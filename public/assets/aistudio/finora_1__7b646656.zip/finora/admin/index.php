<?php
declare(strict_types=1);
// Pintu SUPER ADMIN (diakses lewat IP:port khusus). Docroot Nginx untuk port admin = folder ini.
define('APP_MODE', 'admin');
require __DIR__ . '/../app/bootstrap.php';
require APP_ROOT . '/app/routes/auth.php';
require APP_ROOT . '/app/routes/pages.php';
require APP_ROOT . '/app/routes/admin.php';
require APP_ROOT . '/app/routes/stok.php';
dispatch();
