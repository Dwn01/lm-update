<?php
/**
 * Salin file ini menjadi config/config.php lalu sesuaikan.
 * File config.php TIDAK boleh bisa diakses dari web (di luar docroot, sudah demikian secara default).
 */
return [
    'app_name' => 'LM Finance',

    // Database: 'mysql' (produksi, aaPanel) atau 'sqlite' (uji coba cepat)
    'db' => [
        'driver'      => 'mysql',
        'host'        => '127.0.0.1',
        'port'        => 3306,
        'name'        => 'finora',
        'user'        => 'finora',
        'pass'        => 'Nahiyakanxyz01.',
        'sqlite_path' => __DIR__ . '/../storage/finora.sqlite',
    ],

    'timezone'             => 'Asia/Jakarta',
    'base_path'            => '',      // isi mis. '/finora' jika aplikasi di sub-folder
    'session_idle_minutes' => 120,     // otomatis keluar jika tidak aktif

    // Kunci untuk mengenkripsi rahasia 2FA di database. Diisi otomatis oleh bin/setup.php
    'app_key'              => '82837b3fddbf3fe1e43ac92b20d2950e9251c2db953f8d7744a96373c12c8f5f',

    // Aktifkan jika di belakang proxy tepercaya (Cloudflare Tunnel, Nginx proxy lain).
    // Jika true, IP klien dibaca dari CF-Connecting-IP / X-Forwarded-For dan HTTPS dari X-Forwarded-Proto.
    'trust_proxy'          => false,

    // Notifikasi Telegram setiap ada login (opsional). Cara: chat ke @BotFather -> /newbot -> salin token;
    // kirim pesan apa saja ke bot Anda, lalu buka https://api.telegram.org/bot<TOKEN>/getUpdates untuk melihat chat id.
    // Uji: php bin/admin-tool.php test-telegram
    'telegram' => [
        'bot_token'           => '',     // contoh: 123456789:AAxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
        'chat_id'             => '',     // contoh: 123456789 (atau -100... untuk grup)
        'notify_failed_admin' => true,   // juga beri peringatan saat login admin gagal/diblokir (maks 1 per 5 menit)
    ],

    // Opsional: batasi panel admin hanya dari IP/CIDR tertentu. Kosongkan [] untuk menonaktifkan.
    // Contoh: ['192.168.1.0/24', '203.0.113.10']
    'allowed_admin_ips'    => [],
];
