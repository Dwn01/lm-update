# LM Finance — Aplikasi Manajemen Keuangan

PHP 8.2 (tanpa Composer / tanpa framework) + MySQL/MariaDB. Tampilan mengikuti desain Figma Make "Finance Management Web App".

## Dua pintu, satu aplikasi, satu database

| Pintu | Folder docroot | Diakses lewat | Peran |
|---|---|---|---|
| **User** | `public/` | domain (HTTPS) | Pengguna & Hanya Lihat |
| **Super Admin** | `admin/` | `IP:port` khusus | Super Admin |

Keduanya memakai kode (`app/`), database, dan `config/config.php` yang sama, tetapi **sesi dan akun dipisah**:
akun pengguna tidak bisa login di pintu admin dan sebaliknya. Route admin (`/persetujuan`, `/pengguna`, `/audit`)
hanya terdaftar di pintu admin, jadi lewat domain halaman itu tidak ada (404).

## Alur persetujuan
- **Pengguna**: tambah/ubah/hapus data (transaksi, kategori, akun, invoice, anggaran, profil perusahaan, stok mobil beserta fotonya) **tidak langsung berlaku**. Perubahan masuk antrean *Persetujuan*.
- **Super admin** melihat perbandingan sebelum–sesudah, lalu **Setujui** (diterapkan) atau **Tolak** (dengan catatan).
- Data yang masih menunggu **tidak dihitung** di Dashboard/Analitik/Laporan.
- Satu data hanya boleh punya satu permintaan aktif.
- Super admin mengubah data langsung (tetap tercatat di Log Audit).
- Semua login, pengajuan, persetujuan, dan perubahan masuk **Log Audit**.

## Keamanan yang sudah ada
Password di-hash (bcrypt), CSRF di semua POST, prepared statement (anti SQL injection), escape output (anti XSS),
pembatasan percobaan login (per IP & per akun), sesi diputar saat login & kedaluwarsa otomatis, cookie `HttpOnly`/`SameSite`/`Secure` (saat HTTPS),
header keamanan + CSP, **notifikasi Telegram setiap login** (dan peringatan login admin gagal/diblokir), 2FA TOTP **opsional** (rahasia dienkripsi AES-256-GCM),
password sementara wajib diganti pada login pertama, pembatasan IP admin opsional (`allowed_admin_ips`).

## Pemasangan (aaPanel, Armbian)
Lihat `docs/PANDUAN-PEMASANGAN.md`.


## Fitur Stok Mobil
- Menu **Stok Mobil** untuk tambah, edit, cari/filter, dan hapus kendaraan.
- Data kendaraan mencakup merek/model, tahun, nomor polisi, kondisi dasar, status, harga beli/jual, dan catatan.
- Mendukung banyak foto per mobil (JPG/PNG/WebP, maksimal 5 MB per foto), foto utama, serta hapus foto.
- Foto tersimpan di `public/uploads/cars/`; pastikan user PHP dapat menulis ke folder `public/uploads/`.
- Pengguna (peran *Pengguna*) dapat menambah/mengubah/menghapus mobil dan mengunggah/menghapus foto, tetapi **semuanya masuk antrean Persetujuan**. Foto yang diajukan disimpan sementara di `storage/pending_photos/` (di luar docroot) dan baru dipindahkan ke `public/uploads/cars/` setelah super admin menyetujui; jika ditolak, foto sementara dihapus. Super admin tetap mengubah langsung. Peran *Hanya Lihat* hanya dapat melihat.
- Tabel `cars` dan `car_photos` dibuat oleh `schema_install()` saat menjalankan `php bin/setup.php --admin=USERNAME` dengan username super admin yang sudah ada (akun yang sudah ada akan dilewati). Cadangkan database sebelum menjalankan setup pada server produksi.
- Untuk Nginx, terapkan pembaruan `docs/nginx-user.conf`. Pastikan `upload_max_filesize` sekurangnya `5M` dan `post_max_size` lebih besar dari total upload yang diizinkan.

## Stok mobil terintegrasi keuangan

Semua perubahan tetap lewat alur persetujuan (pengguna mengajukan, super admin menyetujui/langsung menerapkan). Transaksi keuangan baru dibuat **hanya saat perubahan disetujui/diterapkan**; permintaan yang menunggu atau ditolak tidak memengaruhi saldo maupun laporan.

**Pembelian (mobil baru)** — form menanyakan *harga beli*, *dibayar sekarang* (kosong = lunas) dan *sumber dana*. Saat disetujui: mobil masuk stok aktif; satu transaksi **pengeluaran** kategori "Pembelian Mobil" sebesar yang **dibayar** dibuat pada akun sumber (saldo berkurang). Sisa yang belum dibayar menjadi **Utang** (invoice `payable`, jatuh tempo 30 hari). Tanpa sumber dana → validasi gagal (tidak ada akun yang dipilih diam-diam).

**Penjualan** — tombol **Tandai Terjual** di kartu mobil membuka modal (tanggal, harga jual aktual, uang diterima, akun tujuan, pembeli, catatan). Saat disetujui: status jadi Terjual; satu transaksi **pemasukan** kategori "Penjualan Mobil" sebesar **uang yang diterima** pada akun tujuan. Sisa menjadi **Piutang** (invoice `receivable`, jatuh tempo 14 hari). Harga jual rencana hanya dipakai sebagai nilai awal di modal.

**Pembatalan penjualan** — tombol **Batalkan Penjualan** di tab Terjual. Transaksi pemasukan **tidak dihapus**; dibuat transaksi pembalik (pengeluaran "Pembatalan Penjualan") dari akun yang sama sebesar uang yang pernah diterima, piutang sisa yang belum dibayar dihapus, mobil kembali ke stok aktif. Penjualan ulang membuat transaksi baru.

**Hapus mobil** — mobil terjual tidak bisa dihapus (batalkan penjualan dulu). Menghapus mobil belum terjual yang pembeliannya sudah dibukukan membuat transaksi pembalik "Pembatalan Pembelian" (pemasukan); transaksi pembelian aslinya tetap ada.

**Anti-ganda** — setiap transaksi otomatis punya `ref_key` unik (`car:<id>:purchase`, `car:<id>:sale:<n>`, `...:rev`) yang dijaga **indeks UNIK database**; persetujuan memakai klaim status atomik di dalam satu transaksi database (approve ganda/klik ganda/retry gagal tanpa efek). Transaksi otomatis berstatus terkunci di menu Transaksi dan memiliki `car_id` untuk penelusuran.

**Dashboard** (filter: hari ini / bulan / tahun / semua periode):
- Arus kas bersih = uang masuk aktual − uang keluar aktual.
- Laba kotor = harga jual aktual − harga beli, untuk mobil terjual pada periode.
- Laba bersih = laba kotor + pemasukan lain (non-mobil) − biaya operasional (pengeluaran non-mobil). Pembelian mobil tidak dihitung sebagai beban (sudah menjadi harga pokok saat terjual); pembatalan/pembalik tidak dihitung sebagai pendapatan/biaya operasional.
- Kartu **Stok Mobil**: tersedia, dipesan, terjual, rata-rata harga beli, modal stok aktif (tersedia + dipesan). Hanya ringkasan, tidak membuat transaksi.
- Menu Laporan/Analitik adalah laporan **arus kas** (diberi label "Arus Kas Bersih").

**Data lama** — migrasi otomatis (sekali, penanda `storage/.migrated-cars-finance-v2`) hanya menambah kolom/indeks. Mobil lama **tidak** dibuatkan transaksi pembelian; mobil lama berstatus terjual tampil di tab Terjual ("Belum tercatat" bila belum ada transaksi). Transaksi penjualan buatan versi sebelumnya otomatis ditautkan ke mobilnya tanpa mengubah nominal. Rekonsiliasi saldo historis tidak dilakukan otomatis. **Cadangkan database sebelum memperbarui.**

**Keterbatasan** — menandai invoice utang/piutang "Lunas" (fitur lama) hanya mengubah status, belum membuat transaksi kas; pelunasan sisa pembelian/penjualan perlu dicatat sebagai transaksi manual. Pembelian bertanggal hari persetujuan (belum ada input tanggal beli). Belum ada fitur transfer antar-akun.

## Menjalankan lokal (Kali Linux / Debian)
```bash
sudo apt install php-cli php-sqlite3 php-mbstring        # PHP >= 8.2 (fileinfo bawaan)
cd finora
php bin/setup.php --admin=superadmin --sqlite             # membuat config/config.php (SQLite), tabel, super admin (password ditampilkan sekali)
# opsional data contoh: tambahkan --demo
php -S 127.0.0.1:8080 -t public bin/dev-router.php        # pintu USER   -> http://127.0.0.1:8080
FINORA_DEV_ADMIN=1 php -S 127.0.0.1:8081 -t admin bin/dev-router.php   # pintu ADMIN -> http://127.0.0.1:8081 (terminal lain)
```
Buat akun pengguna dari panel admin → menu **Pengguna**. Konfigurasi ada di `config/config.php` (dibuat otomatis; `app_key` acak, jangan dibagikan). Produksi (MySQL + Nginx/aaPanel): lihat `docs/PANDUAN-PEMASANGAN.md`. Pastikan folder `storage/` dan `public/uploads/` dapat ditulis user PHP.
