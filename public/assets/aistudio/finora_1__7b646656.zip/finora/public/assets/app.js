(function () {
  'use strict';
  var body = document.body;

  // --- sidebar ---
  try { if (localStorage.getItem('finora.collapsed') === '1') body.classList.add('sidebar-collapsed'); } catch (e) {}

  document.addEventListener('click', function (ev) {
    var t = ev.target.closest('[data-action]');
    if (t) {
      var a = t.getAttribute('data-action');
      if (a === 'collapse') {
        body.classList.toggle('sidebar-collapsed');
        try { localStorage.setItem('finora.collapsed', body.classList.contains('sidebar-collapsed') ? '1' : '0'); } catch (e) {}
      } else if (a === 'open-menu') { body.classList.add('menu-open'); }
      else if (a === 'close-menu') { body.classList.remove('menu-open'); }
      return;
    }

    // buka dialog form
    var opener = ev.target.closest('[data-dialog]');
    if (opener) { openDialog(opener); return; }

    // tutup dialog
    var closer = ev.target.closest('[data-close]');
    if (closer) { var d = closer.closest('dialog'); if (d) d.close(); return; }

    // klik di luar dialog = tutup
    if (ev.target.tagName === 'DIALOG') { ev.target.close(); return; }

    // tutup menu profil jika klik di luar
    document.querySelectorAll('details.profile-menu[open]').forEach(function (d) {
      if (!d.contains(ev.target)) d.removeAttribute('open');
    });
  });

  function openDialog(btn) {
    var dlg = document.getElementById(btn.getAttribute('data-dialog'));
    if (!dlg) return;
    var form = dlg.querySelector('form');
    var mode = btn.getAttribute('data-mode') || 'create';
    var row = {};
    try { row = JSON.parse(btn.getAttribute('data-row') || '{}'); } catch (e) {}
    form.reset();
    var act = form.querySelector('[name=action]'); if (act) act.value = mode;
    var idf = form.querySelector('[name=id]'); if (idf) idf.value = row.id || '';
    Object.keys(row).forEach(function (k) {
      var els = form.querySelectorAll('[name="' + k + '"]');
      els.forEach(function (el) {
        if (el.type === 'radio') { el.checked = (String(el.value) === String(row[k])); }
        else if (el.type !== 'hidden' || k !== 'action') { el.value = row[k] === null ? '' : row[k]; }
      });
    });
    dlg.querySelectorAll('[data-title-create]').forEach(function (el) { el.hidden = mode !== 'create'; });
    dlg.querySelectorAll('[data-title-update]').forEach(function (el) { el.hidden = mode !== 'update'; });
    var checked = form.querySelector('[name=type]:checked');
    if (checked) filterCategories(form);
    // nilai default dari tombol (mis. bulan)
    var defaults = btn.getAttribute('data-defaults');
    if (defaults && mode === 'create') {
      try { var dv = JSON.parse(defaults); Object.keys(dv).forEach(function (k) { var el = form.querySelector('[name="' + k + '"]'); if (el && !el.value) el.value = dv[k]; }); } catch (e) {}
    }
    dlg.showModal();
    var first = form.querySelector('input[type=text],input[type=number],input[type=date],input[type=month],select,textarea');
    if (first) { try { first.focus(); } catch (e) {} }
  }

  // kategori mengikuti jenis transaksi
  function filterCategories(form) {
    var typeEl = form.querySelector('[name=type]:checked');
    var sel = form.querySelector('select[name=category_id]');
    if (!typeEl || !sel) return;
    var type = typeEl.value;
    var cur = sel.value;
    var stillOk = false;
    Array.prototype.forEach.call(sel.options, function (o) {
      var t = o.getAttribute('data-type');
      if (!t) return;
      var ok = t === type;
      o.hidden = !ok; o.disabled = !ok;
      if (ok && o.value === cur) stillOk = true;
    });
    if (!stillOk) sel.value = '';
  }
  document.addEventListener('change', function (ev) {
    var el = ev.target;
    if (el.matches && el.matches('form [name=type][type=radio]')) filterCategories(el.form);
    if (el.matches && el.matches('[data-autosubmit]')) { (el.form.requestSubmit ? el.form.requestSubmit() : el.form.submit()); }
  });

  // bagian "Data penjualan" pada form stok mobil: tampil hanya saat status = Terjual
  (function () {
    var st = document.getElementById('status'), box = document.querySelector('[data-sale-fields]');
    if (!st || !box) return;
    function sync() { box.classList.toggle('is-hidden', st.value !== 'terjual'); }
    st.addEventListener('change', sync); sync();
  })();

  // konfirmasi hapus / aksi penting
  document.addEventListener('submit', function (ev) {
    var f = ev.target;
    var msg = f.getAttribute && f.getAttribute('data-confirm');
    if (msg && !window.confirm(msg)) { ev.preventDefault(); return; }
    // cegah klik ganda + tampilkan indikator proses (pencegahan sebenarnya ada di backend)
    if (f.hasAttribute && f.hasAttribute('data-once')) {
      if (f.getAttribute('data-busy') === '1') { ev.preventDefault(); return; }
      f.setAttribute('data-busy', '1');
      setTimeout(function () {
        f.querySelectorAll('button[type=submit]').forEach(function (b) {
          b.disabled = true; b.classList.add('is-loading');
          var lt = b.getAttribute('data-loading-text'); if (lt) b.textContent = lt;
        });
      }, 0);
    }
  });
  // kembali dari cache browser: pulihkan tombol
  window.addEventListener('pageshow', function () {
    document.querySelectorAll('form[data-busy]').forEach(function (f) { f.removeAttribute('data-busy'); f.querySelectorAll('button.is-loading').forEach(function (b) { b.disabled = false; b.classList.remove('is-loading'); }); });
  });

  // dialog Tandai Terjual: uang diterima mengikuti harga (sampai diubah manual); akun wajib bila ada uang masuk
  (function () {
    var dlg = document.getElementById('dlg-sell'); if (!dlg) return;
    var price = dlg.querySelector('[name=sold_price]'), recv = dlg.querySelector('[name=sold_received]'), acc = dlg.querySelector('[name=sold_account_id]');
    var touched = false;
    recv.addEventListener('input', function () { touched = true; sync(); });
    price.addEventListener('input', function () { if (!touched) recv.value = price.value; sync(); });
    new MutationObserver(function () {}).observe(dlg, { attributes: true, attributeFilter: ['open'] });
    dlg.addEventListener('close', function () { touched = false; });
    function sync() { acc.required = (parseInt(recv.value || '0', 10) > 0); }
    document.addEventListener('click', function (ev) { if (ev.target.closest && ev.target.closest('[data-dialog=dlg-sell]')) setTimeout(function () { touched = false; sync(); }, 0); });
  })();

  // halaman cetak
  if (body.hasAttribute('data-print')) {
    window.addEventListener('load', function () { setTimeout(function () { window.print(); }, 300); });
  }
  document.querySelectorAll('[data-print-now]').forEach(function (b) {
    b.addEventListener('click', function () { window.print(); });
  });
})();
