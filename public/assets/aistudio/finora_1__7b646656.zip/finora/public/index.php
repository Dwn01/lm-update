<?php
declare(strict_types=1);
// Pintu USER (diakses lewat domain).
define('APP_MODE', 'user');
require __DIR__ . '/../app/bootstrap.php';
require APP_ROOT . '/app/routes/auth.php';
require APP_ROOT . '/app/routes/pages.php';
require APP_ROOT . '/app/routes/stok.php';
dispatch();
