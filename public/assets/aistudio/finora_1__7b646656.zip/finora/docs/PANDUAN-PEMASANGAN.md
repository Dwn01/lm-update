# Panduan Pemasangan LM Finance di aaPanel (Armbian, Nginx, PHP 8.2)

## 1. Siapkan server
- aaPanel: pasang **Nginx**, **PHP 8.2**, **MySQL/MariaDB**.
- PHP 8.2 > Install Extensions: pastikan aktif `pdo_mysql`, `mbstring`, `openssl`, `zip`, `fileinfo`.
  (Ekstensi `zip` dipakai untuk ekspor Excel; jika tidak ada, ekspor otomatis jatuh ke CSV.)
- Di PHP 8.2 > Disabled functions: jangan nonaktifkan `proc_open`/`putenv` bila Anda memakai fitur lain; LM Finance tidak memerlukannya.

## 2. Upload kode
1. Ekstrak `finora.zip` ke `/www/wwwroot/finora/` (jadi ada `/www/wwwroot/finora/public`, `/admin`, `/app`, `/config`, ...).
2. Hak akses: `chown -R www:www /www/wwwroot/finora && chmod -R o-rwx /www/wwwroot/finora/config /www/wwwroot/finora/storage`

## 3. Database
aaPanel > Database > Tambah: nama `finora`, user `finora`, password kuat. Catat.

## 4. Konfigurasi & setup awal (lewat terminal / SSH)
```bash
cd /www/wwwroot/finora
php bin/setup.php                      # membuat config/config.php (app_key acak otomatis)
nano config/config.php                 # isi nama db, user, password
php bin/setup.php --admin=superadmin   # membuat tabel + kategori/akun awal + super admin (password acak ditampilkan SEKALI)
```
- Tambah `--demo` jika ingin data contoh untuk mencoba (jangan untuk data sungguhan).
- Jalankan `php -v` pastikan CLI juga PHP 8.2 (di aaPanel biasanya `/www/server/php/82/bin/php`).

## 5. Pintu USER (domain)
1. aaPanel > Website > Add site: domain Anda, **Root = `/www/wwwroot/finora/public`**, PHP 8.2.
2. SSL > Let's Encrypt (wajib HTTPS).
3. Konfigurasi situs: tempel isi `docs/nginx-user.conf` (bagian location). Reload Nginx.
4. Buka `https://domainanda.com` → halaman masuk.

## 6. Pintu SUPER ADMIN (IP:port)
1. Salin `docs/nginx-admin.conf` menjadi `/www/server/panel/vhost/nginx/finora-admin.conf`, ganti `listen 8443;` (port bebas selain 80/443/8888), lalu Nginx > Reload.
2. Buka port itu di **aaPanel > Security** (firewall) dan di router (port forward) bila ingin dari luar.
3. Buka `http://IP-SERVER:8443` → login `superadmin`. (2FA tidak wajib; bisa diaktifkan sukarela di menu Keamanan.)
4. Menu **Pengguna** → tambah akun user (password sementara dibuat otomatis, user wajib menggantinya).

### Notifikasi Telegram (setiap login)
1. Chat ke **@BotFather** → `/newbot` → salin **token**.
2. Kirim pesan apa saja ke bot Anda, buka `https://api.telegram.org/bot<TOKEN>/getUpdates`, salin angka `chat` → `id`.
3. Isi di `config/config.php`:
   ```php
   'telegram' => ['bot_token' => '123456:AAxxxx', 'chat_id' => '123456789', 'notify_failed_admin' => true],
   ```
4. Uji: `php bin/admin-tool.php test-telegram`. Server harus bisa keluar ke `api.telegram.org` (HTTPS).
Pesan berisi akun, IP, waktu, dan perangkat; dikirim untuk login berhasil (admin & user) dan, untuk admin, login gagal/diblokir (maks 1 pesan per 5 menit). Pesan dikirim setelah halaman tampil sehingga login tidak melambat; jika Telegram tidak terjangkau, login tetap jalan dan galatnya masuk log PHP.

### Wajib dipertimbangkan jika admin dibuka ke internet
- Notifikasi hanya **memberi tahu**, tidak mencegah. Tanpa 2FA, siapa pun yang tahu password bisa masuk; pakai password panjang dan unik, dan segera ganti jika ada notifikasi login yang tidak Anda kenali.
- Batasi IP: buka komentar `allow/deny` di `nginx-admin.conf`, atau isi `allowed_admin_ips` di `config.php`.
- Gunakan **HTTPS** untuk admin (subdomain + Let's Encrypt, atau self-signed). Tanpa HTTPS password terkirim tanpa enkripsi.
- Router dengan CGNAT tidak bisa port-forward; gunakan Cloudflare Tunnel (arahkan hostname ke `http://localhost:PORT`, set `trust_proxy => true`).
- Pasang fail2ban untuk Nginx jika memungkinkan. Aplikasi sudah membatasi percobaan login, namun fail2ban memblokir di tingkat jaringan.

## 7. Jika di belakang proxy (Cloudflare Tunnel, dsb.)
Di `config/config.php` set `'trust_proxy' => true` agar IP asli dan HTTPS terbaca benar. **Jangan** aktifkan jika server langsung terbuka ke internet tanpa proxy tepercaya (header bisa dipalsukan).

## 8. Backup
aaPanel > Cron > Shell: `bash /www/wwwroot/finora/bin/backup.sh` harian. Hasil di `storage/backup/` (simpan salinan di luar server juga).

## 9. Alat darurat (hanya dari terminal)
```bash
php bin/admin-tool.php list
php bin/admin-tool.php reset-2fa superadmin           # jika 2FA opsional diaktifkan lalu HP hilang
php bin/admin-tool.php test-telegram
php bin/admin-tool.php reset-password superadmin 'PasswordBaru123'
php bin/admin-tool.php create-admin namabaru 'PasswordBaru123' "Nama"
```

## 10. Pemecahan masalah
- Halaman putih / error 500: lihat log PHP/Nginx di aaPanel (aplikasi tidak menampilkan detail error ke browser).
- "Aplikasi belum dikonfigurasi": `config/config.php` belum dibuat (langkah 4).
- Tidak bisa login berulang kali: dibatasi 15 menit setelah banyak percobaan gagal.
- Tampilan tanpa gaya (CSS hilang) di pintu admin: pastikan `location ^~ /assets/` dengan `alias` ke `public/assets/` ada dan path benar.
