<?php
declare(strict_types=1);

if (!defined('APP_MODE') || !in_array(APP_MODE, ['user', 'admin'], true)) {
    http_response_code(500);
    exit('APP_MODE tidak valid.');
}
define('APP_ROOT', dirname(__DIR__));

error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');

$cfgFile = APP_ROOT . '/config/config.php';
if (!is_file($cfgFile)) {
    http_response_code(503);
    exit('Aplikasi belum dikonfigurasi. Salin config/config.sample.php menjadi config/config.php lalu jalankan: php bin/setup.php');
}
$GLOBALS['CONFIG'] = require $cfgFile;
date_default_timezone_set((string)($GLOBALS['CONFIG']['timezone'] ?? 'Asia/Jakarta'));

foreach (['helpers', 'db', 'schema', 'totp', 'notify', 'auth', 'cars', 'entities', 'repo', 'icons', 'charts', 'xlsx', 'view', 'partials'] as $lib) {
    require APP_ROOT . '/app/lib/' . $lib . '.php';
}

set_exception_handler(function (Throwable $ex): void {
    app_log(get_class($ex) . ': ' . $ex->getMessage() . ' @ ' . $ex->getFile() . ':' . $ex->getLine());
    if (!headers_sent()) {
        http_response_code(500);
        header('Content-Type: text/html; charset=utf-8');
    }
    echo '<!doctype html><meta charset="utf-8"><title>Terjadi kesalahan</title>'
        . '<body style="font-family:sans-serif;padding:40px"><h2>Terjadi kesalahan di server</h2>'
        . '<p>Silakan coba lagi. Jika berlanjut, hubungi administrator.</p></body>';
});

// Header keamanan
header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
header("Content-Security-Policy: default-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data:; script-src 'self'; form-action 'self'; frame-ancestors 'none'; base-uri 'self'");
header('Cache-Control: no-store');
if (is_https()) {
    header('Strict-Transport-Security: max-age=15552000');
}
header('X-Robots-Tag: noindex, nofollow');

// Panel admin: pembatasan IP opsional
if (is_admin_mode()) {
    $allow = (array)cfg('allowed_admin_ips', []);
    if ($allow && !ip_in_list(client_ip(), $allow)) {
        http_response_code(403);
        exit('Akses ditolak.');
    }
}

schema_migrate_once();
session_boot();

// Router
$GLOBALS['ROUTES'] = [];

function route(string $method, string $path, callable $handler, array $opts = []): void
{
    $GLOBALS['ROUTES'][$method][$path] = [$handler, $opts];
}

function dispatch(): void
{
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    $path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
    $base = rtrim((string)cfg('base_path', ''), '/');
    if ($base !== '' && str_starts_with($path, $base)) {
        $path = substr($path, strlen($base)) ?: '/';
    }
    if ($path !== '/') {
        $path = rtrim($path, '/');
    }
    $hit = $GLOBALS['ROUTES'][$method][$path] ?? null;
    if (!$hit) {
        $other = false;
        foreach ($GLOBALS['ROUTES'] as $m => $list) {
            if (isset($list[$path])) {
                $other = true;
            }
        }
        http_response_code($other ? 405 : 404);
        echo view_page('error', ['code' => $other ? 405 : 404, 'message' => $other ? 'Metode tidak diizinkan.' : 'Halaman tidak ditemukan.'], ['layout' => 'bare', 'title' => 'Tidak ditemukan']);
        return;
    }
    [$handler, $o] = $hit;
    $public = !empty($o['public']);

    if ($method === 'POST' && !csrf_ok()) {
        http_response_code(419);
        echo view_page('error', ['code' => 419, 'message' => 'Sesi formulir kedaluwarsa. Muat ulang halaman lalu coba lagi.'], ['layout' => 'bare', 'title' => 'Sesi kedaluwarsa']);
        return;
    }

    if (!$public) {
        $u = current_user();
        if (!$u) {
            if ($method === 'GET') {
                $_SESSION['intended'] = $_SERVER['REQUEST_URI'] ?? '/';
            }
            redirect(url('/masuk'));
        }
        if (!empty($o['admin']) && !is_super()) {
            http_response_code(403);
            echo view_page('error', ['code' => 403, 'message' => 'Anda tidak memiliki akses ke halaman ini.'], ['title' => 'Akses ditolak', 'active' => '']);
            return;
        }
        if (!empty($o['write']) && !can_write()) {
            flash('error', 'Akun Anda hanya memiliki akses lihat.');
            redirect(url('/'));
        }
        if (must_finish_security() && !in_array($path, ['/keamanan', '/keamanan/password', '/keamanan/2fa/mulai', '/keamanan/2fa/aktifkan', '/keluar'], true)) {
            flash('info', 'Demi keamanan, ganti password sementara Anda terlebih dahulu.');
            redirect(url('/keamanan'));
        }
    }
    $handler();
}
