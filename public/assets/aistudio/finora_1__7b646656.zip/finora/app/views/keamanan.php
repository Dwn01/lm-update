<?php $admin = is_admin_mode(); ?>
<div class="page-title-row">
  <div><h1>Keamanan Akun</h1><p>Kelola password<?= $admin ? ' dan autentikasi dua langkah (2FA, opsional)' : '' ?> akun Anda.</p></div>
</div>

<?php if ($forced): ?>
  <div class="notice"><span>Anda harus mengganti password sementara sebelum melanjutkan.</span></div>
<?php endif; ?>

<div class="security-grid">
  <section class="card">
    <div class="card-title">Ganti password</div>
    <div class="card-subtitle" style="margin-bottom:16px">Minimal 10 karakter, mengandung huruf dan angka.</div>
    <form method="post" action="<?= e(url('/keamanan/password')) ?>" class="form-stack">
      <?= csrf_field() ?>
      <label class="field">Password saat ini<input type="password" name="current" required autocomplete="current-password" maxlength="200"></label>
      <label class="field">Password baru<input type="password" name="new" required autocomplete="new-password" minlength="10" maxlength="200"></label>
      <label class="field">Ulangi password baru<input type="password" name="confirm" required autocomplete="new-password" minlength="10" maxlength="200"></label>
      <div><button class="primary-button" type="submit">Simpan password</button></div>
    </form>
  </section>

  <?php if ($admin): ?>
  <section class="card">
    <div class="card-title">Autentikasi dua langkah (2FA) <?= badge('Opsional', 'neutral') ?></div>
    <?php if ((int)$u['totp_enabled'] === 1): ?>
      <p style="margin:12px 0"><?= badge('Aktif', 'green') ?></p>
      <p class="muted" style="font-size:13px">Login ke panel admin memerlukan kode 6 digit dari aplikasi autentikator. Jika perangkat hilang, reset lewat server: <code>php bin/admin-tool.php reset-2fa <?= e($u['username']) ?></code></p>
    <?php elseif ($secret): ?>
      <div class="card-subtitle" style="margin-bottom:14px">Tambahkan akun ke Google Authenticator / Authy / Microsoft Authenticator dengan memasukkan kunci ini secara manual (jenis: berbasis waktu).</div>
      <div class="form-stack">
        <div><small class="muted">Kunci rahasia</small><div class="code-box"><?= e(trim(chunk_split($secret, 4, ' '))) ?></div></div>
        <div><small class="muted">Atau tautan otpauth</small><div class="code-box" style="font-size:11px;letter-spacing:0"><?= e($uri) ?></div></div>
        <form method="post" action="<?= e(url('/keamanan/2fa/aktifkan')) ?>" class="form-stack">
          <?= csrf_field() ?>
          <label class="field">Masukkan kode 6 digit untuk konfirmasi
            <input class="otp-input" type="text" name="code" inputmode="numeric" maxlength="7" required autocomplete="one-time-code" placeholder="000000">
          </label>
          <div><button class="primary-button" type="submit">Aktifkan 2FA</button></div>
        </form>
      </div>
    <?php else: ?>
      <p style="margin:12px 0"><?= badge('Belum aktif', 'yellow') ?></p>
      <p class="muted" style="font-size:13px;margin-bottom:16px">Tidak wajib. Jika panel admin dibuka ke internet, 2FA sangat menambah keamanan karena password saja bisa ditebak atau bocor. Login tetap memicu notifikasi Telegram bila dikonfigurasi.</p>
      <form method="post" action="<?= e(url('/keamanan/2fa/mulai')) ?>"><?= csrf_field() ?><button class="primary-button" type="submit">Mulai aktivasi 2FA</button></form>
    <?php endif; ?>
  </section>
  <?php else: ?>
  <section class="card">
    <div class="card-title">Akun</div>
    <dl class="kv" style="margin-top:16px">
      <dt>Nama</dt><dd><?= e($u['name']) ?></dd>
      <dt>Username</dt><dd><?= e($u['username']) ?></dd>
      <dt>Peran</dt><dd><?= e(ROLE_LABELS[$u['role']] ?? $u['role']) ?></dd>
      <dt>Masuk terakhir</dt><dd><?= e(datetime_id($u['last_login_at'])) ?></dd>
    </dl>
    <p class="muted" style="font-size:12px;margin-top:16px">Setiap perubahan data yang Anda lakukan akan diajukan dan baru berlaku setelah disetujui super admin.</p>
  </section>
  <?php endif; ?>
</div>
