<?= pending_banner() ?>
<div class="page-title-row">
  <div><h1>Anggaran</h1><p>Tetapkan batas pengeluaran dan pantau realisasi bulanan.</p></div>
  <div class="title-actions">
    <form method="get" action="<?= e(url('/anggaran')) ?>"><input class="select" type="month" name="bulan" value="<?= e($ym) ?>" data-autosubmit aria-label="Bulan"></form>
    <?= add_button('Buat Anggaran', 'dlg-bud', ['month' => $ym]) ?>
  </div>
</div>

<div class="summary-grid">
  <section class="card"><small>Total Anggaran</small><strong><?= e(idr($total)) ?></strong></section>
  <section class="card"><small>Terpakai</small><strong><?= e(idr($used)) ?></strong><span class="muted"><?= $total > 0 ? e(number_format($used / $total * 100, 1, ',', '.')) . '% dari anggaran' : '-' ?></span></section>
  <section class="card"><small>Sisa Anggaran</small><strong class="<?= $total - $used < 0 ? 'negative' : '' ?>"><?= e(idr($total - $used)) ?></strong></section>
</div>

<section class="card page-card">
  <div class="card-heading"><div><div class="card-title">Anggaran Bulan Ini</div><div class="card-subtitle"><?= e(month_label($ym)) ?></div></div></div>
  <div class="budget-list">
    <?php foreach ($list as $b):
        $p = (int)$b['pct'];
        $tone = $p > 100 ? 'red' : ($p > 80 ? 'red' : ($p > 70 ? 'yellow' : 'green'));
        $row = ['id' => (int)$b['id'], 'category_id' => (int)$b['category_id'], 'month' => $b['month'], 'amount' => (int)$b['amount']]; ?>
      <div class="budget-row">
        <div><strong><?= e($b['category_name']) ?><?= pending_chip($pending[(int)$b['id']] ?? null) ?></strong><span class="sub"><?= e(idr($b['used'])) ?> dari <?= e(idr($b['amount'])) ?></span></div>
        <?= badge($p . '%', $tone) ?>
        <?= row_actions('budget', 'dlg-bud', $row, isset($pending[(int)$b['id']])) ?>
        <div class="progress"><i class="<?= $p > 80 ? 'danger' : ($p > 70 ? 'warn' : '') ?>" style="width:<?= min(100, max(0, $p)) ?>%"></i></div>
      </div>
    <?php endforeach; ?>
    <?php if (!$list): ?><div class="empty-state">Belum ada anggaran untuk bulan ini.</div><?php endif; ?>
  </div>
</section>

<?php if (can_write()): ?>
<dialog class="modal" id="dlg-bud">
  <?= modal_head('Buat Anggaran', 'Edit Anggaran', 'Batas pengeluaran per kategori dan bulan') ?>
  <form method="post" action="<?= e(url('/aksi')) ?>">
    <?= action_fields('budget', 'create') ?><input type="hidden" name="id" value="">
    <?= approval_note() ?>
    <div class="form-grid">
      <label class="field full">Kategori pengeluaran<select name="category_id" required><option value="">Pilih kategori</option><?php foreach ($cats as $c): ?><option value="<?= (int)$c['id'] ?>"><?= e($c['name']) ?></option><?php endforeach; ?></select></label>
      <label class="field">Bulan<input type="month" name="month" required value="<?= e($ym) ?>"></label>
      <label class="field">Batas anggaran (Rp)<input type="number" name="amount" required min="1" step="1" inputmode="numeric" placeholder="0"></label>
    </div>
    <div class="modal-actions"><button type="button" class="secondary-button" data-close>Batal</button><button class="primary-button" type="submit"><?= e(submit_label()) ?></button></div>
  </form>
</dialog>
<?php endif; ?>
