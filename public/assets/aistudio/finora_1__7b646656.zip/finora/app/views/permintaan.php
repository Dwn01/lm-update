<div class="page-title-row">
  <div><h1>Permintaan Saya</h1><p>Riwayat perubahan yang Anda ajukan dan status persetujuannya.</p></div>
</div>
<section class="card page-card">
  <div class="table-wrap"><table>
    <thead><tr><th>Diajukan</th><th>Perubahan</th><th>Status</th><th>Diproses</th><th>Catatan</th></tr></thead>
    <tbody>
    <?php foreach ($list as $r):
        $tone = ['pending' => 'yellow', 'approved' => 'green', 'rejected' => 'red'][$r['status']] ?? 'neutral';
        $lbl = ['pending' => 'Menunggu', 'approved' => 'Disetujui', 'rejected' => 'Ditolak'][$r['status']] ?? $r['status']; ?>
      <tr>
        <td><?= e(datetime_id($r['created_at'])) ?></td>
        <td class="wrap"><strong><?= e($r['summary']) ?></strong></td>
        <td><?= badge($lbl, $tone) ?></td>
        <td><?= $r['reviewed_at'] ? e(datetime_id($r['reviewed_at'])) . ($r['reviewer'] ? '<br><small class="muted">oleh ' . e($r['reviewer']) . '</small>' : '') : '-' ?></td>
        <td class="wrap"><?= $r['review_note'] !== '' ? e($r['review_note']) : '-' ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  <?php if (!$list): ?><div class="empty-state">Anda belum mengajukan perubahan apa pun.</div><?php endif; ?></div>
</section>
