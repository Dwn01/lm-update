<div class="page-title-row">
  <div><h1>Persetujuan</h1><p>Tinjau perubahan data yang diajukan pengguna. Perubahan baru berlaku setelah Anda setujui.</p></div>
</div>

<section class="card page-card" style="margin-bottom:14px">
  <div class="tabbar">
    <a class="<?= $status === 'pending' ? 'active' : '' ?>" href="<?= e(url('/persetujuan')) ?>">Menunggu (<?= (int)$counts['pending'] ?>)</a>
    <a class="<?= $status === 'approved' ? 'active' : '' ?>" href="<?= e(url('/persetujuan?status=approved')) ?>">Disetujui (<?= (int)$counts['approved'] ?>)</a>
    <a class="<?= $status === 'rejected' ? 'active' : '' ?>" href="<?= e(url('/persetujuan?status=rejected')) ?>">Ditolak (<?= (int)$counts['rejected'] ?>)</a>
  </div>
</section>

<div class="req-list">
<?php foreach ($list as $r): ?>
  <section class="card req-card">
    <div class="req-head">
      <div>
        <h3><?= e($r['summary']) ?></h3>
        <div class="req-meta">Diajukan oleh <strong><?= e($r['requester']) ?></strong> · <?= e(datetime_id($r['created_at'])) ?> · #<?= (int)$r['id'] ?></div>
      </div>
      <div><?= badge(ACTION_LABELS[$r['action']] ?? $r['action'], $r['action'] === 'delete' ? 'red' : ($r['action'] === 'create' ? 'green' : 'blue')) ?></div>
    </div>

    <?php if ($r['diff']): ?>
    <div class="table-wrap"><table class="diff">
      <thead><tr><th>Bidang</th><th><?= $r['action'] === 'create' ? '' : 'Sebelum' ?></th><th><?= $r['action'] === 'delete' ? '' : 'Sesudah' ?></th></tr></thead>
      <tbody>
      <?php foreach ($r['diff'] as [$label, $b, $a]): ?>
        <tr><td><strong><?= e($label) ?></strong></td>
          <td class="<?= $b !== '' && $r['action'] !== 'create' ? 'before' : '' ?>"><?= $b !== '' ? e($b) : '' ?></td>
          <td class="<?= $a !== '' ? 'after' : '' ?>"><?= $a !== '' ? e($a) : '' ?></td></tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
    <?php endif; ?>

    <?php if ($r['photos_add'] || $r['photos_rm']): ?>
    <div class="req-photos">
      <?php foreach ($r['photos_add'] as $n): ?><figure><img src="<?= e(url('/persetujuan/foto?f=' . $n)) ?>" alt="Foto baru" loading="lazy"><figcaption class="after">Foto baru</figcaption></figure><?php endforeach; ?>
      <?php foreach ($r['photos_rm'] as $pth): ?><figure><img src="<?= e(url($pth)) ?>" alt="Foto dihapus" loading="lazy"><figcaption class="before">Akan dihapus</figcaption></figure><?php endforeach; ?>
    </div>
    <?php endif; ?>

    <?php if ($r['status'] === 'pending'): ?>
    <div class="req-actions">
      <form method="post" action="<?= e(url('/persetujuan/proses')) ?>">
        <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
        <input type="text" name="note" maxlength="255" placeholder="Catatan (opsional, wajib dibaca pengguna jika ditolak)">
        <button class="primary-button sm" type="submit" name="keputusan" value="setuju"><?= icon('check', 16) ?> Setujui</button>
        <button class="danger-button sm" type="submit" name="keputusan" value="tolak" data-confirm-btn>Tolak</button>
      </form>
    </div>
    <?php else: ?>
      <div class="req-meta">
        <?= $r['status'] === 'approved' ? 'Disetujui' : 'Ditolak' ?> oleh <strong><?= e($r['reviewer'] ?? '-') ?></strong> · <?= e(datetime_id($r['reviewed_at'])) ?>
        <?= $r['review_note'] !== '' ? ' · Catatan: ' . e($r['review_note']) : '' ?>
      </div>
    <?php endif; ?>
  </section>
<?php endforeach; ?>
</div>

<?php if (!$list): ?>
  <section class="card"><div class="empty-state"><?= $status === 'pending' ? 'Tidak ada permintaan yang menunggu persetujuan. 🎉' : 'Belum ada data.' ?></div></section>
<?php endif; ?>
