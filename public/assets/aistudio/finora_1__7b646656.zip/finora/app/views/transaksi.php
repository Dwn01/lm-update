<?= pending_banner() ?>
<div class="page-title-row">
  <div><h1>Transaksi</h1><p>Kelola seluruh pemasukan dan pengeluaran perusahaan.</p></div>
  <?= add_button('Tambah Transaksi', 'dlg-tx') ?>
</div>
<section class="card page-card">
  <div class="toolbar">
    <form method="get" action="<?= e(url('/transaksi')) ?>">
      <label class="search-field"><?= icon('search', 18) ?><input name="q" value="<?= e($q) ?>" placeholder="Cari transaksi atau kategori..." maxlength="80"></label>
      <div class="filter-group">
        <select class="select" name="jenis" data-autosubmit aria-label="Jenis">
          <option value="">Semua jenis</option>
          <option value="income" <?= $jenis === 'income' ? 'selected' : '' ?>>Pemasukan</option>
          <option value="expense" <?= $jenis === 'expense' ? 'selected' : '' ?>>Pengeluaran</option>
        </select>
        <input class="select" type="month" name="bulan" value="<?= e($bulan) ?>" data-autosubmit aria-label="Bulan">
        <button class="secondary-button" type="submit"><?= icon('filter', 17) ?> Terapkan</button>
        <?php if ($q !== '' || $jenis !== '' || $bulan !== ''): ?><a class="secondary-button" href="<?= e(url('/transaksi')) ?>">Reset</a><?php endif; ?>
      </div>
    </form>
  </div>
  <?= tx_table($list, true, $pending) ?>
  <div class="table-footer">
    <span>Menampilkan <?= count($list) ?> dari <?= (int)$total ?> transaksi</span>
    <?php if ($pages > 1): ?>
    <div class="pager">
      <?php if ($page > 1): ?><a href="<?= e(pagination_url(['page' => $page - 1])) ?>">←</a><?php else: ?><span class="off">←</span><?php endif; ?>
      <?php
        $start = max(1, $page - 2);
        $end = min($pages, $page + 2);
        for ($i = $start; $i <= $end; $i++): ?>
        <a class="<?= $i === $page ? 'active' : '' ?>" href="<?= e(pagination_url(['page' => $i])) ?>"><?= $i ?></a>
      <?php endfor; ?>
      <?php if ($page < $pages): ?><a href="<?= e(pagination_url(['page' => $page + 1])) ?>">→</a><?php else: ?><span class="off">→</span><?php endif; ?>
    </div>
    <?php endif; ?>
  </div>
</section>
<?= tx_dialog() ?>
