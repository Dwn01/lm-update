<div class="page-title-row">
  <div><h1>Pengguna</h1><p>Akun pengguna hanya dibuat oleh super admin. Pengguna biasa mengajukan perubahan yang perlu Anda setujui.</p></div>
  <button class="primary-button" type="button" data-dialog="dlg-user" data-mode="create"><?= icon('plus', 18) ?> Tambah Pengguna</button>
</div>

<?php if ($newCred): ?>
  <div class="notice" style="display:block">
    <strong>Kredensial sementara untuk <?= e($newCred['name']) ?></strong> — catat sekarang, tidak akan ditampilkan lagi.
    <div class="code-box" style="margin-top:10px">Username: <?= e($newCred['username']) ?> &nbsp;|&nbsp; Password: <?= e($newCred['password']) ?></div>
    <div style="margin-top:8px;font-weight:500">Pengguna wajib mengganti password ini saat login pertama.</div>
  </div>
<?php endif; ?>

<section class="card page-card">
  <div class="table-wrap"><table>
    <thead><tr><th>Nama</th><th>Username</th><th>Peran</th><th>Status</th><th>Masuk terakhir</th><th class="actions"></th></tr></thead>
    <tbody>
    <?php foreach ($users as $u):
        $isMe = (int)$u['id'] === (int)$me['id'];
        $locked = $isMe || $u['role'] === 'super_admin'; ?>
      <tr>
        <td><div class="transaction-name"><span class="avatar" style="width:32px;height:32px;font-size:11px"><?= e(initials($u['name'])) ?></span><div><strong><?= e($u['name']) ?><?= $isMe ? ' (Anda)' : '' ?></strong><small><?= e($u['email'] !== '' ? $u['email'] : '-') ?></small></div></div></td>
        <td><?= e($u['username']) ?></td>
        <td><?php if ($locked): ?><?= badge(ROLE_LABELS[$u['role']] ?? $u['role'], 'blue') ?><?php else: ?>
          <form method="post" action="<?= e(url('/pengguna/peran')) ?>" style="margin:0"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$u['id'] ?>">
            <select class="select compact" name="role" data-autosubmit aria-label="Peran"><option value="user" <?= $u['role'] === 'user' ? 'selected' : '' ?>>Pengguna</option><option value="viewer" <?= $u['role'] === 'viewer' ? 'selected' : '' ?>>Hanya Lihat</option></select></form>
        <?php endif; ?></td>
        <td><?= badge((int)$u['is_active'] === 1 ? 'Aktif' : 'Nonaktif', (int)$u['is_active'] === 1 ? 'green' : 'red') ?><?= (int)$u['must_change_password'] === 1 ? ' ' . badge('Belum ganti password', 'yellow') : '' ?></td>
        <td><?= e(datetime_id($u['last_login_at'])) ?></td>
        <td class="actions">
          <?php if (!$locked): ?>
          <div class="row-actions">
            <form method="post" action="<?= e(url('/pengguna/reset-password')) ?>" data-confirm="Buat password sementara baru untuk <?= e($u['username']) ?>?"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$u['id'] ?>"><button class="secondary-button sm" type="submit">Reset password</button></form>
            <form method="post" action="<?= e(url('/pengguna/status')) ?>" data-confirm="<?= (int)$u['is_active'] === 1 ? 'Nonaktifkan' : 'Aktifkan' ?> akun <?= e($u['username']) ?>?"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$u['id'] ?>"><button class="<?= (int)$u['is_active'] === 1 ? 'danger-button' : 'secondary-button' ?> sm" type="submit"><?= (int)$u['is_active'] === 1 ? 'Nonaktifkan' : 'Aktifkan' ?></button></form>
          </div>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
</section>

<dialog class="modal" id="dlg-user">
  <div class="modal-head"><div><div class="card-title">Tambah Pengguna</div><div class="card-subtitle">Password sementara dibuat otomatis</div></div>
    <button class="icon-button" type="button" data-close aria-label="Tutup"><?= icon('close') ?></button></div>
  <form method="post" action="<?= e(url('/pengguna/tambah')) ?>">
    <?= csrf_field() ?>
    <div class="form-grid">
      <label class="field full">Nama lengkap<input type="text" name="name" required maxlength="100"></label>
      <label class="field">Username<input type="text" name="username" required maxlength="50" pattern="[a-z0-9._\-]{3,50}" autocomplete="off"><small>Huruf kecil, angka, . _ -</small></label>
      <label class="field">Email (opsional)<input type="email" name="email" maxlength="150"></label>
      <label class="field full">Peran
        <select name="role" required><option value="user">Pengguna — dapat mengajukan perubahan</option><option value="viewer">Hanya Lihat — tanpa perubahan</option></select>
      </label>
    </div>
    <div class="modal-actions"><button type="button" class="secondary-button" data-close>Batal</button><button class="primary-button" type="submit">Buat Akun</button></div>
  </form>
</dialog>
