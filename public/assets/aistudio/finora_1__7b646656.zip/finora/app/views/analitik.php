<div class="page-title-row">
  <div><h1>Analitik</h1><p>Pahami performa keuangan melalui tren dan perbandingan.</p></div>
  <div class="title-actions">
    <form method="get" action="<?= e(url('/analitik')) ?>" class="title-actions">
      <input class="select" type="month" name="bulan" value="<?= e($ym) ?>" data-autosubmit aria-label="Bulan">
      <select name="periode" class="select" data-autosubmit aria-label="Periode grafik">
        <option value="6" <?= $periode === '6' ? 'selected' : '' ?>>6 Bulan</option>
        <option value="12" <?= $periode === '12' ? 'selected' : '' ?>>12 Bulan</option>
        <option value="tahun" <?= $periode === 'tahun' ? 'selected' : '' ?>>Tahun <?= e(substr($ym, 0, 4)) ?></option>
      </select>
    </form>
    <a class="primary-button" href="<?= e(url('/laporan')) ?>"><?= icon('file', 18) ?> Buka Laporan</a>
  </div>
</div>

<?php $cInc = pct_change((float)$cur['income'], (float)$prev['income']); ?>
<div class="summary-grid">
  <section class="card"><small>Pendapatan · <?= e(month_label($ym)) ?></small><strong><?= e(idr($cur['income'])) ?></strong>
    <span class="<?= ($cInc ?? 0) >= 0 ? 'positive' : 'negative' ?>"><?= ($cInc ?? 0) >= 0 ? '+' : '-' ?><?= e(pct_text($cInc)) ?> dari bulan lalu</span></section>
  <section class="card"><small>Biaya &amp; Pengeluaran</small><strong><?= e(idr($cur['expense'])) ?></strong>
    <span class="negative"><?= $cur['income'] > 0 ? e(number_format($cur['expense'] / $cur['income'] * 100, 1, ',', '.')) . '% dari pendapatan' : 'Belum ada pendapatan' ?></span></section>
  <section class="card"><small>Arus Kas Bersih</small><strong class="<?= $profit < 0 ? 'negative' : '' ?>"><?= e(idr($profit)) ?></strong>
    <span class="<?= $profit >= 0 ? 'positive' : 'negative' ?>"><?= $margin === null ? 'Margin belum dapat dihitung' : 'Margin ' . e(number_format($margin, 1, ',', '.')) . '%' ?></span></section>
</div>

<div class="charts-grid">
  <section class="card chart-card">
    <div class="card-heading"><div><div class="card-title">Arus Kas</div><div class="card-subtitle">Perbandingan pemasukan dan pengeluaran</div></div></div>
    <div class="legend"><span><i class="legend-dot green"></i>Pemasukan</span><span><i class="legend-dot red"></i>Pengeluaran</span></div>
    <?= chart_cashflow($series) ?>
  </section>
  <section class="card">
    <div class="card-heading" style="padding:20px 20px 0"><div><div class="card-title">Kinerja Bulanan</div><div class="card-subtitle">Arus kas bersih per bulan</div></div></div>
    <?= chart_bars($series['months'], $profits) ?>
  </section>
</div>

<section class="card expense-card">
  <div class="card-heading"><div><div class="card-title">Komposisi Pengeluaran</div><div class="card-subtitle"><?= e(month_label($ym)) ?></div></div></div>
  <?= chart_donut($expCats, $cur['expense']) ?>
</section>
