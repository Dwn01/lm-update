<?= pending_banner() ?>
<div class="page-title-row">
  <div><h1>Akun &amp; Dana</h1><p>Pantau saldo di seluruh rekening dan kas perusahaan. Total: <strong><?= e(idr($total)) ?></strong></p></div>
  <?= add_button('Tambah Akun', 'dlg-acc') ?>
</div>

<?php
$tones = ['blue', 'yellow', 'green', 'purple', 'red'];
$kindIcon = ['bank' => 'bank', 'cash' => 'cash', 'internal' => 'wallet'];
$kindLabel = ['bank' => 'Bank', 'cash' => 'Kas / tunai', 'internal' => 'Dana internal'];
?>
<?php if (!$accs): ?>
  <section class="card"><div class="empty-state">Belum ada akun.</div></section>
<?php else: ?>
<div class="accounts-grid">
  <?php foreach ($accs as $i => $a):
      $row = ['id' => (int)$a['id'], 'name' => $a['name'], 'kind' => $a['kind'], 'number_label' => $a['number_label'], 'opening_balance' => (int)$a['opening_balance']]; ?>
    <section class="card account-card">
      <div class="card-corner"><?= row_actions('account', 'dlg-acc', $row, isset($pending[(int)$a['id']])) ?></div>
      <div class="account-icon <?= $tones[$i % count($tones)] ?>"><?= icon($kindIcon[$a['kind']] ?? 'wallet') ?></div>
      <small><?= e($a['name']) ?><?= pending_chip($pending[(int)$a['id']] ?? null) ?></small>
      <strong class="<?= $a['balance'] < 0 ? 'negative' : '' ?>"><?= e(idr($a['balance'])) ?></strong>
      <span class="sub"><?= e($a['number_label'] !== '' ? $a['number_label'] : ($kindLabel[$a['kind']] ?? '')) ?></span>
    </section>
  <?php endforeach; ?>
</div>

<section class="card">
  <div class="card-heading" style="padding:18px 20px 4px"><div><div class="card-title">Distribusi Dana</div><div class="card-subtitle">Saldo berdasarkan akun</div></div></div>
  <div class="horizontal-bars">
    <?php $max = max(1, ...array_map(fn($a) => max(0, $a['balance']), $accs)); ?>
    <?php foreach ($accs as $i => $a): ?>
      <div><span><?= e($a['name']) ?></span><div><i class="<?= $tones[$i % count($tones)] ?>" style="width:<?= max(2, (int)round(max(0, $a['balance']) / $max * 100)) ?>%"></i></div><strong><?= e(idr_short($a['balance'])) ?></strong></div>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<?php if (can_write()): ?>
<dialog class="modal" id="dlg-acc">
  <?= modal_head('Tambah Akun', 'Edit Akun', 'Rekening bank, kas, atau dana internal') ?>
  <form method="post" action="<?= e(url('/aksi')) ?>">
    <?= action_fields('account', 'create') ?><input type="hidden" name="id" value="">
    <?= approval_note() ?>
    <label class="field">Nama akun<input type="text" name="name" required maxlength="80" placeholder="Contoh: Bank BCA"></label>
    <div class="form-grid">
      <label class="field">Jenis<select name="kind" required><?php foreach ($kindLabel as $k => $l): ?><option value="<?= e($k) ?>"><?= e($l) ?></option><?php endforeach; ?></select></label>
      <label class="field">Keterangan / nomor<input type="text" name="number_label" maxlength="40" placeholder="•••• 8421"></label>
      <label class="field full">Saldo awal (Rp)<input type="number" name="opening_balance" required min="0" step="1" inputmode="numeric" value="0"><small>Saldo sebelum transaksi yang tercatat di sistem.</small></label>
    </div>
    <div class="modal-actions"><button type="button" class="secondary-button" data-close>Batal</button><button class="primary-button" type="submit"><?= e(submit_label()) ?></button></div>
  </form>
</dialog>
<?php endif; ?>
