<?php $admin = is_admin_mode(); ?>
<div class="auth-wrap">
  <div class="auth-card">
    <div class="center"><div class="brand-mark big">F</div></div>
    <h1><?= e(cfg('app_name', 'LM Finance')) ?></h1>
    <p class="sub center"><?= $admin ? '<span class="auth-tag">Panel Super Admin</span><br><br>Masuk untuk mengelola dan menyetujui perubahan data.' : 'Masuk untuk mengelola keuangan perusahaan.' ?></p>
    <?php foreach (flashes() as $f): ?>
      <div class="flash flash-<?= e($f['type']) ?>" role="status"><?= e($f['msg']) ?></div>
    <?php endforeach; ?>
    <form method="post" action="<?= e(url('/masuk')) ?>" class="form-stack" autocomplete="on">
      <?= csrf_field() ?>
      <label class="field">Username
        <input type="text" name="username" required autofocus autocomplete="username" maxlength="50" value="<?= e($username) ?>">
      </label>
      <label class="field">Password
        <input type="password" name="password" required autocomplete="current-password" maxlength="200">
      </label>
      <button class="primary-button" type="submit">Masuk</button>
    </form>
    <?php if (!$admin): ?>
      <p class="muted center" style="font-size:12px;margin-top:18px">Belum punya akun? Akun dibuat oleh super admin.</p>
    <?php endif; ?>
  </div>
</div>
