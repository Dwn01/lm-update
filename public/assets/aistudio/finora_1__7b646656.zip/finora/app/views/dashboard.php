<?= pending_banner() ?>
<div class="page-title-row">
  <div>
    <div class="eyebrow">Ringkasan keuangan · <?= e($rg['label']) ?></div>
    <h1>Selamat <?= e(greeting()) ?>, <?= e($first) ?></h1>
    <p>Berikut kondisi keuangan perusahaan Anda.</p>
  </div>
  <div class="title-actions">
    <form method="get" action="<?= e(url('/')) ?>" class="title-actions"><input type="hidden" name="periode" value="<?= e($periode) ?>">
      <select class="select" name="rentang" data-autosubmit aria-label="Rentang waktu">
        <?php foreach (['hari' => 'Hari ini', 'bulan' => 'Bulan', 'tahun' => 'Tahun', 'semua' => 'Semua periode'] as $k => $lbl): ?><option value="<?= e($k) ?>" <?= $rentang === $k ? 'selected' : '' ?>><?= e($lbl) ?></option><?php endforeach; ?>
      </select>
      <?php if (in_array($rentang, ['bulan', 'tahun'], true)): ?><input class="select" type="month" name="bulan" value="<?= e($ym) ?>" data-autosubmit aria-label="Bulan"><?php endif; ?>
    </form>
    <?= add_button('Tambah Transaksi', 'dlg-tx') ?>
  </div>
</div>

<?php
$renderStats = function (array $list) use ($rg) {
  foreach ($list as [$label, $value, $chg, $ic, $tone, $upGood]):
      $up = $chg === null || $chg >= 0;
      $good = $chg === null ? true : ($upGood ? $chg >= 0 : $chg <= 0); ?>
    <section class="card stat-card">
      <div class="stat-icon <?= e($tone) ?>"><?= icon($ic) ?></div>
      <div class="stat-label"><?= e($label) ?></div>
      <div class="stat-value <?= $value < 0 ? 'negative' : '' ?>"><?= e(idr($value)) ?></div>
      <?php if ($rg['vs'] !== ''): ?><div class="change <?= $good ? 'positive' : 'negative' ?>">
        <?= icon($up ? 'arrowUp' : 'arrowDown', 14) ?> <?= e(pct_text($chg)) ?>
        <span><?= e($rg['vs']) ?></span>
      </div><?php endif; ?>
    </section>
  <?php endforeach;
};
?>
<div class="stats-grid"><?php $renderStats($stats); ?></div>

<div class="stats-grid stats-grid-3">
  <?php $renderStats($stats2); ?>
  <section class="card stat-card stock-card">
    <div class="stat-icon blue"><?= icon('car') ?></div>
    <div class="stat-label">Stok Mobil</div>
    <div class="stock-grid">
      <div><small>Tersedia</small><strong><?= number_format($stock['available']) ?></strong></div>
      <div><small>Dipesan</small><strong><?= number_format($stock['reserved']) ?></strong></div>
      <div><small>Terjual<?= $rentang === 'semua' ? '' : ' (periode)' ?></small><strong><?= number_format($rentang === 'semua' ? $stock['sold'] : $sum['sold_count']) ?></strong></div>
      <div><small>Rata-rata harga beli</small><strong><?= e(idr($stock['avg'])) ?></strong></div>
    </div>
    <div class="stock-capital"><small>Nilai modal stok aktif</small><strong><?= e(idr($stock['capital'])) ?></strong></div>
    <div class="stock-hint">Ringkasan inventaris, bukan transaksi. Stok aktif = tersedia + dipesan.</div>
  </section>
</div>
<p class="def-note">Arus kas bersih = uang masuk − uang keluar. Laba kotor = harga jual aktual − harga beli mobil terjual. Laba bersih = laba kotor + pemasukan lain − biaya operasional (pembelian mobil tidak dihitung sebagai beban karena sudah menjadi harga pokok).</p>

<div class="insight-strip">
  <div>
    <span class="insight-icon blue"><?= icon('invoice') ?></span>
    <div><small>Total Piutang</small><strong><?= e(idr($inv['recv_sum'])) ?></strong></div>
    <?= badge($inv['recv_cnt'] . ' invoice', 'blue') ?>
  </div>
  <div>
    <span class="insight-icon orange"><?= icon('file') ?></span>
    <div><small>Total Utang</small><strong><?= e(idr($inv['pay_sum'])) ?></strong></div>
    <?= badge($inv['pay_overdue'] > 0 ? $inv['pay_overdue'] . ' jatuh tempo' : $inv['pay_cnt'] . ' tagihan', 'yellow') ?>
  </div>
  <div>
    <span class="insight-icon green"><?= icon('budget') ?></span>
    <div><small>Realisasi Anggaran</small><strong><?= $budPct === null ? 'Belum ada anggaran' : e(number_format($budPct, 1, ',', '.')) . '%' ?></strong></div>
    <?php if ($budPct !== null): ?><span class="mini-progress"><i style="width:<?= min(100, max(0, (float)$budPct)) ?>%"></i></span><?php endif; ?>
  </div>
</div>

<div class="charts-grid">
  <section class="card chart-card">
    <div class="card-heading">
      <div><div class="card-title">Arus Kas</div><div class="card-subtitle">Perbandingan pemasukan dan pengeluaran</div></div>
      <form method="get" action="<?= e(url('/')) ?>">
        <input type="hidden" name="bulan" value="<?= e($ym) ?>"><input type="hidden" name="rentang" value="<?= e($rentang) ?>">
        <select name="periode" class="select compact" data-autosubmit aria-label="Periode grafik">
          <option value="6" <?= $periode === '6' ? 'selected' : '' ?>>6 Bulan</option>
          <option value="12" <?= $periode === '12' ? 'selected' : '' ?>>12 Bulan</option>
          <option value="tahun" <?= $periode === 'tahun' ? 'selected' : '' ?>>Tahun <?= e(substr($ym, 0, 4)) ?></option>
        </select>
      </form>
    </div>
    <div class="legend"><span><i class="legend-dot green"></i>Pemasukan</span><span><i class="legend-dot red"></i>Pengeluaran</span></div>
    <?= chart_cashflow($series) ?>
  </section>
  <section class="card expense-card">
    <div class="card-heading"><div><div class="card-title">Rincian Pengeluaran</div><div class="card-subtitle"><?= e($rg['label']) ?></div></div></div>
    <?= chart_donut($expCats, $expTotal) ?>
  </section>
</div>

<section class="card transactions-card">
  <div class="card-heading">
    <div><div class="card-title">Transaksi Terbaru</div><div class="card-subtitle">Aktivitas keuangan terkini</div></div>
    <a class="text-button" href="<?= e(url('/transaksi')) ?>">Lihat semua <?= icon('chevron', 16) ?></a>
  </div>
  <?= tx_table($recent, false, $pending) ?>
</section>

<?= tx_dialog() ?>
