<?= pending_banner() ?>
<div class="page-title-row">
  <div><h1>Piutang &amp; Utang</h1><p>Pantau tagihan masuk, invoice, dan jadwal pembayaran.</p></div>
  <?= add_button('Buat Invoice / Tagihan', 'dlg-inv', ['issue_date' => today(), 'due_date' => date('Y-m-d', strtotime('+14 days'))]) ?>
</div>

<div class="summary-grid">
  <section class="card"><small>Piutang Aktif</small><strong><?= e(idr($inv['recv_sum'])) ?></strong><span class="muted"><?= (int)$inv['recv_cnt'] ?> invoice belum dibayar</span></section>
  <section class="card"><small>Utang Berjalan</small><strong><?= e(idr($inv['pay_sum'])) ?></strong><span class="muted"><?= (int)$inv['pay_cnt'] ?> tagihan belum dibayar</span></section>
  <section class="card"><small>Jatuh Tempo ≤ 7 Hari (termasuk lewat)</small><strong><?= e(idr($inv['soon_sum'])) ?></strong><span class="negative"><?= (int)($inv['recv_overdue'] + $inv['pay_overdue']) ?> sudah lewat jatuh tempo</span></section>
</div>

<section class="card page-card">
  <div class="tabbar">
    <a class="<?= $tab === 'semua' ? 'active' : '' ?>" href="<?= e(url('/piutang-utang')) ?>">Semua</a>
    <a class="<?= $tab === 'piutang' ? 'active' : '' ?>" href="<?= e(url('/piutang-utang?tab=piutang')) ?>">Piutang</a>
    <a class="<?= $tab === 'utang' ? 'active' : '' ?>" href="<?= e(url('/piutang-utang?tab=utang')) ?>">Utang</a>
  </div>
  <div class="table-wrap"><table>
    <thead><tr><th>Nomor</th><th>Jenis</th><th>Kontak</th><th>Jatuh tempo</th><th class="t-right">Jumlah</th><th>Status</th><?php if (can_write()): ?><th class="actions"></th><?php endif; ?></tr></thead>
    <tbody>
    <?php foreach ($list as $i):
        [$stLabel, $stTone] = invoice_status($i);
        $row = ['id' => (int)$i['id'], 'kind' => $i['kind'], 'number' => $i['number'], 'contact_name' => $i['contact_name'], 'issue_date' => $i['issue_date'],
                'due_date' => $i['due_date'], 'amount' => (int)$i['amount'], 'status' => $i['status'], 'note' => $i['note']];
        $pend = $pending[(int)$i['id']] ?? null; ?>
      <tr>
        <td><strong><?= e($i['number']) ?></strong></td>
        <td><?= badge($i['kind'] === 'receivable' ? 'Piutang' : 'Utang', $i['kind'] === 'receivable' ? 'blue' : 'purple') ?></td>
        <td><?= e($i['contact_name']) ?></td>
        <td><?= e(date_id($i['due_date'])) ?></td>
        <td class="t-right"><strong><?= e(idr($i['amount'])) ?></strong></td>
        <td><?= badge($stLabel, $stTone) ?><?= pending_chip($pend) ?></td>
        <?php if (can_write()): ?>
        <td class="actions">
          <div class="row-actions">
            <?php if ($i['status'] === 'unpaid' && !$pend): ?>
              <form method="post" action="<?= e(url('/aksi')) ?>" data-confirm="<?= e(is_super() ? 'Tandai lunas?' : 'Ajukan penandaan lunas? Perlu persetujuan super admin.') ?>">
                <?= action_fields('invoice', 'update') ?><input type="hidden" name="id" value="<?= (int)$i['id'] ?>">
                <?php foreach (['kind', 'number', 'contact_name', 'issue_date', 'due_date', 'amount', 'note'] as $f): ?><input type="hidden" name="<?= e($f) ?>" value="<?= e($row[$f]) ?>"><?php endforeach; ?>
                <input type="hidden" name="status" value="paid">
                <button type="submit" title="Tandai lunas"><?= icon('check', 17) ?></button>
              </form>
            <?php endif; ?>
          </div>
          <?= row_actions('invoice', 'dlg-inv', $row, (bool)$pend) ?>
        </td>
        <?php endif; ?>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  <?php if (!$list): ?><div class="empty-state">Belum ada data.</div><?php endif; ?></div>
</section>

<?php if (can_write()): ?>
<dialog class="modal" id="dlg-inv">
  <?= modal_head('Buat Invoice / Tagihan', 'Edit Invoice / Tagihan', 'Piutang (invoice ke pelanggan) atau utang (tagihan dari pemasok)') ?>
  <form method="post" action="<?= e(url('/aksi')) ?>">
    <?= action_fields('invoice', 'create') ?><input type="hidden" name="id" value="">
    <?= approval_note() ?>
    <div class="form-grid">
      <label class="field">Jenis<select name="kind" required><option value="receivable">Piutang (invoice)</option><option value="payable">Utang (tagihan)</option></select></label>
      <label class="field">Nomor<input type="text" name="number" maxlength="40" placeholder="Kosongkan untuk otomatis"></label>
      <label class="field full">Kontak<input type="text" name="contact_name" required maxlength="150" placeholder="Nama pelanggan / pemasok"></label>
      <label class="field">Tanggal terbit<input type="date" name="issue_date" required value="<?= e(today()) ?>"></label>
      <label class="field">Jatuh tempo<input type="date" name="due_date" required value="<?= e(date('Y-m-d', strtotime('+14 days'))) ?>"></label>
      <label class="field">Jumlah (Rp)<input type="number" name="amount" required min="1" step="1" inputmode="numeric" placeholder="0"></label>
      <label class="field">Status<select name="status" required><option value="unpaid">Belum dibayar</option><option value="paid">Lunas</option></select></label>
      <label class="field full">Catatan<textarea name="note" maxlength="500"></textarea></label>
    </div>
    <div class="modal-actions"><button type="button" class="secondary-button" data-close>Batal</button><button class="primary-button" type="submit"><?= e(submit_label()) ?></button></div>
  </form>
</dialog>
<?php endif; ?>
