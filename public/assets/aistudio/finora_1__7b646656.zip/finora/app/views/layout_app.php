<?php
/** @var string $content */
/** @var string $title */
/** @var string $active */
$u = current_user();
$admin = is_admin_mode();
$company = settings_all()['company_name'] ?? 'LM Finance';
$pendingN = $admin ? pending_total() : pending_mine((int)$u['id']);
$nav = nav_items();
$extra = [];
if ($admin) {
    $extra[] = ['/persetujuan', 'Persetujuan', 'check', $pendingN];
    $extra[] = ['/pengguna', 'Pengguna', 'users', 0];
    $extra[] = ['/audit', 'Log Audit', 'list', 0];
    $extra[] = ['/keamanan', 'Keamanan', 'shield', 0];
} else {
    $extra[] = ['/permintaan', 'Permintaan Saya', 'inbox', $pendingN];
}
$crumb = $title !== '' ? $title : 'Dashboard';
?><!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title><?= e($crumb) ?> · <?= e(cfg('app_name', 'LM Finance')) ?><?= $admin ? ' Admin' : '' ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&display=swap">
<link rel="stylesheet" href="<?= e(url('/assets/app.css')) ?>">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect width='32' height='32' rx='9' fill='%23126b50'/%3E%3Ctext x='16' y='23' font-size='20' font-family='Arial' font-weight='800' text-anchor='middle' fill='white'%3EF%3C/text%3E%3C/svg%3E">
</head>
<body class="<?= $admin ? 'mode-admin' : 'mode-user' ?>">
<div class="app-shell">
  <aside class="sidebar" id="sidebar">
    <div class="brand">
      <div class="brand-mark">F</div>
      <div class="brand-copy"><strong><?= e(cfg('app_name', 'LM Finance')) ?></strong><span><?= $admin ? 'Panel Super Admin' : 'Business Finance' ?></span></div>
      <button class="mobile-close icon-button" type="button" data-action="close-menu" aria-label="Tutup menu"><?= icon('close') ?></button>
    </div>
    <nav>
      <?php foreach ($nav as [$path, $label, $ic]): ?>
        <a href="<?= e(url($path)) ?>" class="<?= $active === $path ? 'active' : '' ?>" title="<?= e($label) ?>"><?= icon($ic) ?><span><?= e($label) ?></span></a>
      <?php endforeach; ?>
      <div class="nav-sep"><span><?= $admin ? 'Administrasi' : 'Persetujuan' ?></span></div>
      <?php foreach ($extra as [$path, $label, $ic, $count]): ?>
        <a href="<?= e(url($path)) ?>" class="<?= $active === $path ? 'active' : '' ?>" title="<?= e($label) ?>"><?= icon($ic) ?><span><?= e($label) ?></span><?php if ($count > 0): ?><i class="nav-count"><?= (int)$count ?></i><?php endif; ?></a>
      <?php endforeach; ?>
    </nav>
    <div class="sidebar-help"><div>?</div><strong>Butuh bantuan?</strong><span><?= $admin ? 'Hubungi pengembang sistem' : 'Hubungi super admin Anda' ?></span></div>
    <button class="collapse-button" type="button" data-action="collapse" aria-label="Ciutkan menu"><?= icon('chevron') ?><span>Ciutkan menu</span></button>
  </aside>
  <div class="mobile-overlay" data-action="close-menu"></div>
  <div class="main-area">
    <header>
      <div class="header-left">
        <button class="menu-button icon-button" type="button" data-action="open-menu" aria-label="Buka menu"><?= icon('menu') ?></button>
        <div class="breadcrumb"><span><?= e($company) ?></span><?= icon('chevron', 14) ?><strong><?= e($crumb) ?></strong></div>
      </div>
      <div class="header-actions">
        <form class="header-search" method="get" action="<?= e(url('/transaksi')) ?>"><?= icon('search', 18) ?><input name="q" placeholder="Cari transaksi..." aria-label="Cari transaksi" maxlength="80"></form>
        <a class="icon-button notification" href="<?= e(url($admin ? '/persetujuan' : '/permintaan')) ?>" title="<?= $admin ? 'Permintaan menunggu persetujuan' : 'Permintaan saya' ?>"><?= icon('bell') ?><?php if ($pendingN > 0): ?><i></i><?php endif; ?></a>
        <details class="profile-menu">
          <summary class="profile">
            <div class="avatar"><?= e(initials($u['name'])) ?></div>
            <div><strong><?= e($u['name']) ?></strong><span><?= e(ROLE_LABELS[$u['role']] ?? $u['role']) ?></span></div>
            <?= icon('chevron', 15) ?>
          </summary>
          <div class="menu-pop">
            <a href="<?= e(url('/keamanan')) ?>"><?= icon('shield', 17) ?> Keamanan akun</a>
            <form method="post" action="<?= e(url('/keluar')) ?>"><?= csrf_field() ?><button type="submit"><?= icon('logout', 17) ?> Keluar</button></form>
          </div>
        </details>
      </div>
    </header>
    <main>
      <?php foreach (flashes() as $f): ?>
        <div class="flash flash-<?= e($f['type']) ?>" role="status"><?= e($f['msg']) ?></div>
      <?php endforeach; ?>
      <?= $content ?>
    </main>
    <nav class="mobile-nav">
      <?php foreach (array_slice($nav, 0, 4) as [$path, $label, $ic]): ?>
        <a href="<?= e(url($path)) ?>" class="<?= $active === $path ? 'active' : '' ?>"><?= icon($ic) ?><span><?= e($label) ?></span></a>
      <?php endforeach; ?>
      <button type="button" data-action="open-menu"><?= icon('menu') ?><span>Lainnya</span></button>
    </nav>
  </div>
</div>
<script src="<?= e(url('/assets/app.js')) ?>" defer></script>
</body>
</html>
