<?php
/** @var string $content */
/** @var string $title */
$admin = defined('APP_MODE') && APP_MODE === 'admin';
?><!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title><?= e($title) ?> · <?= e(cfg('app_name', 'LM Finance')) ?></title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&display=swap">
<link rel="stylesheet" href="<?= e(url('/assets/app.css')) ?>">
<?= $extra_head ?? '' ?>
</head>
<body class="bare <?= $admin ? 'mode-admin' : 'mode-user' ?>" <?= $body_attr ?? '' ?>>
<?= $content ?>
<script src="<?= e(url('/assets/app.js')) ?>" defer></script>
</body>
</html>
