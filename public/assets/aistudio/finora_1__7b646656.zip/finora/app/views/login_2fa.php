<div class="auth-wrap">
  <div class="auth-card">
    <div class="center"><div class="brand-mark big"><?= icon('shield', 28) ?></div></div>
    <h1>Verifikasi dua langkah</h1>
    <p class="sub center">Masukkan 6 digit kode dari aplikasi autentikator Anda.</p>
    <?php foreach (flashes() as $f): ?>
      <div class="flash flash-<?= e($f['type']) ?>" role="status"><?= e($f['msg']) ?></div>
    <?php endforeach; ?>
    <form method="post" action="<?= e(url('/masuk/2fa')) ?>" class="form-stack">
      <?= csrf_field() ?>
      <input class="otp-input" type="text" name="code" inputmode="numeric" pattern="[0-9 ]{6,7}" maxlength="7" autocomplete="one-time-code" required autofocus placeholder="000000">
      <button class="primary-button" type="submit">Verifikasi</button>
    </form>
    <p class="center" style="margin-top:16px"><a class="muted" href="<?= e(url('/masuk')) ?>" style="font-size:12px;text-decoration:underline">Kembali ke halaman masuk</a></p>
  </div>
</div>
