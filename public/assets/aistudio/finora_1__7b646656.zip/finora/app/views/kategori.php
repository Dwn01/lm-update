<?= pending_banner() ?>
<div class="page-title-row">
  <div><h1>Kategori</h1><p>Atur kategori pemasukan dan pengeluaran sesuai kebutuhan.</p></div>
  <div class="title-actions">
    <form method="get" action="<?= e(url('/kategori')) ?>"><input class="select" type="month" name="bulan" value="<?= e($ym) ?>" data-autosubmit aria-label="Bulan"></form>
    <?= add_button('Tambah Kategori', 'dlg-cat') ?>
  </div>
</div>

<?php if (!$cats): ?>
  <section class="card"><div class="empty-state">Belum ada kategori.</div></section>
<?php else: ?>
<div class="category-grid">
  <?php foreach ($cats as $c):
      $row = ['id' => (int)$c['id'], 'name' => $c['name'], 'type' => $c['type'], 'color' => $c['color']]; ?>
    <section class="card category-card">
      <span class="category-dot <?= e($c['color']) ?>"></span>
      <div class="card-corner"><?= row_actions('category', 'dlg-cat', $row, isset($pending[(int)$c['id']]), 'row-actions') ?></div>
      <div class="cat-head"><strong><?= e($c['name']) ?></strong><?= badge($c['type'] === 'income' ? 'Pemasukan' : 'Pengeluaran', $c['type'] === 'income' ? 'green' : 'red') ?></div>
      <small>Realisasi <?= e(month_label($ym)) ?><?= pending_chip($pending[(int)$c['id']] ?? null) ?></small>
      <b><?= e(idr($c['total'])) ?></b>
    </section>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<?php if (can_write()): ?>
<dialog class="modal" id="dlg-cat">
  <?= modal_head('Tambah Kategori', 'Edit Kategori', 'Kelompokkan pemasukan dan pengeluaran') ?>
  <form method="post" action="<?= e(url('/aksi')) ?>">
    <?= action_fields('category', 'create') ?><input type="hidden" name="id" value="">
    <?= approval_note() ?>
    <label class="field">Nama kategori<input type="text" name="name" required maxlength="80" placeholder="Contoh: Penjualan"></label>
    <div class="form-grid">
      <label class="field">Jenis<select name="type" required><option value="income">Pemasukan</option><option value="expense">Pengeluaran</option></select></label>
      <label class="field">Warna<select name="color" required><?php foreach (COLORS as $k => $lbl): ?><option value="<?= e($k) ?>"><?= e($lbl) ?></option><?php endforeach; ?></select></label>
    </div>
    <div class="modal-actions"><button type="button" class="secondary-button" data-close>Batal</button><button class="primary-button" type="submit"><?= e(submit_label()) ?></button></div>
  </form>
</dialog>
<?php endif; ?>
