<div class="page-title-row">
  <div><h1>Log Audit</h1><p>Catatan login, pengajuan, persetujuan, dan perubahan data. Tidak dapat diubah dari aplikasi.</p></div>
</div>
<section class="card page-card">
  <div class="toolbar">
    <form method="get" action="<?= e(url('/audit')) ?>">
      <label class="search-field"><?= icon('search', 18) ?><input name="q" value="<?= e($q) ?>" placeholder="Cari aksi, pengguna, IP..." maxlength="60"></label>
      <div class="filter-group"><button class="secondary-button" type="submit"><?= icon('filter', 17) ?> Cari</button><?php if ($q !== ''): ?><a class="secondary-button" href="<?= e(url('/audit')) ?>">Reset</a><?php endif; ?></div>
    </form>
  </div>
  <div class="table-wrap"><table>
    <thead><tr><th>Waktu</th><th>Pengguna</th><th>Aksi</th><th>Detail</th><th>IP</th></tr></thead>
    <tbody>
    <?php foreach ($list as $l):
        $bad = str_contains($l['action'], 'gagal') || str_contains($l['action'], 'blocked') || $l['action'] === 'tolak'; ?>
      <tr>
        <td><?= e(datetime_id($l['created_at'])) ?></td>
        <td><?= e($l['username'] ?? '-') ?></td>
        <td><?= badge($l['action'], $bad ? 'red' : 'neutral') ?></td>
        <td class="wrap"><?= e($l['detail']) ?></td>
        <td><?= e($l['ip']) ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  <?php if (!$list): ?><div class="empty-state">Belum ada catatan.</div><?php endif; ?></div>
  <div class="table-footer">
    <span><?= (int)$total ?> catatan</span>
    <?php if ($pages > 1): ?>
    <div class="pager">
      <?php if ($page > 1): ?><a href="<?= e(pagination_url(['page' => $page - 1])) ?>">←</a><?php else: ?><span class="off">←</span><?php endif; ?>
      <span><?= (int)$page ?> / <?= (int)$pages ?></span>
      <?php if ($page < $pages): ?><a href="<?= e(pagination_url(['page' => $page + 1])) ?>">→</a><?php else: ?><span class="off">→</span><?php endif; ?>
    </div>
    <?php endif; ?>
  </div>
</section>
