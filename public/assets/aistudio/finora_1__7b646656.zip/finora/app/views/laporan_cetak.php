<div class="print-bar">
  <button type="button" class="primary-button" data-print-now>Cetak / Simpan sebagai PDF</button>
</div>
<div class="print-page">
  <div class="print-head">
    <div>
      <h1>Laporan Keuangan</h1>
      <div class="muted"><?= e($company['company_name']) ?><?= $company['npwp'] !== '' ? ' · NPWP ' . e($company['npwp']) : '' ?></div>
      <div class="muted">Periode: <?= e(month_label($from)) ?> – <?= e(month_label($to)) ?></div>
    </div>
    <div class="muted" style="text-align:right;font-size:12px">Dicetak <?= e(datetime_id(now_sql())) ?></div>
  </div>

  <div class="summary-grid" style="grid-template-columns:repeat(3,1fr)">
    <div class="card"><small>Pendapatan</small><strong><?= e(idr($r['income'])) ?></strong></div>
    <div class="card"><small>Biaya &amp; Pengeluaran</small><strong><?= e(idr($r['expense'])) ?></strong></div>
    <div class="card"><small>Arus Kas Bersih</small><strong><?= e(idr($r['profit'])) ?></strong></div>
  </div>

  <h2>Ringkasan bulanan</h2>
  <table>
    <thead><tr><th>Bulan</th><th class="t-right">Pemasukan</th><th class="t-right">Pengeluaran</th><th class="t-right">Arus kas bersih</th></tr></thead>
    <tbody>
    <?php foreach ($r['months'] as $i => $m): $p = $r['series']['income'][$i] - $r['series']['expense'][$i]; ?>
      <tr><td><?= e(month_label($m)) ?></td><td class="t-right"><?= e(idr($r['series']['income'][$i])) ?></td><td class="t-right"><?= e(idr($r['series']['expense'][$i])) ?></td><td class="t-right"><?= e(idr($p)) ?></td></tr>
    <?php endforeach; ?>
    </tbody>
  </table>

  <h2>Per kategori</h2>
  <table>
    <thead><tr><th>Kategori</th><th>Jenis</th><th class="t-right">Total</th></tr></thead>
    <tbody>
    <?php foreach ($r['cats'] as $c): ?>
      <tr><td><?= e($c['name']) ?></td><td><?= $c['type'] === 'income' ? 'Pemasukan' : 'Pengeluaran' ?></td><td class="t-right"><?= e(idr($c['s'])) ?></td></tr>
    <?php endforeach; ?>
    </tbody>
  </table>

  <h2>Daftar transaksi (<?= count($tx) ?>)</h2>
  <table>
    <thead><tr><th>Tanggal</th><th>Nama</th><th>Kategori</th><th>Akun</th><th class="t-right">Jumlah</th></tr></thead>
    <tbody>
    <?php foreach ($tx as $t): ?>
      <tr><td><?= e(date_id($t['tx_date'])) ?></td><td><?= e($t['name']) ?></td><td><?= e($t['category_name']) ?></td><td><?= e($t['account_name']) ?></td>
        <td class="t-right"><?= $t['type'] === 'income' ? '+' : '-' ?><?= e(idr($t['amount'])) ?></td></tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
