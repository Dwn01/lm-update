<?php
$qs = http_build_query(['dari' => $from, 'sampai' => $to]);
?>
<div class="page-title-row">
  <div><h1>Laporan</h1><p>Tinjau dan unduh laporan keuangan perusahaan.</p></div>
  <div class="title-actions">
    <a class="secondary-button" href="<?= e(url('/laporan/export?' . $qs . '&format=csv')) ?>"><?= icon('download', 17) ?> CSV</a>
    <a class="secondary-button" href="<?= e(url('/laporan/export?' . $qs . '&format=xlsx')) ?>"><?= icon('download', 17) ?> Excel</a>
    <a class="primary-button" href="<?= e(url('/laporan/cetak?' . $qs)) ?>" target="_blank" rel="noopener"><?= icon('print', 18) ?> Ekspor PDF</a>
  </div>
</div>

<section class="card" style="padding:16px 18px;margin-bottom:14px">
  <form method="get" action="<?= e(url('/laporan')) ?>" class="filter-group">
    <label class="field" style="flex-direction:row;align-items:center;gap:8px">Dari <input class="select" type="month" name="dari" value="<?= e($from) ?>" required style="width:auto"></label>
    <label class="field" style="flex-direction:row;align-items:center;gap:8px">Sampai <input class="select" type="month" name="sampai" value="<?= e($to) ?>" required style="width:auto"></label>
    <button class="secondary-button" type="submit"><?= icon('calendar', 17) ?> Terapkan</button>
  </form>
</section>

<div class="summary-grid">
  <section class="card"><small>Pendapatan</small><strong><?= e(idr($r['income'])) ?></strong><span class="muted"><?= e(month_label($from)) ?> – <?= e(month_label($to)) ?></span></section>
  <section class="card"><small>Biaya &amp; Pengeluaran</small><strong><?= e(idr($r['expense'])) ?></strong><span class="negative"><?= $r['income'] > 0 ? e(number_format($r['expense'] / $r['income'] * 100, 1, ',', '.')) . '% dari pendapatan' : '-' ?></span></section>
  <section class="card"><small>Arus Kas Bersih</small><strong class="<?= $r['profit'] < 0 ? 'negative' : '' ?>"><?= e(idr($r['profit'])) ?></strong><span class="<?= $r['profit'] >= 0 ? 'positive' : 'negative' ?>"><?= $r['income'] > 0 ? 'Margin ' . e(number_format($r['profit'] / $r['income'] * 100, 1, ',', '.')) . '%' : '-' ?></span></section>
</div>

<div class="charts-grid">
  <section class="card chart-card">
    <div class="card-heading"><div><div class="card-title">Arus Kas</div><div class="card-subtitle"><?= e(month_label($from)) ?> – <?= e(month_label($to)) ?></div></div></div>
    <div class="legend"><span><i class="legend-dot green"></i>Pemasukan</span><span><i class="legend-dot red"></i>Pengeluaran</span></div>
    <?= chart_cashflow($r['series']) ?>
  </section>
  <section class="card page-card">
    <div class="card-heading"><div><div class="card-title">Per Kategori</div><div class="card-subtitle">Total pada periode terpilih</div></div></div>
    <div class="table-wrap"><table>
      <thead><tr><th>Kategori</th><th>Jenis</th><th class="t-right">Total</th></tr></thead>
      <tbody>
      <?php foreach ($r['cats'] as $c): ?>
        <tr><td><strong><?= e($c['name']) ?></strong></td><td><?= badge($c['type'] === 'income' ? 'Pemasukan' : 'Pengeluaran', $c['type'] === 'income' ? 'green' : 'red') ?></td><td class="t-right"><?= e(idr($c['s'])) ?></td></tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <?php if (!$r['cats']): ?><div class="empty-state">Belum ada transaksi pada periode ini.</div><?php endif; ?></div>
  </section>
</div>

<section class="card page-card">
  <div class="card-heading"><div><div class="card-title">Ringkasan Bulanan</div><div class="card-subtitle">Pemasukan, pengeluaran, dan laba bersih</div></div></div>
  <div class="table-wrap"><table>
    <thead><tr><th>Bulan</th><th class="t-right">Pemasukan</th><th class="t-right">Pengeluaran</th><th class="t-right">Arus kas bersih</th></tr></thead>
    <tbody>
    <?php foreach ($r['months'] as $i => $m):
        $p = $r['series']['income'][$i] - $r['series']['expense'][$i]; ?>
      <tr><td><strong><?= e(month_label($m)) ?></strong></td><td class="t-right amount-in"><?= e(idr($r['series']['income'][$i])) ?></td><td class="t-right amount-out"><?= e(idr($r['series']['expense'][$i])) ?></td><td class="t-right"><strong class="<?= $p < 0 ? 'negative' : '' ?>"><?= e(idr($p)) ?></strong></td></tr>
    <?php endforeach; ?>
      <tr><td><strong>Total</strong></td><td class="t-right"><strong><?= e(idr($r['income'])) ?></strong></td><td class="t-right"><strong><?= e(idr($r['expense'])) ?></strong></td><td class="t-right"><strong class="<?= $r['profit'] < 0 ? 'negative' : '' ?>"><?= e(idr($r['profit'])) ?></strong></td></tr>
    </tbody>
  </table></div>
</section>
