<div class="auth-wrap">
  <div class="auth-card" style="text-align:center">
    <div class="brand-mark big">F</div>
    <h1 style="margin:18px 0 6px"><?= (int)$code ?></h1>
    <p class="muted"><?= e($message) ?></p>
    <p style="margin-top:22px"><a class="primary-button" href="<?= e(url('/')) ?>">Kembali ke beranda</a></p>
  </div>
</div>
