<div class="page-title-row">
  <div><h1>Pengaturan</h1><p>Kelola profil perusahaan dan keamanan akun.</p></div>
</div>
<?= pending_banner() ?>
<div class="settings-layout">
  <nav class="card settings-nav">
    <a class="active" href="<?= e(url('/pengaturan')) ?>"><?= icon('settings', 17) ?> Profil Perusahaan</a>
    <a href="<?= e(url('/keamanan')) ?>"><?= icon('shield', 17) ?> Keamanan Akun</a>
    <?php if (is_admin_mode()): ?>
      <a href="<?= e(url('/pengguna')) ?>"><?= icon('users', 17) ?> Pengguna &amp; Peran</a>
      <a href="<?= e(url('/audit')) ?>"><?= icon('list', 17) ?> Log Audit</a>
    <?php endif; ?>
  </nav>
  <section class="card settings-form">
    <div class="card-title">Profil Perusahaan</div>
    <div class="logo-upload"><div><?= e(initials($s['company_name'])) ?></div><span class="muted" style="font-size:12px">Inisial dibuat otomatis dari nama perusahaan.</span></div>
    <?php if ($pendingSettings && !is_super()): ?>
      <div class="notice"><span>Ada perubahan profil yang masih menunggu persetujuan super admin.</span></div>
    <?php endif; ?>
    <form method="post" action="<?= e(url('/aksi')) ?>" class="form-stack">
      <?= action_fields('settings', 'update', url('/pengaturan')) ?>
      <?= approval_note() ?>
      <div class="form-grid">
        <label class="field">Nama perusahaan<input name="company_name" required maxlength="120" value="<?= e($s['company_name']) ?>" <?= can_write() ? '' : 'readonly' ?>></label>
        <label class="field">NPWP<input name="npwp" maxlength="30" value="<?= e($s['npwp']) ?>" <?= can_write() ? '' : 'readonly' ?>></label>
        <label class="field">Email perusahaan<input type="email" name="email" maxlength="150" value="<?= e($s['email']) ?>" <?= can_write() ? '' : 'readonly' ?>></label>
        <label class="field">Nomor telepon<input name="phone" maxlength="30" value="<?= e($s['phone']) ?>" <?= can_write() ? '' : 'readonly' ?>></label>
        <label class="field full">Alamat<textarea name="address" maxlength="300" <?= can_write() ? '' : 'readonly' ?>><?= e($s['address']) ?></textarea></label>
      </div>
      <?php if (can_write()): ?>
      <div class="form-actions"><button class="primary-button" type="submit"><?= e(submit_label('Simpan Perubahan')) ?></button></div>
      <?php endif; ?>
    </form>
  </section>
</div>
