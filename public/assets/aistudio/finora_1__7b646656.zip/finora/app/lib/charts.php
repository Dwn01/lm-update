<?php
declare(strict_types=1);

/** Grafik berbasis SVG/CSS murni (tanpa library JS atau CDN). */

function chart_scale(float $max): array
{
    if ($max <= 0) {
        return [4000000.0, 1000000.0];
    }
    $raw = $max / 4;
    $mag = 10 ** floor(log10($raw));
    $n = $raw / $mag;
    $step = ($n <= 1 ? 1 : ($n <= 2 ? 2 : ($n <= 5 ? 5 : 10))) * $mag;
    return [$step * 4, $step];
}

function smooth_path(array $pts): string
{
    if (!$pts) {
        return '';
    }
    $d = sprintf('M%.1f %.1f', $pts[0][0], $pts[0][1]);
    for ($i = 1; $i < count($pts); $i++) {
        $dx = ($pts[$i][0] - $pts[$i - 1][0]) / 2;
        $d .= sprintf(' C%.1f %.1f %.1f %.1f %.1f %.1f', $pts[$i - 1][0] + $dx, $pts[$i - 1][1], $pts[$i][0] - $dx, $pts[$i][1], $pts[$i][0], $pts[$i][1]);
    }
    return $d;
}

function chart_cashflow(array $s): string
{
    $months = $s['months'];
    $n = count($months);
    if ($n === 0) {
        return '';
    }
    $max = max(1, ...$s['income'], ...$s['expense']);
    [$top] = chart_scale((float)$max);
    $W = 620;
    $H = 200;
    $y0 = 10;
    $y1 = 198;
    $yOf = fn($v) => $y1 - ($v / $top) * ($y1 - $y0);
    $xOf = fn($i) => ($i + 0.5) / $n * $W;

    $pi = [];
    $pe = [];
    for ($i = 0; $i < $n; $i++) {
        $pi[] = [$xOf($i), $yOf($s['income'][$i])];
        $pe[] = [$xOf($i), $yOf($s['expense'][$i])];
    }
    $lineI = smooth_path($pi);
    $lineE = smooth_path($pe);

    $svg = '<svg viewBox="0 0 ' . $W . ' ' . $H . '" preserveAspectRatio="none" role="img" aria-label="Grafik arus kas">';
    $svg .= '<defs><linearGradient id="gArea" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#16a777" stop-opacity=".16"/><stop offset="1" stop-color="#16a777" stop-opacity="0"/></linearGradient></defs>';
    for ($k = 0; $k <= 4; $k++) {
        $y = $y0 + ($y1 - $y0) / 4 * $k;
        $svg .= '<line x1="0" y1="' . round($y, 1) . '" x2="' . $W . '" y2="' . round($y, 1) . '" stroke="#e8ecea" stroke-dasharray="4 5" vector-effect="non-scaling-stroke"/>';
    }
    if ($n > 1) {
        $svg .= '<path d="' . $lineI . sprintf(' L%.1f %d L%.1f %d Z', $pi[$n - 1][0], $y1, $pi[0][0], $y1) . '" fill="url(#gArea)"/>';
    }
    $svg .= '<path d="' . $lineI . '" fill="none" stroke="#149e70" stroke-width="3" vector-effect="non-scaling-stroke" stroke-linejoin="round"/>';
    $svg .= '<path d="' . $lineE . '" fill="none" stroke="#ed635c" stroke-width="2.5" stroke-dasharray="7 5" vector-effect="non-scaling-stroke" stroke-linejoin="round"/>';
    for ($i = 0; $i < $n; $i++) {
        $label = month_label($months[$i]);
        $svg .= sprintf('<path d="M%.1f %.1f h0" stroke="#149e70" stroke-width="10" stroke-linecap="round" vector-effect="non-scaling-stroke"><title>%s - Pemasukan %s</title></path>', $pi[$i][0], $pi[$i][1], e($label), e(idr($s['income'][$i])));
        $svg .= sprintf('<path d="M%.1f %.1f h0" stroke="#fff" stroke-width="4" stroke-linecap="round" vector-effect="non-scaling-stroke"/>', $pi[$i][0], $pi[$i][1]);
        $svg .= sprintf('<path d="M%.1f %.1f h0" stroke="#ed635c" stroke-width="8" stroke-linecap="round" vector-effect="non-scaling-stroke"><title>%s - Pengeluaran %s</title></path>', $pe[$i][0], $pe[$i][1], e($label), e(idr($s['expense'][$i])));
        $svg .= sprintf('<path d="M%.1f %.1f h0" stroke="#fff" stroke-width="3" stroke-linecap="round" vector-effect="non-scaling-stroke"/>', $pe[$i][0], $pe[$i][1]);
    }
    $svg .= '</svg>';

    $ylab = '';
    for ($k = 0; $k <= 4; $k++) {
        $v = $top - $top / 4 * $k;
        $y = $y0 + ($y1 - $y0) / 4 * $k;
        $ylab .= '<span style="top:' . round($y, 1) . 'px">' . e(idr_short($v)) . '</span>';
    }
    $xl = '';
    foreach ($months as $m) {
        $xl .= '<span>' . e(month_label($m, true)) . '</span>';
    }

    return '<div class="line-chart"><div class="y-labels">' . $ylab . '</div>' . $svg
        . '<div class="x-labels" style="grid-template-columns:repeat(' . $n . ',1fr)">' . $xl . '</div></div>';
}

function chart_donut(array $items, int $total, string $centerLabel = 'Total'): string
{
    if ($total <= 0 || !$items) {
        return '<div class="empty-state">Belum ada pengeluaran pada periode ini.</div>';
    }
    $colors = ['#168060', '#5b85c5', '#efb45f', '#dc7770'];
    $top = array_slice($items, 0, 3);
    $rest = array_sum(array_column(array_slice($items, 3), 'amount'));
    $parts = [];
    foreach ($top as $it) {
        $parts[] = [$it['name'], $it['amount']];
    }
    if ($rest > 0) {
        $parts[] = ['Lainnya', $rest];
    }
    $acc = 0.0;
    $stops = [];
    $legend = '';
    foreach ($parts as $i => [$name, $amt]) {
        $p = $amt / $total * 100;
        $stops[] = $colors[$i] . ' ' . round($acc, 2) . '% ' . round($acc + $p, 2) . '%';
        $acc += $p;
        $legend .= '<div><i style="background:' . $colors[$i] . '"></i><span>' . e($name) . '</span><strong>' . round($p) . '%</strong></div>';
    }
    return '<div class="donut-wrap"><div class="donut" style="background:conic-gradient(' . implode(',', $stops) . ')">'
        . '<div><strong>' . e(idr_short($total)) . '</strong><span>' . e($centerLabel) . '</span></div></div>'
        . '<div class="donut-legend">' . $legend . '</div></div>';
}

function chart_bars(array $months, array $values): string
{
    $max = max(1, ...array_map('abs', $values));
    $h = '<div class="bar-chart">';
    foreach ($months as $i => $m) {
        $v = $values[$i];
        $pct = max(4, (int)round(abs($v) / $max * 100));
        $cls = $v < 0 ? ' class="neg"' : '';
        $h .= '<div><i' . $cls . ' style="height:' . $pct . '%" title="' . e(month_label($m) . ': ' . idr($v)) . '"></i><span>' . e(month_label($m, true)) . '</span></div>';
    }
    return $h . '</div>';
}
