<?php
declare(strict_types=1);

/**
 * Render sebuah view (app/views/{name}.php) di dalam layout.
 * $opts: layout (default 'app'), title, active (path menu aktif)
 */
function view_page(string $name, array $data = [], array $opts = []): string
{
    $render = function (string $file, array $vars): string {
        extract($vars, EXTR_SKIP);
        ob_start();
        require $file;
        return (string)ob_get_clean();
    };
    $content = $render(APP_ROOT . '/app/views/' . $name . '.php', $data);
    $layout = $opts['layout'] ?? 'app';
    if ($layout === 'none') {
        return $content;
    }
    return $render(APP_ROOT . '/app/views/layout_' . $layout . '.php', [
        'content' => $content,
        'title'   => $opts['title'] ?? '',
        'active'  => $opts['active'] ?? '',
        'extra_head' => $opts['extra_head'] ?? '',
        'body_attr' => $opts['body_attr'] ?? '',
    ]);
}

function render(string $name, array $data = [], array $opts = []): void
{
    echo view_page($name, $data, $opts);
}

/** Navigasi sidebar. */
function nav_items(): array
{
    $items = [
        ['/', 'Dashboard', 'grid'],
        ['/transaksi', 'Transaksi', 'swap'],
        ['/stok-mobil', 'Stok Mobil', 'car'],
        ['/kategori', 'Kategori', 'tag'],
        ['/analitik', 'Analitik', 'chart'],
        ['/laporan', 'Laporan', 'file'],
        ['/akun', 'Akun', 'wallet'],
        ['/piutang-utang', 'Piutang & Utang', 'invoice'],
        ['/anggaran', 'Anggaran', 'budget'],
        ['/pengaturan', 'Pengaturan', 'settings'],
    ];
    return $items;
}

function badge(string $text, string $tone = 'neutral'): string
{
    return '<span class="badge badge-' . e($tone) . '">' . e($text) . '</span>';
}

function pagination_url(array $overrides): string
{
    $q = array_merge($_GET, $overrides);
    foreach ($q as $k => $v) {
        if ($v === '' || $v === null) {
            unset($q[$k]);
        }
    }
    $path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
    return $path . ($q ? '?' . http_build_query($q) : '');
}

/** Hidden field standar untuk form aksi data. */
function action_fields(string $entity, string $action, string $returnTo = ''): string
{
    return csrf_field()
        . '<input type="hidden" name="entity" value="' . e($entity) . '">'
        . '<input type="hidden" name="action" value="' . e($action) . '">'
        . '<input type="hidden" name="return" value="' . e($returnTo !== '' ? $returnTo : ($_SERVER['REQUEST_URI'] ?? '/')) . '">';
}
