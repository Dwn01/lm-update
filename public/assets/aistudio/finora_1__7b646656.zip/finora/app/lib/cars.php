<?php
declare(strict_types=1);

/**
 * Foto stok mobil dalam alur persetujuan.
 *
 * Foto yang diunggah pengguna TIDAK langsung masuk ke folder publik. Foto disimpan sementara
 * di storage/pending_photos (di luar docroot) dan baru dipindahkan ke public/uploads/cars
 * setelah super admin menyetujui. Jika ditolak, foto sementara dihapus.
 *
 * Bentuk "extras" yang disimpan di payload permintaan:
 *   ['add' => [nama-file-sementara...], 'remove' => [id foto...], 'primary' => int|'new:N'|null]
 */

const CAR_STAGE_RE = '/^[a-f0-9]{36}\.(jpg|png|webp)$/';

function car_stage_dir(): string
{
    return APP_ROOT . '/storage/pending_photos';
}

function car_public_dir(): string
{
    return APP_ROOT . '/public/uploads/cars';
}

function car_ensure_dir(string $dir): void
{
    if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) {
        throw new RuntimeException('Folder foto tidak dapat dibuat.');
    }
}

/** Simpan foto unggahan ke folder sementara. @return string[] nama file sementara */
function car_stage_uploads(array $files): array
{
    if (!isset($files['name']) || !is_array($files['name'])) {
        return [];
    }
    $count = count(array_filter((array)($files['error'] ?? []), static fn($e) => (int)$e !== UPLOAD_ERR_NO_FILE));
    if ($count === 0) {
        return []; // tidak ada foto dipilih: jangan sentuh folder/ekstensi apa pun
    }
    if ($count > 10) {
        throw new RuntimeException('Maksimal 10 foto per pengajuan.');
    }
    car_ensure_dir(car_stage_dir());
    // Ekstensi fileinfo tidak selalu terpasang (mis. PHP aaPanel); cadangannya getimagesize().
    $finfo = class_exists('finfo') ? new finfo(FILEINFO_MIME_TYPE) : null;
    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    $saved = [];
    try {
        foreach ($files['name'] as $i => $_) {
            $err = (int)($files['error'][$i] ?? UPLOAD_ERR_NO_FILE);
            if ($err === UPLOAD_ERR_NO_FILE) {
                continue;
            }
            if ($err !== UPLOAD_ERR_OK) {
                throw new RuntimeException('Ada foto yang gagal diunggah.');
            }
            $tmp = (string)($files['tmp_name'][$i] ?? '');
            if (!is_uploaded_file($tmp) || (int)($files['size'][$i] ?? 0) > 5 * 1024 * 1024) {
                throw new RuntimeException('Setiap foto harus maksimal 5 MB.');
            }
            $info = @getimagesize($tmp);
            $mime = $finfo ? $finfo->file($tmp) : (is_array($info) ? (string)($info['mime'] ?? '') : '');
            if (!isset($allowed[$mime]) || $info === false) {
                throw new RuntimeException('Format foto harus JPG, PNG, atau WebP.');
            }
            $name = bin2hex(random_bytes(18)) . '.' . $allowed[$mime];
            if (!move_uploaded_file($tmp, car_stage_dir() . '/' . $name)) {
                throw new RuntimeException('Foto tidak dapat disimpan.');
            }
            @chmod(car_stage_dir() . '/' . $name, 0640);
            $saved[] = $name;
        }
    } catch (Throwable $e) {
        car_discard_staged($saved);
        throw $e;
    }
    return $saved;
}

function car_discard_staged(array $names): void
{
    foreach ($names as $n) {
        if (is_string($n) && preg_match(CAR_STAGE_RE, $n)) {
            $f = car_stage_dir() . '/' . $n;
            if (is_file($f)) {
                @unlink($f);
            }
        }
    }
}

function car_remove_photo_file(string $path): void
{
    if (preg_match('~^/uploads/cars/([a-f0-9]{36}\.(jpg|png|webp))$~', $path, $m)) {
        $file = car_public_dir() . '/' . $m[1];
        if (is_file($file)) {
            @unlink($file);
        }
    }
}

/** Baca input form foto menjadi "extras" (foto baru sudah disimpan sementara). */
function car_extras_clean(array $in, ?int $carId, array &$err): array
{
    $add = [];
    try {
        $add = car_stage_uploads($_FILES['photos'] ?? []);
    } catch (RuntimeException $e) {
        $err[] = $e->getMessage();
    } catch (Throwable $e) {
        app_log('Unggah foto gagal: ' . get_class($e) . ': ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
        $err[] = 'Foto tidak dapat diproses di server. Simpan tanpa foto atau hubungi administrator.';
    }
    $remove = [];
    $primary = null;
    if ($carId) {
        $own = array_map('intval', array_column(rows('SELECT id FROM car_photos WHERE car_id=?', [$carId]), 'id'));
        foreach ((array)($in['remove_photo'] ?? []) as $rid) {
            if (is_string($rid) && ctype_digit($rid) && in_array((int)$rid, $own, true)) {
                $remove[] = (int)$rid;
            }
        }
        $remove = array_values(array_unique($remove));
        $p = isset($in['primary_photo']) && is_string($in['primary_photo']) ? $in['primary_photo'] : '';
        if ($p !== '' && ctype_digit($p) && in_array((int)$p, $own, true) && !in_array((int)$p, $remove, true)) {
            $primary = (int)$p;
            $cur = (int)val('SELECT id FROM car_photos WHERE car_id=? AND is_primary=1', [$carId]);
            if ($primary === $cur) {
                $primary = null; // tidak berubah
            }
        }
    }
    if (isset($in['primary_new']) && is_string($in['primary_new']) && ctype_digit($in['primary_new']) && isset($add[(int)$in['primary_new']])) {
        $primary = 'new:' . (int)$in['primary_new'];
    }
    return ['add' => $add, 'remove' => $remove, 'primary' => $primary];
}

function car_extras_empty(?array $x): bool
{
    return !$x || (empty($x['add']) && empty($x['remove']) && ($x['primary'] ?? null) === null);
}

function car_extras_discard(?array $x): void
{
    if ($x && !empty($x['add'])) {
        car_discard_staged((array)$x['add']);
    }
}

/** Baris diff [label, sebelum, sesudah] untuk perubahan foto. */
function car_extras_diff(array $x): array
{
    $out = [];
    if (!empty($x['add'])) {
        $out[] = ['Foto baru', '', count($x['add']) . ' foto ditambahkan'];
    }
    if (!empty($x['remove'])) {
        $out[] = ['Hapus foto', count($x['remove']) . ' foto', ''];
    }
    if (($x['primary'] ?? null) !== null) {
        $out[] = ['Foto utama', '', 'Diganti'];
    }
    return $out;
}

/** Periksa bahwa foto sementara masih ada sebelum disetujui. */
function car_extras_check(?array $x): ?string
{
    foreach ((array)($x['add'] ?? []) as $n) {
        if (!is_string($n) || !preg_match(CAR_STAGE_RE, $n) || !is_file(car_stage_dir() . '/' . $n)) {
            return 'Foto yang diajukan sudah tidak tersedia. Tolak permintaan ini dan minta pengguna mengunggah ulang.';
        }
    }
    return null;
}

/** Terapkan perubahan foto setelah data mobil tersimpan. */
function car_extras_apply(int $carId, ?array $x): void
{
    if (car_extras_empty($x)) {
        return;
    }
    $now = now_sql();
    $filesToDelete = [];
    foreach ((array)($x['remove'] ?? []) as $rid) {
        $p = row('SELECT * FROM car_photos WHERE id=? AND car_id=?', [(int)$rid, $carId]);
        if ($p) {
            q('DELETE FROM car_photos WHERE id=?', [(int)$p['id']]);
            $filesToDelete[] = (string)$p['path'];
        }
    }
    car_ensure_dir(car_public_dir());
    $newIds = [];
    foreach ((array)($x['add'] ?? []) as $i => $n) {
        if (!is_string($n) || !preg_match(CAR_STAGE_RE, $n)) {
            continue;
        }
        $src = car_stage_dir() . '/' . $n;
        $dst = car_public_dir() . '/' . $n;
        if (!is_file($src)) {
            throw new RuntimeException('Foto sementara tidak ditemukan.');
        }
        if (!@rename($src, $dst) && !(@copy($src, $dst) && @unlink($src))) {
            throw new RuntimeException('Foto tidak dapat dipindahkan.');
        }
        @chmod($dst, 0644); // foto publik: harus terbaca oleh user Nginx
        $newIds[(int)$i] = insert_row('car_photos', ['car_id' => $carId, 'path' => '/uploads/cars/' . $n, 'is_primary' => 0, 'created_at' => $now]);
    }
    $primary = $x['primary'] ?? null;
    if (is_string($primary) && str_starts_with($primary, 'new:') && isset($newIds[(int)substr($primary, 4)])) {
        $primary = $newIds[(int)substr($primary, 4)];
    }
    if (is_int($primary) && row('SELECT id FROM car_photos WHERE id=? AND car_id=?', [$primary, $carId])) {
        q('UPDATE car_photos SET is_primary=0 WHERE car_id=?', [$carId]);
        q('UPDATE car_photos SET is_primary=1 WHERE id=?', [$primary]);
    }
    if (!row('SELECT id FROM car_photos WHERE car_id=? AND is_primary=1', [$carId])) {
        $first = row('SELECT id FROM car_photos WHERE car_id=? ORDER BY id LIMIT 1', [$carId]);
        if ($first) {
            q('UPDATE car_photos SET is_primary=1 WHERE id=?', [(int)$first['id']]);
        }
    }
    foreach ($filesToDelete as $path) { // hapus file hanya setelah semua langkah DB berhasil
        car_remove_photo_file($path);
    }
}

// =====================================================================
//  Integrasi keuangan: pembelian, penjualan, pembatalan
//  Prinsip: transaksi yang sudah dibukukan TIDAK dihapus. Pembatalan dibuat sebagai
//  transaksi pembalik (reversal) yang nyata, dan setiap transaksi punya ref_key UNIK
//  (dijaga indeks database) sehingga klik ganda / retry tidak bisa membukukan dua kali.
// =====================================================================

/** Transaksi yang dibuat otomatis dari modul Stok Mobil (hanya boleh diubah lewat Stok Mobil). */
function tx_is_system(int $txId): bool
{
    return (int)val('SELECT COUNT(*) FROM transactions WHERE id=? AND ref_type IS NOT NULL', [$txId]) > 0;
}

/** Nama kategori sistem untuk transaksi otomatis. */
const CAR_CATEGORIES = [
    'purchase'          => ['Pembelian Mobil', 'expense', 'red'],
    'sale'              => ['Penjualan Mobil', 'income', 'green'],
    'sale_reversal'     => ['Pembatalan Penjualan', 'expense', 'yellow'],
    'purchase_reversal' => ['Pembatalan Pembelian', 'income', 'blue'],
];

function car_category_id(string $refType): int
{
    [$name, $type, $color] = CAR_CATEGORIES[$refType];
    $id = val('SELECT id FROM categories WHERE name=? AND type=?', [$name, $type]);
    if ($id) {
        return (int)$id;
    }
    return insert_row('categories', ['name' => $name, 'type' => $type, 'color' => $color, 'created_at' => now_sql()]);
}

function car_title(array $car): string
{
    return trim($car['brand'] . ' ' . $car['model'] . ' ' . $car['plate_number']);
}

/** Bukukan satu transaksi otomatis. ref_key unik: jika sudah ada, database menolak (rollback). */
function car_post_tx(array $car, string $refType, string $refKey, int $accountId, int $amount, string $date, string $name, string $note, int $by): int
{
    if ($amount <= 0) {
        throw new RuntimeException('Nominal transaksi otomatis harus lebih dari 0.');
    }
    return insert_row('transactions', [
        'name'        => mb_substr($name, 0, 150),
        'type'        => CAR_CATEGORIES[$refType][1],
        'category_id' => car_category_id($refType),
        'account_id'  => $accountId,
        'amount'      => $amount,
        'tx_date'     => $date,
        'note'        => mb_substr($note, 0, 500),
        'created_by'  => $by,
        'car_id'      => (int)$car['id'],
        'ref_type'    => $refType,
        'ref_key'     => $refKey,
        'created_at'  => now_sql(),
        'updated_at'  => now_sql(),
    ]);
}

/** Utang/piutang sisa pembayaran memakai mekanisme invoice yang sudah ada. */
function car_post_invoice(string $kind, string $contact, string $issue, int $days, int $amount, string $note): int
{
    $c = ['kind' => $kind, 'number' => '', 'issue_date' => $issue];
    entity_get('invoice')['prepare']($c, null); // nomor otomatis INV-/BILL-tahun-urut
    return insert_row('invoices', [
        'number' => $c['number'], 'kind' => $kind, 'contact_name' => mb_substr($contact, 0, 150),
        'issue_date' => $issue, 'due_date' => date('Y-m-d', strtotime($issue . ' +' . $days . ' days')),
        'amount' => $amount, 'status' => 'unpaid', 'note' => mb_substr($note, 0, 500), 'created_at' => now_sql(),
    ]);
}

/** Balik satu transaksi yang pernah dibukukan dengan transaksi pembalik. Aman terhadap pemanggilan ulang. */
function car_reverse_tx(array $car, int $origTxId, string $revType, string $revKey, string $label, int $by): void
{
    $o = row('SELECT * FROM transactions WHERE id=?', [$origTxId]);
    if (!$o) {
        return;
    }
    car_post_tx($car, $revType, $revKey, (int)$o['account_id'], (int)$o['amount'], today(),
        $label . ': ' . car_title($car), 'Pembalikan transaksi #' . $origTxId . ' (' . $o['name'] . ')', $by);
}

/**
 * Sinkronkan keuangan dengan perubahan mobil. Dipanggil di dalam transaksi database yang sama
 * dengan perubahan data mobil, jadi seluruhnya berhasil atau seluruhnya dibatalkan.
 *
 *  - create                     : pembelian -> pengeluaran sebesar yang DIBAYAR + utang untuk sisanya
 *  - bukan terjual -> terjual   : pemasukan sebesar yang DITERIMA + piutang untuk sisanya
 *  - terjual -> bukan terjual   : transaksi pembalik (pengeluaran) + hapus piutang sisa yang belum dibayar
 */
function car_sync_finance(int $carId, int $by, ?array $prev, string $action): void
{
    $car = row('SELECT * FROM cars WHERE id=?', [$carId]);
    if (!$car) {
        return;
    }
    // 1) PEMBELIAN (hanya saat mobil baru dibuat; mobil lama tidak pernah dibukukan ulang)
    if ($action === 'create' && $car['purchase_tx_id'] === null && $car['purchase_invoice_id'] === null) {
        $price = (int)$car['purchase_price'];
        $paid = $car['purchase_paid'] === null ? $price : (int)$car['purchase_paid'];
        if ($paid > 0) {
            $txId = car_post_tx($car, 'purchase', 'car:' . $carId . ':purchase', (int)$car['purchase_account_id'], $paid, today(),
                'Pembelian mobil: ' . car_title($car), 'Otomatis dari Stok Mobil #' . $carId . ($paid < $price ? ' (dibayar sebagian)' : ''), $by);
            q('UPDATE cars SET purchase_tx_id=? WHERE id=?', [$txId, $carId]);
        }
        if ($price - $paid > 0) {
            $inv = car_post_invoice('payable', 'Penjual mobil: ' . car_title($car), today(), 30, $price - $paid, 'Sisa pembelian mobil #' . $carId);
            q('UPDATE cars SET purchase_invoice_id=? WHERE id=?', [$inv, $carId]);
        }
        q('UPDATE cars SET purchase_paid=? WHERE id=?', [$paid, $carId]);
    }

    $was = $prev['status'] ?? null;
    // 2) PENJUALAN
    if ($car['status'] === 'terjual' && $was !== 'terjual') {
        $seq = (int)$car['sale_seq'] + 1;
        $price = (int)$car['sold_price'];
        $recv = (int)$car['sold_received'];
        q('UPDATE cars SET sale_seq=? WHERE id=?', [$seq, $carId]);
        if ($recv > 0) {
            $txId = car_post_tx($car, 'sale', 'car:' . $carId . ':sale:' . $seq, (int)$car['sold_account_id'], $recv, (string)$car['sold_at'],
                'Penjualan mobil: ' . car_title($car),
                'Otomatis dari Stok Mobil #' . $carId . ($car['buyer_name'] !== '' ? ' - pembeli: ' . $car['buyer_name'] : '') . ($recv < $price ? ' (diterima sebagian)' : ''), $by);
            q('UPDATE cars SET sold_tx_id=? WHERE id=?', [$txId, $carId]);
        }
        if ($price - $recv > 0) {
            $inv = car_post_invoice('receivable', $car['buyer_name'] !== '' ? $car['buyer_name'] : 'Pembeli ' . car_title($car), (string)$car['sold_at'], 14, $price - $recv, 'Sisa pembayaran penjualan mobil #' . $carId);
            q('UPDATE cars SET sale_invoice_id=? WHERE id=?', [$inv, $carId]);
        }
    }
    // 3) PEMBATALAN PENJUALAN
    if ($was === 'terjual' && $car['status'] !== 'terjual' && $prev) {
        $seq = (int)$prev['sale_seq'];
        if ($prev['sold_tx_id'] !== null) {
            car_reverse_tx($car, (int)$prev['sold_tx_id'], 'sale_reversal', 'car:' . $carId . ':sale:' . $seq . ':rev', 'Pembatalan penjualan', $by);
        }
        if ($prev['sale_invoice_id'] !== null) {
            q("DELETE FROM invoices WHERE id=? AND status='unpaid'", [(int)$prev['sale_invoice_id']]);
        }
        q('UPDATE cars SET sold_tx_id=NULL, sale_invoice_id=NULL, sold_received=NULL, sold_note=? WHERE id=?', ['', $carId]);
        audit('batal_jual', 'car', $carId, car_title($car) . ' (penjualan #' . $seq . ' dibatalkan)', $by);
    }
}

/** Dipanggil sebelum mobil dihapus. Pembelian dibalik dengan transaksi pembalik; riwayat tetap tersimpan. */
function car_before_delete(int $carId, int $by = 0): void
{
    $car = row('SELECT * FROM cars WHERE id=?', [$carId]);
    if (!$car) {
        return;
    }
    if ($car['status'] === 'terjual') {
        throw new RuntimeException('Mobil terjual tidak dapat dihapus. Batalkan penjualan terlebih dahulu.');
    }
    if ($car['purchase_tx_id'] !== null) {
        car_reverse_tx($car, (int)$car['purchase_tx_id'], 'purchase_reversal', 'car:' . $carId . ':purchase:rev', 'Pembatalan pembelian', $by);
    }
    if ($car['purchase_invoice_id'] !== null) {
        q("DELETE FROM invoices WHERE id=? AND status='unpaid'", [(int)$car['purchase_invoice_id']]);
    }
    foreach (rows('SELECT path FROM car_photos WHERE car_id=?', [$carId]) as $p) {
        car_remove_photo_file((string)$p['path']);
    }
    q('DELETE FROM car_photos WHERE car_id=?', [$carId]);
}

// =====================================================================
//  Masukan form -> data mobil (melindungi data keuangan dari manipulasi request)
// =====================================================================

const CAR_FIELDS_COPY = ['brand','model','year','plate_number','color','transmission','fuel','mileage','purchase_price','purchase_paid','purchase_account_id','selling_price','status','description','sold_at','sold_price','sold_received','sold_account_id','buyer_name','sold_note'];
const CAR_SALE_FIELDS = ['sold_at','sold_price','sold_received','sold_account_id','buyer_name','sold_note'];

/**
 * Aturan:
 *  - Mobil baru: status hanya tersedia/dipesan; data penjualan diabaikan.
 *  - Edit biasa: data keuangan (harga beli yang sudah dibukukan, data penjualan) tidak bisa diubah dari form;
 *    status Terjual tidak bisa diatur dari form.
 *  - op=sell   : "Tandai Terjual" -> hanya data penjualan yang diambil dari form, sisanya dari database.
 *  - op=unsell : "Batalkan Penjualan" -> status kembali tersedia; data lain dari database.
 */
function car_prepare_input(array $in, ?int $id, string $action): array
{
    $op = (string)($in['op'] ?? '');
    if ($action === 'create') {
        if (!in_array($in['status'] ?? '', ['tersedia', 'dipesan'], true)) {
            $in['status'] = 'tersedia';
        }
        foreach (CAR_SALE_FIELDS as $k) {
            unset($in[$k]);
        }
        return $in;
    }
    $b = $id ? row('SELECT * FROM cars WHERE id=?', [$id]) : null;
    if (!$b) {
        $in['_error'] = 'Data tidak ditemukan atau sudah dihapus.';
        return $in;
    }
    $base = [];
    foreach (CAR_FIELDS_COPY as $k) {
        $base[$k] = $b[$k] === null ? '' : (string)$b[$k];
    }
    if ($op === 'sell') {
        if ($b['status'] === 'terjual') {
            $in['_error'] = 'Mobil ini sudah ditandai terjual.';
            return $in;
        }
        $out = $base;
        foreach (CAR_SALE_FIELDS as $k) {
            $out[$k] = isset($in[$k]) && is_string($in[$k]) ? $in[$k] : '';
        }
        $out['status'] = 'terjual';
        $out['op'] = 'sell';
        return $out;
    }
    if ($op === 'unsell') {
        if ($b['status'] !== 'terjual') {
            $in['_error'] = 'Mobil ini tidak berstatus terjual, tidak ada penjualan yang dibatalkan.';
            return $in;
        }
        $out = $base;
        $out['status'] = 'tersedia';
        $out['op'] = 'unsell';
        return $out;
    }
    // edit biasa
    $locked = $b['purchase_tx_id'] !== null || $b['purchase_invoice_id'] !== null;
    if ($locked) {
        foreach (['purchase_price', 'purchase_paid', 'purchase_account_id'] as $k) {
            $in[$k] = $base[$k];
        }
    } else {
        foreach (['purchase_paid', 'purchase_account_id'] as $k) {
            $in[$k] = $base[$k]; // mobil lama: tidak ada pembukuan pembelian
        }
    }
    if ($b['status'] === 'terjual') {
        $in['status'] = 'terjual';
        foreach (CAR_SALE_FIELDS as $k) {
            $in[$k] = $base[$k];
        }
        $in['selling_price'] = $base['selling_price'];
    } elseif (!in_array($in['status'] ?? '', ['tersedia', 'dipesan'], true)) {
        $in['_error'] = 'Untuk menandai mobil terjual, gunakan tombol "Tandai Terjual" agar keuangan tercatat.';
    }
    return $in;
}

function car_summary(string $action, array $data, string $op): ?string
{
    $t = trim(($data['brand'] ?? '') . ' ' . ($data['model'] ?? '') . ' ' . ($data['plate_number'] ?? ''));
    if ($op === 'sell') {
        return 'Tandai Terjual: ' . $t . ' (' . idr($data['sold_price'] ?? 0) . ')';
    }
    if ($op === 'unsell') {
        return 'Batalkan Penjualan: ' . $t;
    }
    return null;
}