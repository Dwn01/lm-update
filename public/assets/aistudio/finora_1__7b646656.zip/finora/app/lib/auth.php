<?php
declare(strict_types=1);

const ROLE_LABELS = ['super_admin' => 'Super Admin', 'user' => 'Pengguna', 'viewer' => 'Hanya Lihat'];

function is_admin_mode(): bool
{
    return APP_MODE === 'admin';
}

function mode_roles(): array
{
    return is_admin_mode() ? ['super_admin'] : ['user', 'viewer'];
}

function session_boot(): void
{
    session_name(is_admin_mode() ? 'finora_admin' : 'finora_user');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'secure'   => is_https(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    session_start();

    $idle = (int)cfg('session_idle_minutes', 120) * 60;
    if (!empty($_SESSION['uid']) && isset($_SESSION['last']) && time() - (int)$_SESSION['last'] > $idle) {
        $_SESSION = [];
        session_regenerate_id(true);
        $_SESSION['flash'][] = ['type' => 'info', 'msg' => 'Sesi berakhir karena tidak aktif. Silakan masuk kembali.'];
    }
    $_SESSION['last'] = time();
}

function current_user(): ?array
{
    static $cache = false;
    if ($cache !== false) {
        return $cache;
    }
    $cache = null;
    if (!empty($_SESSION['uid'])) {
        $u = row('SELECT * FROM users WHERE id=?', [(int)$_SESSION['uid']]);
        if ($u && (int)$u['is_active'] === 1 && in_array($u['role'], mode_roles(), true)) {
            $cache = $u;
        } else {
            unset($_SESSION['uid']);
        }
    }
    return $cache;
}

function is_super(): bool
{
    $u = current_user();
    return $u !== null && $u['role'] === 'super_admin';
}

function can_write(): bool
{
    $u = current_user();
    return $u !== null && in_array($u['role'], ['super_admin', 'user'], true);
}

function audit(string $action, string $entity = '', ?int $entityId = null, string $detail = '', ?int $userId = null): void
{
    try {
        $uid = $userId ?? (current_user()['id'] ?? null);
        insert_row('audit_logs', [
            'user_id'    => $uid,
            'action'     => $action,
            'entity'     => $entity,
            'entity_id'  => $entityId,
            'detail'     => mb_substr($detail, 0, 500),
            'ip'         => client_ip(),
            'created_at' => now_sql(),
        ]);
    } catch (Throwable $ex) {
        app_log('audit gagal: ' . $ex->getMessage());
    }
}

// ---------- pembatasan percobaan login ----------

function login_blocked(string $username): bool
{
    $since = date('Y-m-d H:i:s', time() - 15 * 60);
    $byIp = (int)val('SELECT COUNT(*) FROM login_attempts WHERE success=0 AND ip=? AND created_at>=?', [client_ip(), $since]);
    $byUser = (int)val('SELECT COUNT(*) FROM login_attempts WHERE success=0 AND username=? AND created_at>=?', [$username, $since]);
    return $byIp >= 8 || $byUser >= 5;
}

function record_attempt(string $username, bool $ok): void
{
    insert_row('login_attempts', [
        'ip' => client_ip(), 'username' => mb_substr($username, 0, 50), 'success' => $ok ? 1 : 0, 'created_at' => now_sql(),
    ]);
    if (random_int(1, 50) === 1) {
        q('DELETE FROM login_attempts WHERE created_at<?', [date('Y-m-d H:i:s', time() - 7 * 86400)]);
    }
}

/**
 * @return array [status, message]  status: ok | 2fa | fail | blocked
 */
function try_login(string $username, string $password): array
{
    $username = mb_strtolower(trim($username));
    if ($username === '' || $password === '') {
        return ['fail', 'Username dan password wajib diisi.'];
    }
    if (login_blocked($username)) {
        audit('login_blocked', 'user', null, 'username=' . $username, 0);
        notify_login_failed($username, true);
        return ['blocked', 'Terlalu banyak percobaan gagal. Coba lagi dalam 15 menit.'];
    }
    $u = row('SELECT * FROM users WHERE username=?', [$username]);
    // Selalu jalankan verifikasi agar waktu respons relatif sama.
    $hash = $u['password_hash'] ?? '$2y$10$usesomesillystringforsaltuYcJb2cF5yq0Yh5Xc0q6u3o6e9N7gH2';
    $ok = password_verify($password, $hash);
    if (!$u || !$ok || (int)$u['is_active'] !== 1 || !in_array($u['role'], mode_roles(), true)) {
        record_attempt($username, false);
        audit('login_gagal', 'user', $u ? (int)$u['id'] : null, 'username=' . $username, $u ? (int)$u['id'] : null);
        notify_login_failed($username, false);
        return ['fail', 'Username atau password salah.'];
    }
    record_attempt($username, true);
    if (password_needs_rehash($hash, PASSWORD_DEFAULT)) {
        update_row('users', (int)$u['id'], ['password_hash' => password_hash($password, PASSWORD_DEFAULT)]);
    }
    if (is_admin_mode() && (int)$u['totp_enabled'] === 1) {
        session_regenerate_id(true);
        $_SESSION['pre2fa'] = (int)$u['id'];
        $_SESSION['pre2fa_at'] = time();
        return ['2fa', ''];
    }
    finish_login($u);
    return ['ok', ''];
}

function finish_login(array $u): void
{
    session_regenerate_id(true);
    unset($_SESSION['pre2fa'], $_SESSION['pre2fa_at']);
    $_SESSION['uid'] = (int)$u['id'];
    $_SESSION['last'] = time();
    unset($_SESSION['csrf']);
    update_row('users', (int)$u['id'], ['last_login_at' => now_sql()]);
    audit('login', 'user', (int)$u['id'], 'Masuk', (int)$u['id']);
    notify_login($u);
}

function verify_2fa_login(string $code): bool
{
    $uid = (int)($_SESSION['pre2fa'] ?? 0);
    if ($uid === 0 || time() - (int)($_SESSION['pre2fa_at'] ?? 0) > 300) {
        return false;
    }
    $u = row('SELECT * FROM users WHERE id=?', [$uid]);
    if (!$u || (int)$u['is_active'] !== 1 || empty($u['totp_secret'])) {
        return false;
    }
    if (login_blocked($u['username'])) {
        return false;
    }
    $secret = secret_decrypt((string)$u['totp_secret']);
    $step = $secret ? totp_verify($secret, $code, $u['totp_last_step'] !== null ? (int)$u['totp_last_step'] : null) : null;
    if ($step === null) {
        record_attempt($u['username'], false);
        audit('2fa_gagal', 'user', $uid, '', $uid);
        return false;
    }
    update_row('users', $uid, ['totp_last_step' => $step]);
    finish_login($u);
    return true;
}

function logout_user(): void
{
    $uid = current_user()['id'] ?? null;
    if ($uid) {
        audit('logout', 'user', (int)$uid, 'Keluar');
    }
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 3600, $p['path'], $p['domain'] ?? '', (bool)$p['secure'], true);
    }
    session_destroy();
}

function password_problems(string $pw): array
{
    $p = [];
    if (mb_strlen($pw) < 10) {
        $p[] = 'Password minimal 10 karakter.';
    }
    if (!preg_match('/[A-Za-z]/', $pw) || !preg_match('/\d/', $pw)) {
        $p[] = 'Password harus mengandung huruf dan angka.';
    }
    return $p;
}

/** Akun yang wajib mengganti password sementara sebelum memakai aplikasi. (2FA bersifat sukarela.) */
function must_finish_security(): bool
{
    $u = current_user();
    return $u !== null && (int)$u['must_change_password'] === 1;
}
