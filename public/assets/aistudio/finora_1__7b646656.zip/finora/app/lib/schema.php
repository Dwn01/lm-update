<?php
declare(strict_types=1);

/**
 * DDL yang kompatibel untuk MySQL/MariaDB dan SQLite.
 * Jumlah uang disimpan sebagai bilangan bulat rupiah.
 */
function schema_statements(string $driver): array
{
    $my = $driver !== 'sqlite';
    $pk = $my ? 'INT AUTO_INCREMENT PRIMARY KEY' : 'INTEGER PRIMARY KEY AUTOINCREMENT';
    $big = $my ? 'BIGINT' : 'INTEGER';
    $tail = $my ? ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci' : '';

    $s = [];
    $s[] = "CREATE TABLE IF NOT EXISTS users (
        id $pk,
        name VARCHAR(100) NOT NULL,
        username VARCHAR(50) NOT NULL UNIQUE,
        email VARCHAR(150) NOT NULL DEFAULT '',
        password_hash VARCHAR(255) NOT NULL,
        role VARCHAR(20) NOT NULL DEFAULT 'user',
        is_active INT NOT NULL DEFAULT 1,
        must_change_password INT NOT NULL DEFAULT 0,
        totp_secret TEXT NULL,
        totp_enabled INT NOT NULL DEFAULT 0,
        totp_last_step $big NULL,
        created_at VARCHAR(19) NOT NULL,
        last_login_at VARCHAR(19) NULL
    )$tail";

    $s[] = "CREATE TABLE IF NOT EXISTS login_attempts (
        id $pk,
        ip VARCHAR(45) NOT NULL,
        username VARCHAR(50) NOT NULL,
        success INT NOT NULL DEFAULT 0,
        created_at VARCHAR(19) NOT NULL
    )$tail";

    $s[] = "CREATE TABLE IF NOT EXISTS categories (
        id $pk,
        name VARCHAR(80) NOT NULL,
        type VARCHAR(10) NOT NULL,
        color VARCHAR(10) NOT NULL DEFAULT 'green',
        created_at VARCHAR(19) NOT NULL,
        UNIQUE (name, type)
    )$tail";

    $s[] = "CREATE TABLE IF NOT EXISTS accounts (
        id $pk,
        name VARCHAR(80) NOT NULL UNIQUE,
        kind VARCHAR(10) NOT NULL DEFAULT 'bank',
        number_label VARCHAR(40) NOT NULL DEFAULT '',
        opening_balance $big NOT NULL DEFAULT 0,
        created_at VARCHAR(19) NOT NULL
    )$tail";

    $s[] = "CREATE TABLE IF NOT EXISTS transactions (
        id $pk,
        name VARCHAR(150) NOT NULL,
        type VARCHAR(10) NOT NULL,
        category_id INT NOT NULL,
        account_id INT NOT NULL,
        amount $big NOT NULL,
        tx_date DATE NOT NULL,
        note VARCHAR(500) NOT NULL DEFAULT '',
        created_by INT NULL,
        car_id INT NULL,
        ref_type VARCHAR(20) NULL,
        ref_key VARCHAR(60) NULL,
        created_at VARCHAR(19) NOT NULL,
        updated_at VARCHAR(19) NOT NULL,
        FOREIGN KEY (category_id) REFERENCES categories(id),
        FOREIGN KEY (account_id) REFERENCES accounts(id)
    )$tail";
    $s[] = 'CREATE INDEX idx_tx_date ON transactions (tx_date)';
    $s[] = 'CREATE INDEX idx_tx_category ON transactions (category_id)';
    $s[] = 'CREATE INDEX idx_tx_account ON transactions (account_id)';
    $s[] = 'CREATE INDEX idx_tx_car ON transactions (car_id)';
    // Penjaga anti-ganda di level database: satu referensi bisnis hanya boleh dibukukan sekali.
    $s[] = 'CREATE UNIQUE INDEX uq_tx_ref_key ON transactions (ref_key)';

    $s[] = "CREATE TABLE IF NOT EXISTS invoices (
        id $pk,
        number VARCHAR(40) NOT NULL UNIQUE,
        kind VARCHAR(12) NOT NULL,
        contact_name VARCHAR(150) NOT NULL,
        issue_date DATE NOT NULL,
        due_date DATE NOT NULL,
        amount $big NOT NULL,
        status VARCHAR(10) NOT NULL DEFAULT 'unpaid',
        note VARCHAR(500) NOT NULL DEFAULT '',
        created_at VARCHAR(19) NOT NULL
    )$tail";

    $s[] = "CREATE TABLE IF NOT EXISTS budgets (
        id $pk,
        category_id INT NOT NULL,
        month VARCHAR(7) NOT NULL,
        amount $big NOT NULL,
        created_at VARCHAR(19) NOT NULL,
        UNIQUE (category_id, month),
        FOREIGN KEY (category_id) REFERENCES categories(id)
    )$tail";

    $s[] = "CREATE TABLE IF NOT EXISTS settings (
        k VARCHAR(60) NOT NULL PRIMARY KEY,
        v TEXT NOT NULL
    )$tail";

    $s[] = "CREATE TABLE IF NOT EXISTS change_requests (
        id $pk,
        entity VARCHAR(30) NOT NULL,
        action VARCHAR(10) NOT NULL,
        entity_id INT NULL,
        summary VARCHAR(255) NOT NULL,
        payload TEXT NOT NULL,
        before_data TEXT NOT NULL,
        status VARCHAR(10) NOT NULL DEFAULT 'pending',
        requested_by INT NOT NULL,
        reviewed_by INT NULL,
        review_note VARCHAR(255) NOT NULL DEFAULT '',
        created_at VARCHAR(19) NOT NULL,
        reviewed_at VARCHAR(19) NULL,
        FOREIGN KEY (requested_by) REFERENCES users(id)
    )$tail";
    $s[] = 'CREATE INDEX idx_cr_status ON change_requests (status)';

    $s[] = "CREATE TABLE IF NOT EXISTS audit_logs (
        id $pk,
        user_id INT NULL,
        action VARCHAR(40) NOT NULL,
        entity VARCHAR(30) NOT NULL DEFAULT '',
        entity_id INT NULL,
        detail VARCHAR(500) NOT NULL DEFAULT '',
        ip VARCHAR(45) NOT NULL DEFAULT '',
        created_at VARCHAR(19) NOT NULL
    )$tail";
    $s[] = 'CREATE INDEX idx_audit_created ON audit_logs (created_at)';
    $s[] = 'CREATE INDEX idx_attempt_created ON login_attempts (created_at)';

    $s[] = "CREATE TABLE IF NOT EXISTS cars (
        id $pk,
        brand VARCHAR(80) NOT NULL,
        model VARCHAR(100) NOT NULL,
        year INT NOT NULL,
        plate_number VARCHAR(20) NOT NULL DEFAULT '',
        color VARCHAR(50) NOT NULL DEFAULT '',
        transmission VARCHAR(20) NOT NULL DEFAULT 'Manual',
        fuel VARCHAR(40) NOT NULL DEFAULT '',
        mileage $big NOT NULL DEFAULT 0,
        purchase_price $big NOT NULL DEFAULT 0,
        selling_price $big NOT NULL DEFAULT 0,
        status VARCHAR(12) NOT NULL DEFAULT 'tersedia',
        description VARCHAR(2000) NOT NULL DEFAULT '',
        sold_at DATE NULL,
        sold_price $big NULL,
        buyer_name VARCHAR(150) NOT NULL DEFAULT '',
        sold_account_id INT NULL,
        sold_tx_id INT NULL,
        sold_received $big NULL,
        sold_note VARCHAR(255) NOT NULL DEFAULT '',
        sale_invoice_id INT NULL,
        sale_seq INT NOT NULL DEFAULT 0,
        purchase_account_id INT NULL,
        purchase_paid $big NULL,
        purchase_tx_id INT NULL,
        purchase_invoice_id INT NULL,
        created_at VARCHAR(19) NOT NULL,
        updated_at VARCHAR(19) NOT NULL
    )$tail";
    $s[] = 'CREATE INDEX idx_cars_status ON cars (status)';
    $s[] = "CREATE TABLE IF NOT EXISTS car_photos (
        id $pk,
        car_id INT NOT NULL,
        path VARCHAR(255) NOT NULL,
        is_primary INT NOT NULL DEFAULT 0,
        created_at VARCHAR(19) NOT NULL,
        FOREIGN KEY (car_id) REFERENCES cars(id) ON DELETE CASCADE
    )$tail";
    $s[] = 'CREATE INDEX idx_car_photos_car ON car_photos (car_id)';

    return $s;
}

function schema_columns(string $table): array
{
    $have = [];
    if (db_driver() === 'sqlite') {
        foreach (db()->query('PRAGMA table_info(' . $table . ')')->fetchAll(PDO::FETCH_ASSOC) as $c) {
            $have[] = $c['name'];
        }
    } else {
        foreach (db()->query('SHOW COLUMNS FROM ' . $table)->fetchAll(PDO::FETCH_ASSOC) as $c) {
            $have[] = $c['Field'];
        }
    }
    return $have;
}

/**
 * Migrasi aman & idempoten untuk database lama:
 *  - menambah kolom penjualan/pembelian pada cars dan referensi mobil pada transactions
 *  - menautkan transaksi penjualan hasil versi sebelumnya (tanpa mengubah nominal/saldo)
 *  - TIDAK membuat transaksi baru untuk mobil lama (mencegah pengeluaran ganda)
 */
function schema_migrate(): void
{
    $big = db_driver() !== 'sqlite' ? 'BIGINT' : 'INTEGER';
    $plan = [
        'cars' => [
            'sold_at'             => 'DATE NULL',
            'sold_price'          => $big . ' NULL',
            'buyer_name'          => "VARCHAR(150) NOT NULL DEFAULT ''",
            'sold_account_id'     => 'INT NULL',
            'sold_tx_id'          => 'INT NULL',
            'sold_received'       => $big . ' NULL',
            'sold_note'           => "VARCHAR(255) NOT NULL DEFAULT ''",
            'sale_invoice_id'     => 'INT NULL',
            'sale_seq'            => 'INT NOT NULL DEFAULT 0',
            'purchase_account_id' => 'INT NULL',
            'purchase_paid'       => $big . ' NULL',
            'purchase_tx_id'      => 'INT NULL',
            'purchase_invoice_id' => 'INT NULL',
        ],
        'transactions' => [
            'car_id'   => 'INT NULL',
            'ref_type' => 'VARCHAR(20) NULL',
            'ref_key'  => 'VARCHAR(60) NULL',
        ],
    ];
    foreach ($plan as $table => $cols) {
        $have = schema_columns($table);
        if (!$have) {
            return; // tabel belum ada; schema_install yang membuatnya
        }
        foreach ($cols as $col => $def) {
            if (!in_array($col, $have, true)) {
                db()->exec('ALTER TABLE ' . $table . ' ADD COLUMN ' . $col . ' ' . $def);
            }
        }
    }
    foreach (['CREATE INDEX idx_tx_car ON transactions (car_id)', 'CREATE UNIQUE INDEX uq_tx_ref_key ON transactions (ref_key)'] as $sql) {
        try {
            db()->exec($sql);
        } catch (PDOException $ex) {
            $m = strtolower($ex->getMessage());
            if (!str_contains($m, 'already exists') && !str_contains($m, 'duplicate key name')) {
                throw $ex;
            }
        }
    }
    // Mobil lama berstatus terjual: isi tanggal & harga laku dari data yang ada.
    db()->exec("UPDATE cars SET sold_at=SUBSTR(updated_at,1,10), sold_price=selling_price WHERE status='terjual' AND sold_at IS NULL");
    // Transaksi penjualan buatan versi sebelumnya: beri referensi mobil agar dapat ditelusuri.
    foreach (rows("SELECT id, sold_tx_id FROM cars WHERE sold_tx_id IS NOT NULL AND sale_seq=0") as $c) {
        $t = row('SELECT id, amount FROM transactions WHERE id=? AND ref_key IS NULL', [(int)$c['sold_tx_id']]);
        if ($t) {
            q("UPDATE transactions SET car_id=?, ref_type='sale', ref_key=? WHERE id=?", [(int)$c['id'], 'car:' . (int)$c['id'] . ':sale:1', (int)$t['id']]);
            q('UPDATE cars SET sale_seq=1, sold_received=? WHERE id=?', [(int)$t['amount'], (int)$c['id']]);
        }
    }
}

/** Jalankan migrasi sekali (ditandai berkas) agar pembaruan kode tidak butuh langkah manual. */
function schema_migrate_once(): void
{
    $flag = APP_ROOT . '/storage/.migrated-cars-finance-v2';
    if (is_file($flag)) {
        return;
    }
    try {
        schema_migrate();
        @file_put_contents($flag, date('c'));
    } catch (Throwable $e) {
        app_log('Migrasi gagal: ' . $e->getMessage());
    }
}

function schema_install(): void
{
    foreach (schema_statements(db_driver()) as $sql) {
        try {
            db()->exec($sql);
        } catch (PDOException $ex) {
            $m = strtolower($ex->getMessage());
            // Index yang sudah ada: abaikan agar setup bisa dijalankan ulang.
            // Kolom indeks belum ada (tabel lama): dilewati, schema_migrate() menambah kolom lalu membuat indeksnya.
            if (str_contains($m, 'already exists') || str_contains($m, 'duplicate key name')
                || (preg_match('/^\s*CREATE\s+(UNIQUE\s+)?INDEX/i', $sql) && (str_contains($m, 'key column') || str_contains($m, 'no such column')))) {
                continue;
            }
            throw $ex;
        }
    }
    schema_migrate();
}
