<?php
declare(strict_types=1);

/** Notifikasi Telegram (opsional). Aktif jika telegram.bot_token dan telegram.chat_id diisi di config.php. */

function tg_enabled(): bool
{
    return (string)cfg('telegram.bot_token', '') !== '' && (string)cfg('telegram.chat_id', '') !== '';
}

/** Kirim pesan teks biasa (tanpa parse_mode, jadi aman dari injeksi format). @return array [ok, pesan galat] */
function tg_send(string $text): array
{
    if (!tg_enabled()) {
        return [false, 'Telegram belum dikonfigurasi'];
    }
    $base = rtrim((string)cfg('telegram.api_base', 'https://api.telegram.org'), '/');
    $url = $base . '/bot' . cfg('telegram.bot_token') . '/sendMessage';
    $fields = ['chat_id' => (string)cfg('telegram.chat_id'), 'text' => mb_substr($text, 0, 3500), 'disable_web_page_preview' => 'true'];

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query($fields),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 3,
            CURLOPT_TIMEOUT => 5,
        ]);
        $body = curl_exec($ch);
        $err = curl_errno($ch) ? curl_error($ch) : '';
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
    } else {
        $ctx = stream_context_create(['http' => [
            'method' => 'POST', 'timeout' => 5, 'ignore_errors' => true,
            'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
            'content' => http_build_query($fields),
        ]]);
        $body = @file_get_contents($url, false, $ctx);
        $err = $body === false ? 'koneksi gagal' : '';
        $code = 0;
        if (isset($http_response_header[0]) && preg_match('/\s(\d{3})\s/', $http_response_header[0], $m)) {
            $code = (int)$m[1];
        }
    }
    if ($err !== '' || $body === false) {
        return [false, 'Tidak dapat terhubung ke Telegram' . ($err !== '' ? ': ' . $err : '')];
    }
    $j = json_decode((string)$body, true);
    if ($code !== 200 || !is_array($j) || empty($j['ok'])) {
        return [false, 'Telegram menolak: ' . (is_array($j) ? (string)($j['description'] ?? $code) : $code)];
    }
    return [true, ''];
}

/** Kirim setelah respons ke browser selesai, supaya login tidak tertahan. */
function tg_send_later(string $text): void
{
    if (!tg_enabled()) {
        return;
    }
    register_shutdown_function(function () use ($text): void {
        try {
            if (session_status() === PHP_SESSION_ACTIVE) {
                session_write_close();
            }
            if (function_exists('fastcgi_finish_request')) {
                fastcgi_finish_request();
            }
            [$ok, $err] = tg_send($text);
            if (!$ok) {
                app_log('telegram gagal: ' . $err);
            }
        } catch (Throwable $ex) {
            app_log('telegram error: ' . $ex->getMessage());
        }
    });
}

function tg_clean(string $s, int $max = 120): string
{
    $s = preg_replace('/[\x00-\x1F\x7F]/u', ' ', $s) ?? '';
    return mb_substr(trim($s), 0, $max);
}

function tg_context_lines(): string
{
    return "IP: " . client_ip() . "\n"
        . "Waktu: " . date('d-m-Y H:i:s') . " WIB\n"
        . "Perangkat: " . tg_clean((string)($_SERVER['HTTP_USER_AGENT'] ?? '-'), 100);
}

function notify_login(array $u): void
{
    $where = is_admin_mode() ? 'PANEL SUPER ADMIN' : 'Aplikasi (user)';
    $icon = is_admin_mode() ? '🔐' : '✅';
    tg_send_later($icon . ' Login berhasil — ' . cfg('app_name', 'LM Finance') . "\n"
        . "Pintu: $where\n"
        . 'Akun: ' . tg_clean((string)$u['username'], 50) . ' (' . tg_clean((string)$u['name'], 60) . ")\n"
        . tg_context_lines());
}

/** Peringatan login gagal pada panel admin; maksimal 1 pesan per 5 menit agar tidak membanjiri. */
function notify_login_failed(string $username, bool $blocked): void
{
    if (!is_admin_mode() || !tg_enabled() || cfg('telegram.notify_failed_admin', true) === false) {
        return;
    }
    $key = 'tg_last_fail';
    $last = (int)(val('SELECT v FROM settings WHERE k=?', [$key]) ?? 0);
    if (time() - $last < 300) {
        return;
    }
    if ((int)val('SELECT COUNT(*) FROM settings WHERE k=?', [$key]) > 0) {
        q('UPDATE settings SET v=? WHERE k=?', [(string)time(), $key]);
    } else {
        q('INSERT INTO settings (k, v) VALUES (?, ?)', [$key, (string)time()]);
    }
    tg_send_later('⚠️ ' . ($blocked ? 'Login admin DIBLOKIR (terlalu banyak percobaan)' : 'Login admin GAGAL') . ' — ' . cfg('app_name', 'LM Finance') . "\n"
        . 'Username dicoba: ' . tg_clean($username, 50) . "\n"
        . tg_context_lines() . "\n(Peringatan serupa ditahan 5 menit)");
}
