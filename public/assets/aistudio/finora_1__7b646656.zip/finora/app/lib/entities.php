<?php
declare(strict_types=1);

/**
 * Definisi data keuangan + alur persetujuan.
 * - Super admin: perubahan langsung diterapkan (tercatat di log audit).
 * - Pengguna: perubahan disimpan sebagai permintaan (change_requests) dan baru
 *   diterapkan setelah disetujui super admin.
 */

const COLORS = ['green' => 'Hijau', 'blue' => 'Biru', 'red' => 'Merah', 'yellow' => 'Kuning', 'purple' => 'Ungu'];
const ACTION_LABELS = ['create' => 'Tambah', 'update' => 'Ubah', 'delete' => 'Hapus'];

function entity_defs(): array
{
    static $defs = null;
    if ($defs !== null) {
        return $defs;
    }

    $defs = [
        'transaction' => [
            'table' => 'transactions',
            'label' => 'Transaksi',
            'fields' => [
                'type'        => ['label' => 'Jenis', 't' => 'enum', 'values' => ['income' => 'Pemasukan', 'expense' => 'Pengeluaran'], 'req' => true],
                'name'        => ['label' => 'Nama transaksi', 't' => 'str', 'max' => 150, 'req' => true],
                'category_id' => ['label' => 'Kategori', 't' => 'fk', 'table' => 'categories', 'req' => true],
                'account_id'  => ['label' => 'Akun / metode', 't' => 'fk', 'table' => 'accounts', 'req' => true],
                'amount'      => ['label' => 'Jumlah', 't' => 'money', 'req' => true],
                'tx_date'     => ['label' => 'Tanggal', 't' => 'date', 'req' => true],
                'note'        => ['label' => 'Catatan', 't' => 'text', 'max' => 500],
            ],
            'title' => fn(array $d) => ($d['name'] ?? '') . (isset($d['amount']) ? ' (' . idr($d['amount']) . ')' : ''),
            'on_create' => fn(int $by) => ['created_by' => $by, 'created_at' => now_sql(), 'updated_at' => now_sql()],
            'on_update' => fn() => ['updated_at' => now_sql()],
            'can_delete' => fn(int $id): ?string => tx_is_system($id) ? 'Transaksi ini dibuat otomatis oleh modul Stok Mobil dan tidak dapat dihapus di sini. Koreksi lewat Stok Mobil (pembatalan).' : null,
            'check' => function (array $c, ?int $id, array &$err): void {
                if ($id && tx_is_system($id)) {
                    $err[] = 'Transaksi ini dibuat otomatis oleh modul Stok Mobil dan tidak dapat diubah di sini.';
                }
                if (isset($c['category_id'], $c['type'])) {
                    $t = val('SELECT type FROM categories WHERE id=?', [$c['category_id']]);
                    if ($t !== null && $t !== $c['type']) {
                        $err[] = 'Jenis kategori tidak sesuai dengan jenis transaksi.';
                    }
                }
            },
        ],

        'category' => [
            'table' => 'categories',
            'label' => 'Kategori',
            'fields' => [
                'name'  => ['label' => 'Nama kategori', 't' => 'str', 'max' => 80, 'req' => true],
                'type'  => ['label' => 'Jenis', 't' => 'enum', 'values' => ['income' => 'Pemasukan', 'expense' => 'Pengeluaran'], 'req' => true],
                'color' => ['label' => 'Warna', 't' => 'enum', 'values' => COLORS, 'req' => true],
            ],
            'title' => fn(array $d) => (string)($d['name'] ?? ''),
            'on_create' => fn(int $by) => ['created_at' => now_sql()],
            'on_update' => fn() => [],
            'check' => function (array $c, ?int $id, array &$err): void {
                if (isset($c['name'], $c['type'])) {
                    $dup = val('SELECT COUNT(*) FROM categories WHERE name=? AND type=? AND id<>?', [$c['name'], $c['type'], $id ?? 0]);
                    if ((int)$dup > 0) {
                        $err[] = 'Kategori dengan nama dan jenis yang sama sudah ada.';
                    }
                }
                if ($id && isset($c['type'])) {
                    $cur = val('SELECT type FROM categories WHERE id=?', [$id]);
                    $used = (int)val('SELECT COUNT(*) FROM transactions WHERE category_id=?', [$id]) + (int)val('SELECT COUNT(*) FROM budgets WHERE category_id=?', [$id]);
                    if ($cur !== null && $cur !== $c['type'] && $used > 0) {
                        $err[] = 'Jenis kategori tidak dapat diubah karena sudah dipakai transaksi/anggaran.';
                    }
                }
            },
            'can_delete' => function (int $id): ?string {
                $n = (int)val('SELECT COUNT(*) FROM transactions WHERE category_id=?', [$id]);
                $b = (int)val('SELECT COUNT(*) FROM budgets WHERE category_id=?', [$id]);
                return ($n + $b) > 0 ? 'Kategori sudah dipakai oleh ' . $n . ' transaksi dan ' . $b . ' anggaran sehingga tidak bisa dihapus.' : null;
            },
        ],

        'account' => [
            'table' => 'accounts',
            'label' => 'Akun',
            'fields' => [
                'name'            => ['label' => 'Nama akun', 't' => 'str', 'max' => 80, 'req' => true],
                'kind'            => ['label' => 'Jenis akun', 't' => 'enum', 'values' => ['bank' => 'Bank', 'cash' => 'Kas / tunai', 'internal' => 'Dana internal'], 'req' => true],
                'number_label'    => ['label' => 'Keterangan / nomor', 't' => 'str', 'max' => 40],
                'opening_balance' => ['label' => 'Saldo awal', 't' => 'money', 'req' => true, 'zero' => true],
            ],
            'title' => fn(array $d) => (string)($d['name'] ?? ''),
            'on_create' => fn(int $by) => ['created_at' => now_sql()],
            'on_update' => fn() => [],
            'check' => function (array $c, ?int $id, array &$err): void {
                if (isset($c['name']) && (int)val('SELECT COUNT(*) FROM accounts WHERE name=? AND id<>?', [$c['name'], $id ?? 0]) > 0) {
                    $err[] = 'Nama akun sudah dipakai.';
                }
            },
            'can_delete' => function (int $id): ?string {
                $n = (int)val('SELECT COUNT(*) FROM transactions WHERE account_id=?', [$id]);
                return $n > 0 ? 'Akun masih dipakai oleh ' . $n . ' transaksi sehingga tidak bisa dihapus.' : null;
            },
        ],

        'invoice' => [
            'table' => 'invoices',
            'label' => 'Invoice/Tagihan',
            'fields' => [
                'kind'         => ['label' => 'Jenis', 't' => 'enum', 'values' => ['receivable' => 'Piutang', 'payable' => 'Utang'], 'req' => true],
                'number'       => ['label' => 'Nomor', 't' => 'str', 'max' => 40],
                'contact_name' => ['label' => 'Kontak', 't' => 'str', 'max' => 150, 'req' => true],
                'issue_date'   => ['label' => 'Tanggal terbit', 't' => 'date', 'req' => true],
                'due_date'     => ['label' => 'Jatuh tempo', 't' => 'date', 'req' => true],
                'amount'       => ['label' => 'Jumlah', 't' => 'money', 'req' => true],
                'status'       => ['label' => 'Status', 't' => 'enum', 'values' => ['unpaid' => 'Belum dibayar', 'paid' => 'Lunas'], 'req' => true],
                'note'         => ['label' => 'Catatan', 't' => 'text', 'max' => 500],
            ],
            'title' => fn(array $d) => trim(($d['number'] ?? '') . ' ' . ($d['contact_name'] ?? '')),
            'on_create' => fn(int $by) => ['created_at' => now_sql()],
            'on_update' => fn() => [],
            'prepare' => function (array &$c, ?int $id): void {
                if (($c['number'] ?? '') === '') {
                    if ($id) {
                        $c['number'] = (string)val('SELECT number FROM invoices WHERE id=?', [$id]);
                    }
                    if (($c['number'] ?? '') === '' && isset($c['kind'], $c['issue_date'])) {
                        $prefix = $c['kind'] === 'receivable' ? 'INV' : 'BILL';
                        $year = substr($c['issue_date'], 0, 4);
                        $n = (int)val('SELECT COUNT(*) FROM invoices WHERE number LIKE ?', [$prefix . '-' . $year . '-%']) + 1;
                        do {
                            $num = sprintf('%s-%s-%03d', $prefix, $year, $n++);
                        } while ((int)val('SELECT COUNT(*) FROM invoices WHERE number=?', [$num]) > 0);
                        $c['number'] = $num;
                    }
                }
            },
            'check' => function (array $c, ?int $id, array &$err): void {
                if (!empty($c['number']) && (int)val('SELECT COUNT(*) FROM invoices WHERE number=? AND id<>?', [$c['number'], $id ?? 0]) > 0) {
                    $err[] = 'Nomor invoice sudah dipakai.';
                }
                if (isset($c['issue_date'], $c['due_date']) && $c['due_date'] < $c['issue_date']) {
                    $err[] = 'Jatuh tempo tidak boleh lebih awal dari tanggal terbit.';
                }
            },
        ],

        'budget' => [
            'table' => 'budgets',
            'label' => 'Anggaran',
            'fields' => [
                'category_id' => ['label' => 'Kategori', 't' => 'fk', 'table' => 'categories', 'req' => true],
                'month'       => ['label' => 'Bulan', 't' => 'month', 'req' => true],
                'amount'      => ['label' => 'Batas anggaran', 't' => 'money', 'req' => true],
            ],
            'title' => fn(array $d) => (isset($d['category_id']) ? (string)val('SELECT name FROM categories WHERE id=?', [$d['category_id']]) : '')
                . (isset($d['month']) ? ' - ' . month_label($d['month']) : ''),
            'on_create' => fn(int $by) => ['created_at' => now_sql()],
            'on_update' => fn() => [],
            'check' => function (array $c, ?int $id, array &$err): void {
                if (isset($c['category_id'])) {
                    $t = val('SELECT type FROM categories WHERE id=?', [$c['category_id']]);
                    if ($t !== 'expense') {
                        $err[] = 'Anggaran hanya dapat dibuat untuk kategori pengeluaran.';
                    }
                    if (isset($c['month']) && (int)val('SELECT COUNT(*) FROM budgets WHERE category_id=? AND month=? AND id<>?', [$c['category_id'], $c['month'], $id ?? 0]) > 0) {
                        $err[] = 'Anggaran untuk kategori ini pada bulan tersebut sudah ada.';
                    }
                }
            },
        ],

        'car' => [
            'table' => 'cars',
            'label' => 'Stok Mobil',
            'fields' => [
                'brand'          => ['label' => 'Merek', 't' => 'str', 'max' => 80, 'req' => true],
                'model'          => ['label' => 'Model / tipe', 't' => 'str', 'max' => 100, 'req' => true],
                'year'           => ['label' => 'Tahun', 't' => 'int', 'min' => 1950, 'max' => (int)date('Y') + 1, 'req' => true],
                'plate_number'   => ['label' => 'Nomor polisi', 't' => 'str', 'max' => 20],
                'color'          => ['label' => 'Warna', 't' => 'str', 'max' => 50],
                'transmission'   => ['label' => 'Transmisi', 't' => 'enum', 'values' => ['Manual' => 'Manual', 'Otomatis' => 'Otomatis'], 'req' => true],
                'fuel'           => ['label' => 'Bahan bakar', 't' => 'str', 'max' => 40],
                'mileage'        => ['label' => 'Kilometer', 't' => 'int', 'min' => 0, 'max' => 9999999, 'req' => true],
                'purchase_price' => ['label' => 'Harga beli (harga pokok)', 't' => 'money', 'req' => true, 'zero' => true],
                'purchase_paid'  => ['label' => 'Dibayar saat pembelian', 't' => 'money', 'zero' => true],
                'purchase_account_id' => ['label' => 'Sumber dana pembelian', 't' => 'fk', 'table' => 'accounts'],
                'selling_price'  => ['label' => 'Harga jual (rencana)', 't' => 'money', 'req' => true, 'zero' => true],
                'status'         => ['label' => 'Status', 't' => 'enum', 'values' => ['tersedia' => 'Tersedia', 'dipesan' => 'Dipesan', 'terjual' => 'Terjual'], 'req' => true],
                'description'    => ['label' => 'Deskripsi', 't' => 'text', 'max' => 2000],
                'sold_at'         => ['label' => 'Tanggal terjual', 't' => 'date'],
                'sold_price'      => ['label' => 'Harga jual aktual', 't' => 'money'],
                'sold_received'   => ['label' => 'Uang diterima', 't' => 'money', 'zero' => true],
                'sold_account_id' => ['label' => 'Dana masuk ke akun', 't' => 'fk', 'table' => 'accounts'],
                'buyer_name'      => ['label' => 'Pembeli', 't' => 'str', 'max' => 150],
                'sold_note'       => ['label' => 'Catatan penjualan', 't' => 'str', 'max' => 255],
            ],
            'title' => fn(array $d) => trim(($d['brand'] ?? '') . ' ' . ($d['model'] ?? '') . ' ' . ($d['plate_number'] ?? '')),
            'on_create' => fn(int $by) => ['created_at' => now_sql(), 'updated_at' => now_sql()],
            'on_update' => fn() => ['updated_at' => now_sql()],
            'prepare_input' => fn(array $in, ?int $id, array $before, string $action): array => car_prepare_input($in, $id, $action),
            'summary' => fn(string $action, array $data, string $op): ?string => car_summary($action, $data, $op),
            'prepare' => function (array &$c, ?int $id): void {
                if (isset($c['plate_number'])) {
                    $c['plate_number'] = strtoupper((string)$c['plate_number']);
                }
                if (($c['status'] ?? '') !== 'terjual') { // bukan terjual: data penjualan dikosongkan
                    foreach (['sold_at', 'sold_price', 'sold_received', 'sold_account_id'] as $k) {
                        $c[$k] = null;
                    }
                    $c['buyer_name'] = '';
                    $c['sold_note'] = '';
                }
                if ($id === null && ($c['purchase_paid'] ?? null) === null && isset($c['purchase_price'])) {
                    $c['purchase_paid'] = $c['purchase_price']; // kosong = dibayar lunas
                }
            },
            'check' => function (array $c, ?int $id, array &$err): void {
                if (!empty($c['plate_number']) && (int)val('SELECT COUNT(*) FROM cars WHERE plate_number=? AND id<>?', [$c['plate_number'], $id ?? 0]) > 0) {
                    $err[] = 'Nomor polisi sudah digunakan oleh data mobil lain.';
                }
                // Pembelian (hanya saat mobil baru dibuat)
                if ($id === null && (int)($c['purchase_price'] ?? 0) > 0) {
                    $paid = (int)($c['purchase_paid'] ?? 0);
                    if ($paid > (int)$c['purchase_price']) {
                        $err[] = 'Jumlah dibayar tidak boleh melebihi harga beli.';
                    }
                    if ($paid > 0 && empty($c['purchase_account_id'])) {
                        $err[] = 'Pilih sumber dana (akun) untuk pembayaran pembelian mobil.';
                    }
                }
                // Penjualan (divalidasi saat transisi ke terjual; mobil yang sudah terjual datanya terkunci dari DB)
                $alreadySold = $id !== null && val('SELECT status FROM cars WHERE id=?', [$id]) === 'terjual';
                if (($c['status'] ?? '') === 'terjual' && !$alreadySold) {
                    if (empty($c['sold_at'])) {
                        $err[] = 'Tanggal penjualan wajib diisi.';
                    } elseif ($c['sold_at'] > today()) {
                        $err[] = 'Tanggal penjualan tidak boleh di masa depan.';
                    }
                    if (empty($c['sold_price'])) {
                        $err[] = 'Harga jual aktual wajib diisi.';
                    }
                    if (($c['sold_received'] ?? null) === null) {
                        $err[] = 'Uang yang diterima wajib diisi (isi 0 jika belum ada pembayaran).';
                    } elseif (!empty($c['sold_price']) && (int)$c['sold_received'] > (int)$c['sold_price']) {
                        $err[] = 'Uang diterima tidak boleh melebihi harga jual aktual.';
                    }
                    if ((int)($c['sold_received'] ?? 0) > 0 && empty($c['sold_account_id'])) {
                        $err[] = 'Pilih akun tujuan penerimaan dana.';
                    }
                }
            },
            'can_delete' => function (int $id): ?string {
                $st = val('SELECT status FROM cars WHERE id=?', [$id]);
                return $st === 'terjual' ? 'Mobil terjual tidak dapat dihapus. Batalkan penjualan terlebih dahulu agar riwayat keuangan tetap benar.' : null;
            },
            'after_apply'    => fn(int $id, int $by, ?array $prev, string $action) => car_sync_finance($id, $by, $prev, $action),
            // foto: lihat app/lib/cars.php
            'extras_clean'   => fn(array $in, ?int $id, array &$err): array => car_extras_clean($in, $id, $err),
            'extras_diff'    => fn(array $x): array => car_extras_diff($x),
            'extras_check'   => fn(?array $x): ?string => car_extras_check($x),
            'extras_apply'   => fn(int $id, ?array $x) => car_extras_apply($id, $x),
            'extras_discard' => fn(?array $x) => car_extras_discard($x),
            'extras_empty'   => fn(?array $x): bool => car_extras_empty($x),
            'before_delete'  => fn(int $id, int $by) => car_before_delete($id, $by),
        ],

        'settings' => [
            'table' => null,
            'label' => 'Pengaturan',
            'fields' => [
                'company_name' => ['label' => 'Nama perusahaan', 't' => 'str', 'max' => 120, 'req' => true],
                'npwp'         => ['label' => 'NPWP', 't' => 'str', 'max' => 30],
                'email'        => ['label' => 'Email perusahaan', 't' => 'email', 'max' => 150],
                'phone'        => ['label' => 'Nomor telepon', 't' => 'str', 'max' => 30],
                'address'      => ['label' => 'Alamat', 't' => 'text', 'max' => 300],
            ],
            'title' => fn(array $d) => 'Profil Perusahaan',
        ],
    ];
    return $defs;
}

function entity_get(string $name): ?array
{
    return entity_defs()[$name] ?? null;
}

function settings_all(): array
{
    static $cache = null;
    if ($cache === null) {
        $cache = ['company_name' => 'Perusahaan Saya', 'npwp' => '', 'email' => '', 'phone' => '', 'address' => ''];
        foreach (rows('SELECT k, v FROM settings') as $r) {
            $cache[$r['k']] = $r['v'];
        }
    }
    return $cache;
}

// ---------- validasi ----------

/** @return array [clean, errors] */
function entity_clean(string $entity, array $in, ?int $id = null): array
{
    $def = entity_get($entity);
    $clean = [];
    $err = [];
    foreach ($def['fields'] as $f => $s) {
        $raw = isset($in[$f]) && (is_string($in[$f]) || is_int($in[$f])) ? trim((string)$in[$f]) : '';
        $label = $s['label'];
        if ($raw === '') {
            if (!empty($s['req'])) {
                $err[] = $label . ' wajib diisi.';
            } else {
                $clean[$f] = in_array($s['t'], ['str', 'text', 'email'], true) ? '' : null;
            }
            continue;
        }
        switch ($s['t']) {
            case 'str':
            case 'text':
            case 'email':
                if (mb_strlen($raw) > ($s['max'] ?? 255)) {
                    $err[] = $label . ' terlalu panjang (maks ' . ($s['max'] ?? 255) . ' karakter).';
                    break;
                }
                if ($s['t'] === 'email' && !filter_var($raw, FILTER_VALIDATE_EMAIL)) {
                    $err[] = $label . ' tidak valid.';
                    break;
                }
                $clean[$f] = $raw;
                break;
            case 'enum':
                if (!array_key_exists($raw, $s['values'])) {
                    $err[] = $label . ' tidak valid.';
                    break;
                }
                $clean[$f] = $raw;
                break;
            case 'fk':
                if (!ctype_digit($raw) || (int)val('SELECT COUNT(*) FROM ' . $s['table'] . ' WHERE id=?', [(int)$raw]) === 0) {
                    $err[] = $label . ' tidak ditemukan.';
                    break;
                }
                $clean[$f] = (int)$raw;
                break;
            case 'money':
                $t = preg_replace('/^Rp\s*/i', '', $raw);
                if (!preg_match('/^\d+$/', $t) && !preg_match('/^\d{1,3}(\.\d{3})+$/', $t)) {
                    $err[] = $label . ' harus berupa angka rupiah bulat (tanpa koma/desimal).';
                    break;
                }
                $n = (int)str_replace('.', '', $t);
                if ($n === 0 && empty($s['zero'])) {
                    $err[] = $label . ' harus lebih dari 0.';
                    break;
                }
                if ($n > 999999999999) {
                    $err[] = $label . ' terlalu besar.';
                    break;
                }
                $clean[$f] = $n;
                break;
            case 'int':
                if (!ctype_digit($raw) || strlen($raw) > 9 || (int)$raw < ($s['min'] ?? 0) || (int)$raw > ($s['max'] ?? 999999999)) {
                    $err[] = $label . ' tidak valid.';
                    break;
                }
                $clean[$f] = (int)$raw;
                break;
            case 'date':
                $d = DateTime::createFromFormat('Y-m-d', $raw);
                if (!$d || $d->format('Y-m-d') !== $raw || (int)$d->format('Y') < 2000 || (int)$d->format('Y') > 2100) {
                    $err[] = $label . ' tidak valid.';
                    break;
                }
                $clean[$f] = $raw;
                break;
            case 'month':
                if (!valid_month($raw)) {
                    $err[] = $label . ' tidak valid.';
                    break;
                }
                $clean[$f] = $raw;
                break;
        }
    }
    if (!$err && isset($def['prepare'])) {
        $def['prepare']($clean, $id);
    }
    if (!$err && isset($def['check'])) {
        $def['check']($clean, $id, $err);
    }
    return [$clean, $err];
}

// ---------- membaca data ----------

function entity_row(string $entity, ?int $id): ?array
{
    $def = entity_get($entity);
    if ($entity === 'settings') {
        return array_intersect_key(settings_all(), $def['fields']);
    }
    if (!$id) {
        return null;
    }
    $r = row('SELECT * FROM ' . $def['table'] . ' WHERE id=?', [$id]);
    return $r ? array_intersect_key($r, $def['fields']) : null;
}

function entity_display(string $entity, string $field, $value): string
{
    $s = entity_get($entity)['fields'][$field] ?? null;
    if ($value === null || $value === '') {
        return '-';
    }
    if (!$s) {
        return (string)$value;
    }
    switch ($s['t']) {
        case 'enum':
            return (string)($s['values'][$value] ?? $value);
        case 'fk':
            return (string)(val('SELECT name FROM ' . $s['table'] . ' WHERE id=?', [(int)$value]) ?? ('#' . $value));
        case 'money':
            return idr($value);
        case 'date':
            return date_id((string)$value);
        case 'month':
            return month_label((string)$value);
    }
    return (string)$value;
}

function change_summary(string $entity, string $action, array $data): string
{
    $def = entity_get($entity);
    $t = trim((string)$def['title']($data));
    if ($entity === 'settings') {
        return 'Ubah Pengaturan: Profil Perusahaan';
    }
    return ACTION_LABELS[$action] . ' ' . $def['label'] . ($t !== '' ? ': ' . $t : '');
}

/** Daftar [label, sebelum, sesudah] untuk ditampilkan ke super admin. */
function change_diff(array $req): array
{
    $entity = $req['entity'];
    $def = entity_get($entity);
    if (!$def) {
        return [];
    }
    $before = json_decode((string)$req['before_data'], true) ?: [];
    $after = json_decode((string)$req['payload'], true) ?: [];
    $out = [];
    foreach ($def['fields'] as $f => $s) {
        $b = $before[$f] ?? null;
        $a = $after[$f] ?? null;
        if ($req['action'] === 'create') {
            if ($a !== null && $a !== '') {
                $out[] = [$s['label'], '', entity_display($entity, $f, $a)];
            }
        } elseif ($req['action'] === 'delete') {
            if ($b !== null && $b !== '') {
                $out[] = [$s['label'], entity_display($entity, $f, $b), ''];
            }
        } elseif ((string)$b !== (string)$a) {
            $out[] = [$s['label'], entity_display($entity, $f, $b), entity_display($entity, $f, $a)];
        }
    }
    if ($entity === 'car' && $req['action'] === 'delete' && (int)val('SELECT COUNT(*) FROM cars WHERE id=? AND purchase_tx_id IS NOT NULL', [(int)$req['entity_id']]) > 0) {
        $out[] = ['Keuangan', 'Pembelian dibalik dengan transaksi pembatalan (riwayat tetap tersimpan)', ''];
    }
    if ($entity === 'car' && $req['action'] === 'update' && ($after['status'] ?? '') === 'terjual' && ($before['status'] ?? '') !== 'terjual') {
        $out[] = ['Keuangan', '', 'Pemasukan ' . idr($after['sold_received'] ?? 0) . ' dicatat' . ((int)($after['sold_price'] ?? 0) > (int)($after['sold_received'] ?? 0) ? '; sisa ' . idr((int)$after['sold_price'] - (int)$after['sold_received']) . ' menjadi piutang' : '')];
    }
    if ($entity === 'car' && $req['action'] === 'update' && ($before['status'] ?? '') === 'terjual' && ($after['status'] ?? '') !== 'terjual') {
        $out[] = ['Keuangan', 'Penjualan dibalik dengan transaksi pembatalan (pengeluaran)', ''];
    }
    if (isset($def['extras_diff']) && $req['action'] !== 'delete') {
        $x = $after['_x'] ?? null;
        if (is_array($x)) {
            foreach ($def['extras_diff']($x) as $row) {
                $out[] = $row;
            }
        }
    }
    return $out;
}

// ---------- menerapkan perubahan ----------

function entity_apply(string $entity, string $action, ?int $id, array $clean, int $by): int
{
    $def = entity_get($entity);
    if ($entity === 'settings') {
        foreach ($clean as $k => $v) {
            if ((int)val('SELECT COUNT(*) FROM settings WHERE k=?', [$k]) > 0) {
                q('UPDATE settings SET v=? WHERE k=?', [(string)$v, $k]);
            } else {
                q('INSERT INTO settings (k, v) VALUES (?, ?)', [$k, (string)$v]);
            }
        }
        return 0;
    }
    $t = $def['table'];
    $extras = $clean['_x'] ?? null;
    unset($clean['_x']);
    if ($action === 'create') {
        $newId = insert_row($t, $clean + $def['on_create']($by));
        if (isset($def['extras_apply'])) {
            $def['extras_apply']($newId, $extras);
        }
        if (isset($def['after_apply'])) {
            $def['after_apply']($newId, $by, null, 'create');
        }
        return $newId;
    }
    if ($action === 'update') {
        $prev = isset($def['after_apply']) ? row('SELECT * FROM ' . $t . ' WHERE id=?', [(int)$id]) : null;
        update_row($t, (int)$id, $clean + ($def['on_update'] ?? fn() => [])());
        if (isset($def['extras_apply'])) {
            $def['extras_apply']((int)$id, $extras);
        }
        if (isset($def['after_apply'])) {
            $def['after_apply']((int)$id, $by, $prev, 'update');
        }
        return (int)$id;
    }
    if (isset($def['before_delete'])) {
        $def['before_delete']((int)$id, $by);
    }
    delete_row($t, (int)$id);
    return (int)$id;
}

function pending_exists(string $entity, ?int $id): bool
{
    if ($entity === 'settings') {
        return (int)val("SELECT COUNT(*) FROM change_requests WHERE status='pending' AND entity='settings'") > 0;
    }
    return (int)val("SELECT COUNT(*) FROM change_requests WHERE status='pending' AND entity=? AND entity_id=? AND action<>'create'", [$entity, $id]) > 0;
}

/** @return array<int,string> entity_id => action yang masih menunggu */
function pending_map(string $entity, array $ids): array
{
    if (!$ids) {
        return [];
    }
    $out = [];
    $sql = "SELECT entity_id, action FROM change_requests WHERE status='pending' AND entity=? AND entity_id IN (" . in_placeholders($ids) . ')';
    foreach (rows($sql, array_merge([$entity], array_values($ids))) as $r) {
        $out[(int)$r['entity_id']] = $r['action'];
    }
    return $out;
}

function pending_total(): int
{
    return (int)val("SELECT COUNT(*) FROM change_requests WHERE status='pending'");
}

function pending_mine(int $uid): int
{
    return (int)val("SELECT COUNT(*) FROM change_requests WHERE status='pending' AND requested_by=?", [$uid]);
}

/**
 * Titik masuk semua perubahan data dari form.
 * @return array [bool ok, string pesan]
 */
function submit_change(string $entity, string $action, ?int $id, array $input): array
{
    $def = entity_get($entity);
    $u = current_user();
    if (!$def || !$u || !in_array($action, ['create', 'update', 'delete'], true)) {
        return [false, 'Permintaan tidak valid.'];
    }
    if ($entity === 'settings' && $action !== 'update') {
        return [false, 'Permintaan tidak valid.'];
    }
    if (!can_write()) {
        return [false, 'Akun Anda hanya memiliki akses lihat.'];
    }

    $before = [];
    if ($action !== 'create') {
        $before = entity_row($entity, $id);
        if ($before === null) {
            return [false, 'Data tidak ditemukan atau sudah dihapus.'];
        }
    }

    $op = '';
    if (isset($def['prepare_input']) && $action !== 'delete') {
        $op = (string)($input['op'] ?? '');
        $input = $def['prepare_input']($input, $id, $before, $action);
        if (isset($input['_error'])) {
            return [false, (string)$input['_error']];
        }
    }
    $clean = [];
    $extras = null;
    // Foto sementara harus dibersihkan jika pengajuan gagal di langkah mana pun.
    $bail = function (string $msg) use (&$extras, $def): array {
        if ($extras && isset($def['extras_discard'])) {
            $def['extras_discard']($extras);
        }
        return [false, $msg];
    };
    if ($action === 'delete') {
        if (isset($def['can_delete'])) {
            $msg = $def['can_delete']((int)$id);
            if ($msg) {
                return [false, $msg];
            }
        }
    } else {
        [$clean, $errs] = entity_clean($entity, $input, $id);
        if (isset($def['extras_clean'])) {
            $extras = $def['extras_clean']($input, $id, $errs);
        }
        if ($errs) {
            return $bail(implode(' ', $errs));
        }
        $hasExtras = $extras !== null && !$def['extras_empty']($extras);
        if ($action === 'update') {
            $changed = $hasExtras;
            foreach ($clean as $k => $v) {
                if ((string)($before[$k] ?? '') !== (string)$v) {
                    $changed = true;
                    break;
                }
            }
            if (!$changed) {
                return $bail('Tidak ada perubahan yang dilakukan.');
            }
        }
        if ($hasExtras) {
            $clean['_x'] = $extras;
        }
    }

    $merged = $action === 'delete' ? $before : array_diff_key($clean, ['_x' => 1]) + $before;
    $summary = (isset($def['summary']) ? $def['summary']($action, $merged, $op) : null) ?? change_summary($entity, $action, $merged);

    if (is_super()) {
        try {
            db()->beginTransaction();
            $newId = entity_apply($entity, $action, $id, $clean, (int)$u['id']);
            audit('langsung_' . $action, $entity, $newId ?: $id, $summary);
            db()->commit();
        } catch (Throwable $ex) {
            if (db()->inTransaction()) {
                db()->rollBack();
            }
            app_log('apply gagal: ' . $ex->getMessage());
            return $bail($ex instanceof RuntimeException ? $ex->getMessage() : 'Perubahan gagal disimpan. Pastikan data tidak sedang dipakai di tempat lain.');
        }
        return [true, 'Perubahan disimpan.'];
    }

    if (pending_exists($entity, $id) && $action !== 'create') {
        return $bail('Data ini masih memiliki permintaan yang menunggu persetujuan. Tunggu hingga diproses super admin.');
    }
    $rid = insert_row('change_requests', [
        'entity'       => $entity,
        'action'       => $action,
        'entity_id'    => $id,
        'summary'      => mb_substr($summary, 0, 255),
        'payload'      => json_encode($clean, JSON_UNESCAPED_UNICODE),
        'before_data'  => json_encode($before, JSON_UNESCAPED_UNICODE),
        'status'       => 'pending',
        'requested_by' => (int)$u['id'],
        'created_at'   => now_sql(),
    ]);
    audit('ajukan_' . $action, $entity, $id, $summary . ' (permintaan #' . $rid . ')');
    return [true, 'Perubahan diajukan dan menunggu persetujuan super admin.'];
}

/** @return array [bool ok, string pesan] */
function approve_request(int $reqId, int $adminId, string $note = ''): array
{
    $r = row("SELECT * FROM change_requests WHERE id=? AND status='pending'", [$reqId]);
    if (!$r) {
        return [false, 'Permintaan tidak ditemukan atau sudah diproses.'];
    }
    $entity = $r['entity'];
    $def = entity_get($entity);
    $action = $r['action'];
    $id = $r['entity_id'] !== null ? (int)$r['entity_id'] : null;
    if (!$def) {
        return [false, 'Jenis data tidak dikenal.'];
    }

    $clean = [];
    if ($action !== 'create' && $entity !== 'settings' && entity_row($entity, $id) === null) {
        return [false, 'Data target sudah tidak ada. Tolak permintaan ini.'];
    }
    if ($action === 'delete') {
        if (isset($def['can_delete']) && ($msg = $def['can_delete']((int)$id))) {
            return [false, $msg];
        }
    } else {
        $payload = json_decode((string)$r['payload'], true) ?: [];
        [$clean, $errs] = entity_clean($entity, $payload, $id);
        if ($errs) {
            return [false, 'Data tidak lagi valid: ' . implode(' ', $errs) . ' Tolak permintaan ini.'];
        }
        if (isset($payload['_x']) && is_array($payload['_x'])) {
            if (isset($def['extras_check']) && ($msg = $def['extras_check']($payload['_x']))) {
                return [false, $msg];
            }
            $clean['_x'] = $payload['_x'];
        }
    }
    try {
        db()->beginTransaction();
        // Kunci status lebih dulu: hanya satu pemanggilan yang bisa mengubah 'pending' -> 'approved'.
        $claim = q("UPDATE change_requests SET status='approved', reviewed_by=?, review_note=?, reviewed_at=? WHERE id=? AND status='pending'", [$adminId, mb_substr($note, 0, 255), now_sql(), $reqId]);
        if ($claim->rowCount() !== 1) {
            db()->rollBack();
            return [false, 'Permintaan sudah diproses.'];
        }
        $newId = entity_apply($entity, $action, $id, $clean, (int)$r['requested_by']);
        audit('setujui', $entity, $newId ?: $id, $r['summary'] . ' (permintaan #' . $reqId . ')');
        db()->commit();
    } catch (Throwable $ex) {
        if (db()->inTransaction()) {
            db()->rollBack();
        }
        app_log('approve gagal: ' . $ex->getMessage());
        return [false, $ex instanceof RuntimeException ? $ex->getMessage() : 'Gagal menerapkan perubahan. Data mungkin sedang dipakai di tempat lain.'];
    }
    return [true, 'Permintaan disetujui dan perubahan diterapkan.'];
}

function reject_request(int $reqId, int $adminId, string $note = ''): array
{
    $r = row("SELECT * FROM change_requests WHERE id=? AND status='pending'", [$reqId]);
    if (!$r) {
        return [false, 'Permintaan tidak ditemukan atau sudah diproses.'];
    }
    $def = entity_get((string)$r['entity']);
    $payload = json_decode((string)$r['payload'], true) ?: [];
    if ($def && isset($def['extras_discard']) && isset($payload['_x']) && is_array($payload['_x'])) {
        $def['extras_discard']($payload['_x']);
    }
    q("UPDATE change_requests SET status='rejected', reviewed_by=?, review_note=?, reviewed_at=? WHERE id=?", [$adminId, mb_substr($note, 0, 255), now_sql(), $reqId]);
    audit('tolak', $r['entity'], $r['entity_id'] !== null ? (int)$r['entity_id'] : null, $r['summary'] . ' (permintaan #' . $reqId . ')');
    return [true, 'Permintaan ditolak.'];
}
