<?php
declare(strict_types=1);

/** Query ringkasan untuk dashboard, analitik, dan laporan. */

function sum_range(string $from, string $to): array
{
    $out = ['income' => 0, 'expense' => 0];
    foreach (rows('SELECT type, COALESCE(SUM(amount),0) AS s FROM transactions WHERE tx_date>=? AND tx_date<=? GROUP BY type', [$from, $to]) as $r) {
        $out[$r['type']] = (int)$r['s'];
    }
    return $out;
}

function sum_month(string $ym): array
{
    return sum_range($ym . '-01', month_end($ym));
}

/** Daftar bulan untuk grafik: '6' | '12' (berakhir di $endYm) atau 'tahun' (Jan-Des tahun $endYm). */
function period_months(string $endYm, string $periode): array
{
    if ($periode === 'tahun') {
        $y = substr($endYm, 0, 4);
        return array_map(fn($m) => sprintf('%s-%02d', $y, $m), range(1, 12));
    }
    $n = $periode === '12' ? 12 : 6;
    $out = [];
    for ($i = $n - 1; $i >= 0; $i--) {
        $out[] = month_add($endYm, -$i);
    }
    return $out;
}

function monthly_series(array $months): array
{
    $inc = array_fill_keys($months, 0);
    $exp = array_fill_keys($months, 0);
    if ($months) {
        $from = $months[0] . '-01';
        $to = month_end(end($months));
        $sql = 'SELECT SUBSTR(tx_date,1,7) AS ym, type, COALESCE(SUM(amount),0) AS s FROM transactions WHERE tx_date>=? AND tx_date<=? GROUP BY SUBSTR(tx_date,1,7), type';
        foreach (rows($sql, [$from, $to]) as $r) {
            if ($r['type'] === 'income' && isset($inc[$r['ym']])) {
                $inc[$r['ym']] = (int)$r['s'];
            } elseif ($r['type'] === 'expense' && isset($exp[$r['ym']])) {
                $exp[$r['ym']] = (int)$r['s'];
            }
        }
    }
    return ['months' => $months, 'income' => array_values($inc), 'expense' => array_values($exp)];
}

function account_balances(): array
{
    $sums = [];
    foreach (rows('SELECT account_id, type, COALESCE(SUM(amount),0) AS s FROM transactions GROUP BY account_id, type') as $r) {
        $sums[(int)$r['account_id']][$r['type']] = (int)$r['s'];
    }
    $out = [];
    foreach (rows('SELECT * FROM accounts ORDER BY id') as $a) {
        $s = $sums[(int)$a['id']] ?? [];
        $a['balance'] = (int)$a['opening_balance'] + ($s['income'] ?? 0) - ($s['expense'] ?? 0);
        $out[] = $a;
    }
    return $out;
}

/** @return array<int,array{name:string,amount:int,color:string}> urut terbesar */
function expense_by_category(string $from, string $to): array
{
    $sql = "SELECT c.id, c.name, c.color, COALESCE(SUM(t.amount),0) AS s FROM transactions t JOIN categories c ON c.id=t.category_id
            WHERE t.type='expense' AND t.tx_date>=? AND t.tx_date<=? GROUP BY c.id, c.name, c.color ORDER BY s DESC";
    return array_map(fn($r) => ['name' => $r['name'], 'amount' => (int)$r['s'], 'color' => $r['color']], rows($sql, [$from, $to]));
}

/** @return array<int,int> category_id => total pada bulan tsb */
function category_totals(string $from, string $to): array
{
    $out = [];
    foreach (rows('SELECT category_id, COALESCE(SUM(amount),0) AS s FROM transactions WHERE tx_date>=? AND tx_date<=? GROUP BY category_id', [$from, $to]) as $r) {
        $out[(int)$r['category_id']] = (int)$r['s'];
    }
    return $out;
}

function budget_rows(string $ym): array
{
    $spent = category_totals($ym . '-01', month_end($ym));
    $out = [];
    foreach (rows('SELECT b.*, c.name AS category_name FROM budgets b JOIN categories c ON c.id=b.category_id WHERE b.month=? ORDER BY c.name', [$ym]) as $b) {
        $b['used'] = $spent[(int)$b['category_id']] ?? 0;
        $b['pct'] = (int)$b['amount'] > 0 ? (int)round($b['used'] / (int)$b['amount'] * 100) : 0;
        $out[] = $b;
    }
    return $out;
}

function invoice_status(array $inv): array
{
    if ($inv['status'] === 'paid') {
        return ['Lunas', 'green'];
    }
    if ($inv['due_date'] < today()) {
        return ['Jatuh tempo', 'red'];
    }
    return [$inv['kind'] === 'payable' ? 'Terjadwal' : 'Belum dibayar', 'yellow'];
}

function invoice_stats(): array
{
    $t = today();
    $soon = date('Y-m-d', strtotime('+7 days'));
    $s = [
        'recv_sum' => 0, 'recv_cnt' => 0, 'pay_sum' => 0, 'pay_cnt' => 0,
        'recv_overdue' => 0, 'pay_overdue' => 0, 'soon_sum' => 0,
    ];
    foreach (rows("SELECT kind, amount, due_date FROM invoices WHERE status='unpaid'") as $r) {
        $a = (int)$r['amount'];
        if ($r['kind'] === 'receivable') {
            $s['recv_sum'] += $a;
            $s['recv_cnt']++;
            $s['recv_overdue'] += $r['due_date'] < $t ? 1 : 0;
        } else {
            $s['pay_sum'] += $a;
            $s['pay_cnt']++;
            $s['pay_overdue'] += $r['due_date'] < $t ? 1 : 0;
        }
        if ($r['due_date'] <= $soon) {
            $s['soon_sum'] += $a;
        }
    }
    return $s;
}

/** Transaksi + nama kategori & akun, dengan filter. @return array [rows, total] */
function tx_list(array $f, int $page = 1, int $per = 10): array
{
    $where = ['1=1'];
    $p = [];
    if (!empty($f['q'])) {
        $where[] = '(t.name LIKE ? OR c.name LIKE ?)';
        $p[] = '%' . $f['q'] . '%';
        $p[] = '%' . $f['q'] . '%';
    }
    if (!empty($f['type'])) {
        $where[] = 't.type=?';
        $p[] = $f['type'];
    }
    if (!empty($f['from'])) {
        $where[] = 't.tx_date>=?';
        $p[] = $f['from'];
    }
    if (!empty($f['to'])) {
        $where[] = 't.tx_date<=?';
        $p[] = $f['to'];
    }
    $w = implode(' AND ', $where);
    $base = 'FROM transactions t JOIN categories c ON c.id=t.category_id JOIN accounts a ON a.id=t.account_id WHERE ' . $w;
    $total = (int)val('SELECT COUNT(*) ' . $base, $p);
    $limit = '';
    if ($per > 0) {
        $limit = ' LIMIT ' . $per . ' OFFSET ' . max(0, ($page - 1) * $per);
    }
    $r = rows('SELECT t.*, c.name AS category_name, a.name AS account_name ' . $base . ' ORDER BY t.tx_date DESC, t.id DESC' . $limit, $p);
    return [$r, $total];
}

/** Total saldo seluruh akun sampai (dan termasuk) tanggal tertentu. */
function balance_at(string $date): int
{
    $open = (int)val('SELECT COALESCE(SUM(opening_balance),0) FROM accounts');
    $t = sum_range('2000-01-01', $date);
    return $open + $t['income'] - $t['expense'];
}


// ---------- Ringkasan bisnis jual-beli mobil ----------

/** Rentang tanggal dashboard: hari ini | bulan terpilih | tahun terpilih | semua. */
function dash_range(string $rentang, string $ym): array
{
    switch ($rentang) {
        case 'hari':
            $t = today();
            $y = date('Y-m-d', strtotime($t . ' -1 day'));
            return ['from' => $t, 'to' => $t, 'pfrom' => $y, 'pto' => $y, 'label' => 'Hari ini', 'vs' => 'vs kemarin'];
        case 'tahun':
            $yr = (int)substr($ym, 0, 4);
            return ['from' => $yr . '-01-01', 'to' => $yr . '-12-31', 'pfrom' => ($yr - 1) . '-01-01', 'pto' => ($yr - 1) . '-12-31', 'label' => 'Tahun ' . $yr, 'vs' => 'vs tahun lalu'];
        case 'semua':
            return ['from' => '2000-01-01', 'to' => '2100-12-31', 'pfrom' => null, 'pto' => null, 'label' => 'Semua periode', 'vs' => ''];
        default:
            $pm = month_add($ym, -1);
            return ['from' => $ym . '-01', 'to' => month_end($ym), 'pfrom' => $pm . '-01', 'pto' => month_end($pm), 'label' => month_label($ym), 'vs' => 'vs bulan lalu'];
    }
}

/**
 * Definisi:
 *  arus kas bersih = uang masuk aktual - uang keluar aktual (semua transaksi final)
 *  laba kotor      = harga jual aktual - harga pokok, untuk mobil terjual pada periode
 *  laba bersih     = laba kotor + pemasukan lain (non-mobil) - biaya operasional (pengeluaran non-mobil)
 * Pembelian mobil TIDAK dihitung sebagai beban laba rugi (sudah menjadi harga pokok saat terjual).
 * Permintaan yang belum disetujui/ditolak tidak ada di tabel transaksi, jadi tidak ikut terhitung.
 */
function business_summary(string $from, string $to): array
{
    $o = ['income' => 0, 'expense' => 0, 'income_other' => 0, 'opex' => 0];
    foreach (rows('SELECT type, COALESCE(SUM(amount),0) AS s, COALESCE(SUM(CASE WHEN ref_type IS NULL THEN amount ELSE 0 END),0) AS o FROM transactions WHERE tx_date>=? AND tx_date<=? GROUP BY type', [$from, $to]) as $r) {
        if ($r['type'] === 'income') {
            $o['income'] = (int)$r['s'];
            $o['income_other'] = (int)$r['o'];
        } else {
            $o['expense'] = (int)$r['s'];
            $o['opex'] = (int)$r['o'];
        }
    }
    $c = row("SELECT COUNT(*) AS n, COALESCE(SUM(sold_price),0) AS rev, COALESCE(SUM(purchase_price),0) AS cogs FROM cars WHERE status='terjual' AND sold_at>=? AND sold_at<=?", [$from, $to]);
    $o['sold_count'] = (int)$c['n'];
    $o['revenue'] = (int)$c['rev'];
    $o['cogs'] = (int)$c['cogs'];
    $o['net_cash'] = $o['income'] - $o['expense'];
    $o['gross_profit'] = $o['revenue'] - $o['cogs'];
    $o['net_profit'] = $o['gross_profit'] + $o['income_other'] - $o['opex'];
    return $o;
}

/** Ringkasan inventaris (kondisi saat ini). Stok aktif = tersedia + dipesan. */
function car_stock_summary(): array
{
    $r = row("SELECT
        COALESCE(SUM(CASE WHEN status='tersedia' THEN 1 ELSE 0 END),0) AS available,
        COALESCE(SUM(CASE WHEN status='dipesan' THEN 1 ELSE 0 END),0) AS reserved,
        COALESCE(SUM(CASE WHEN status='terjual' THEN 1 ELSE 0 END),0) AS sold,
        COALESCE(SUM(CASE WHEN status<>'terjual' THEN purchase_price ELSE 0 END),0) AS capital
        FROM cars");
    $active = (int)$r['available'] + (int)$r['reserved'];
    return [
        'available' => (int)$r['available'], 'reserved' => (int)$r['reserved'], 'active' => $active,
        'sold' => (int)$r['sold'], 'capital' => (int)$r['capital'],
        'avg' => $active > 0 ? (int)round((int)$r['capital'] / $active) : 0,
    ];
}
