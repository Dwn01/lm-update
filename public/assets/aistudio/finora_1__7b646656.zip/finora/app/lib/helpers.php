<?php
declare(strict_types=1);

const MONTHS_SHORT = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
const MONTHS_LONG  = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];

function cfg(string $key, $default = null)
{
    $v = $GLOBALS['CONFIG'] ?? [];
    foreach (explode('.', $key) as $k) {
        if (!is_array($v) || !array_key_exists($k, $v)) {
            return $default;
        }
        $v = $v[$k];
    }
    return $v;
}

function e($s): string
{
    return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function url(string $path = '/'): string
{
    return rtrim((string)cfg('base_path', ''), '/') . $path;
}

function idr($n): string
{
    $n = (int)$n;
    return ($n < 0 ? '-' : '') . 'Rp ' . number_format(abs($n), 0, ',', '.');
}

/** 1250000 -> 1,3jt ; 40000000 -> 40jt */
function idr_short($n): string
{
    $a = abs((float)$n);
    $s = $n < 0 ? '-' : '';
    if ($a >= 1e9) {
        return $s . rtrim(rtrim(number_format($a / 1e9, 1, ',', '.'), '0'), ',') . 'M';
    }
    if ($a >= 1e6) {
        return $s . rtrim(rtrim(number_format($a / 1e6, 1, ',', '.'), '0'), ',') . 'jt';
    }
    if ($a >= 1e3) {
        return $s . number_format($a / 1e3, 0, ',', '.') . 'rb';
    }
    return $s . (string)(int)$a;
}

function date_id(?string $d): string
{
    if (!$d) {
        return '-';
    }
    $t = strtotime($d);
    if (!$t) {
        return '-';
    }
    return date('j', $t) . ' ' . MONTHS_SHORT[(int)date('n', $t) - 1] . ' ' . date('Y', $t);
}

function datetime_id(?string $d): string
{
    if (!$d) {
        return '-';
    }
    $t = strtotime($d);
    return $t ? date_id($d) . ', ' . date('H:i', $t) : '-';
}

function month_label(string $ym, bool $short = false): string
{
    if (!preg_match('/^(\d{4})-(\d{2})$/', $ym, $m)) {
        return $ym;
    }
    $i = (int)$m[2] - 1;
    return $short ? MONTHS_SHORT[$i] : MONTHS_LONG[$i] . ' ' . $m[1];
}

function valid_month(?string $ym): bool
{
    return is_string($ym) && (bool)preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $ym);
}

function month_add(string $ym, int $n): string
{
    return date('Y-m', strtotime($ym . '-01 ' . ($n >= 0 ? '+' : '') . $n . ' month'));
}

function month_end(string $ym): string
{
    return date('Y-m-t', strtotime($ym . '-01'));
}

function pct_change(float $now, float $prev): ?float
{
    if ($prev == 0.0) {
        return $now == 0.0 ? 0.0 : null;
    }
    return ($now - $prev) / abs($prev) * 100;
}

function pct_text(?float $p): string
{
    return $p === null ? 'baru' : number_format(abs($p), 1, ',', '.') . '%';
}

function now_sql(): string
{
    return date('Y-m-d H:i:s');
}

function today(): string
{
    return date('Y-m-d');
}

// ---------- request / response ----------

function req(string $key, string $default = ''): string
{
    $v = $_POST[$key] ?? $_GET[$key] ?? $default;
    return is_string($v) ? trim($v) : $default;
}

function is_post(): bool
{
    return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
}

function is_https(): bool
{
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        return true;
    }
    return (bool)cfg('trust_proxy') && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https';
}

function client_ip(): string
{
    if (cfg('trust_proxy')) {
        foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR'] as $h) {
            if (!empty($_SERVER[$h])) {
                $ip = trim(explode(',', (string)$_SERVER[$h])[0]);
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
    }
    return (string)($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
}

function ip_in_list(string $ip, array $list): bool
{
    foreach ($list as $entry) {
        $entry = trim((string)$entry);
        if ($entry === '') {
            continue;
        }
        if (strpos($entry, '/') === false) {
            if ($ip === $entry) {
                return true;
            }
            continue;
        }
        [$subnet, $bits] = explode('/', $entry, 2);
        $ipBin = @inet_pton($ip);
        $subBin = @inet_pton($subnet);
        if ($ipBin === false || $subBin === false || strlen($ipBin) !== strlen($subBin)) {
            continue;
        }
        $bits = (int)$bits;
        $bytes = intdiv($bits, 8);
        $rem = $bits % 8;
        if ($bytes > 0 && substr($ipBin, 0, $bytes) !== substr($subBin, 0, $bytes)) {
            continue;
        }
        if ($rem === 0) {
            return true;
        }
        $mask = (0xFF << (8 - $rem)) & 0xFF;
        if ((ord($ipBin[$bytes]) & $mask) === (ord($subBin[$bytes]) & $mask)) {
            return true;
        }
    }
    return false;
}

function redirect(string $to): void
{
    header('Location: ' . $to);
    exit;
}

/** Hanya izinkan redirect ke path internal. */
function safe_return(?string $r, string $default = '/'): string
{
    if (!$r || $r[0] !== '/' || str_starts_with($r, '//') || strpos($r, '\\') !== false || preg_match('/[\r\n]/', $r)) {
        return url($default);
    }
    return $r;
}

function flash(string $type, string $msg): void
{
    $_SESSION['flash'][] = ['type' => $type, 'msg' => $msg];
}

function flashes(): array
{
    $f = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $f;
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">';
}

function csrf_ok(): bool
{
    $t = $_POST['_csrf'] ?? '';
    return is_string($t) && !empty($_SESSION['csrf']) && hash_equals($_SESSION['csrf'], $t);
}

function json_attr($data): string
{
    return e(json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
}

function initials(string $name): string
{
    $parts = preg_split('/\s+/', trim($name)) ?: [];
    $s = '';
    foreach (array_slice($parts, 0, 2) as $p) {
        $s .= mb_strtoupper(mb_substr($p, 0, 1));
    }
    return $s !== '' ? $s : '?';
}

function greeting(): string
{
    $h = (int)date('G');
    return $h < 11 ? 'pagi' : ($h < 15 ? 'siang' : ($h < 18 ? 'sore' : 'malam'));
}

function app_log(string $msg): void
{
    @error_log('[finora] ' . $msg);
}
