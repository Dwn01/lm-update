<?php
declare(strict_types=1);

function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }
    $c = cfg('db', []);
    $opts = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ];
    if (($c['driver'] ?? 'mysql') === 'sqlite') {
        $path = (string)($c['sqlite_path'] ?? (APP_ROOT . '/storage/finora.sqlite'));
        if (!is_dir(dirname($path))) {
            mkdir(dirname($path), 0750, true);
        }
        $pdo = new PDO('sqlite:' . $path, null, null, $opts);
        $pdo->exec('PRAGMA foreign_keys = ON');
    } else {
        $dsn = sprintf(
            'mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
            $c['host'] ?? '127.0.0.1',
            (int)($c['port'] ?? 3306),
            $c['name'] ?? 'finora'
        );
        $opts[PDO::ATTR_EMULATE_PREPARES] = false;
        $pdo = new PDO($dsn, (string)($c['user'] ?? ''), (string)($c['pass'] ?? ''), $opts);
    }
    return $pdo;
}

function db_driver(): string
{
    return (string)cfg('db.driver', 'mysql');
}

function q(string $sql, array $params = []): PDOStatement
{
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st;
}

function rows(string $sql, array $params = []): array
{
    return q($sql, $params)->fetchAll();
}

function row(string $sql, array $params = []): ?array
{
    $r = q($sql, $params)->fetch();
    return $r === false ? null : $r;
}

function val(string $sql, array $params = [])
{
    $r = q($sql, $params)->fetchColumn();
    return $r === false ? null : $r;
}

function insert_row(string $table, array $data): int
{
    $cols = array_keys($data);
    $sql = 'INSERT INTO ' . $table . ' (' . implode(',', $cols) . ') VALUES (' . implode(',', array_fill(0, count($cols), '?')) . ')';
    q($sql, array_values($data));
    return (int)db()->lastInsertId();
}

function update_row(string $table, int $id, array $data): void
{
    $set = implode(',', array_map(fn($c) => $c . '=?', array_keys($data)));
    q('UPDATE ' . $table . ' SET ' . $set . ' WHERE id=?', array_merge(array_values($data), [$id]));
}

function delete_row(string $table, int $id): void
{
    q('DELETE FROM ' . $table . ' WHERE id=?', [$id]);
}

function in_placeholders(array $values): string
{
    return implode(',', array_fill(0, count($values), '?'));
}
