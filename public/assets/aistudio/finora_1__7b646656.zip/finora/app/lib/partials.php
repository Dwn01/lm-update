<?php
declare(strict_types=1);

/** Tombol Edit + Hapus untuk satu baris/kartu. */
function row_actions(string $entity, string $dialogId, array $rowData, bool $disabled = false, string $wrapClass = 'row-actions'): string
{
    if (!can_write()) {
        return '';
    }
    $dis = $disabled ? ' disabled title="Menunggu persetujuan"' : '';
    $confirm = is_super() ? 'Hapus data ini? Tindakan ini tidak dapat dibatalkan.' : 'Ajukan penghapusan data ini? Penghapusan baru berlaku setelah disetujui super admin.';
    $h = '<div class="' . $wrapClass . '">';
    $h .= '<button type="button" data-dialog="' . e($dialogId) . '" data-mode="update" data-row="' . json_attr($rowData) . '" title="Edit"' . $dis . '>' . icon('edit', 17) . '</button>';
    $h .= '<form method="post" action="' . e(url('/aksi')) . '" data-confirm="' . e($confirm) . '">'
        . action_fields($entity, 'delete')
        . '<input type="hidden" name="id" value="' . (int)$rowData['id'] . '">'
        . '<button type="submit" class="del" title="Hapus"' . $dis . '>' . icon('trash', 17) . '</button></form>';
    return $h . '</div>';
}

function pending_chip(?string $action): string
{
    if (!$action) {
        return '';
    }
    return ' ' . badge('Menunggu: ' . (ACTION_LABELS[$action] ?? $action), 'yellow');
}

/** Tabel transaksi (dashboard & halaman transaksi). */
function tx_table(array $rows, bool $actions = false, array $pending = []): string
{
    $canAct = $actions && can_write();
    $h = '<div class="table-wrap"><table class="tx-table"><thead><tr><th>Transaksi</th><th>Kategori</th><th>Tanggal</th><th>Akun</th><th>Jumlah</th>' . ($canAct ? '<th class="actions"></th>' : '') . '</tr></thead><tbody>';
    foreach ($rows as $t) {
        $in = $t['type'] === 'income';
        $h .= '<tr><td><div class="transaction-name"><span class="transaction-icon ' . ($in ? 'income' : 'expense') . '">' . icon($in ? 'arrowDown' : 'arrowUp', 17) . '</span>'
            . '<div><strong>' . e($t['name']) . '</strong><small>' . ($in ? 'Pemasukan' : 'Pengeluaran') . pending_chip($pending[(int)$t['id']] ?? null) . (!empty($t['ref_type']) ? ' ' . badge('Otomatis · Stok Mobil', 'blue') : '') . '</small></div></div></td>'
            . '<td>' . badge($t['category_name']) . '</td><td>' . e(date_id($t['tx_date'])) . '</td><td>' . e($t['account_name']) . '</td>'
            . '<td class="' . ($in ? 'amount-in' : 'amount-out') . '">' . ($in ? '+' : '-') . e(idr($t['amount'])) . '</td>';
        if ($canAct) {
            $row = [
                'id' => (int)$t['id'], 'type' => $t['type'], 'name' => $t['name'], 'category_id' => (int)$t['category_id'],
                'account_id' => (int)$t['account_id'], 'amount' => (int)$t['amount'], 'tx_date' => $t['tx_date'], 'note' => $t['note'],
            ];
            $h .= '<td class="actions">' . (!empty($t['ref_type']) ? '<small class="muted" title="Dibuat otomatis; koreksi lewat Stok Mobil">Terkunci</small>' : row_actions('transaction', 'dlg-tx', $row, isset($pending[(int)$t['id']]))) . '</td>';
        }
        $h .= '</tr>';
    }
    $h .= '</tbody></table>';
    if (!$rows) {
        $h .= '<div class="empty-state">Belum ada transaksi yang sesuai.</div>';
    }
    return $h . '</div>';
}

/** Dialog tambah/ubah transaksi (dipakai di Dashboard dan Transaksi). */
function tx_dialog(): string
{
    if (!can_write()) {
        return '';
    }
    $cats = rows('SELECT id, name, type FROM categories ORDER BY name');
    $accs = rows('SELECT id, name FROM accounts ORDER BY id');
    $h = '<dialog class="modal" id="dlg-tx"><div class="modal-head"><div>'
        . '<div class="card-title" data-title-create>Tambah Transaksi</div><div class="card-title" data-title-update hidden>Edit Transaksi</div>'
        . '<div class="card-subtitle">Catat aktivitas keuangan perusahaan</div></div>'
        . '<button class="icon-button" type="button" data-close aria-label="Tutup">' . icon('close') . '</button></div>'
        . '<form method="post" action="' . e(url('/aksi')) . '">' . action_fields('transaction', 'create') . '<input type="hidden" name="id" value="">';
    if (!is_super()) {
        $h .= '<div class="modal-note">Perubahan akan diajukan dan baru berlaku setelah disetujui super admin.</div>';
    }
    $h .= '<div class="type-switch"><label><input type="radio" name="type" value="income" checked><span>' . icon('arrowDown', 17) . ' Pemasukan</span></label>'
        . '<label><input type="radio" name="type" value="expense"><span>' . icon('arrowUp', 17) . ' Pengeluaran</span></label></div>'
        . '<label class="field">Nama transaksi<input type="text" name="name" required maxlength="150" placeholder="Contoh: Pembayaran pelanggan"></label>'
        . '<div class="form-grid">'
        . '<label class="field">Kategori<select name="category_id" required><option value="">Pilih kategori</option>';
    foreach ($cats as $c) {
        $h .= '<option value="' . (int)$c['id'] . '" data-type="' . e($c['type']) . '">' . e($c['name']) . '</option>';
    }
    $h .= '</select></label><label class="field">Akun / metode pembayaran<select name="account_id" required><option value="">Pilih akun</option>';
    foreach ($accs as $a) {
        $h .= '<option value="' . (int)$a['id'] . '">' . e($a['name']) . '</option>';
    }
    $h .= '</select></label>'
        . '<label class="field">Jumlah (Rp)<input type="number" name="amount" required min="1" step="1" inputmode="numeric" placeholder="0"></label>'
        . '<label class="field">Tanggal<input type="date" name="tx_date" required value="' . e(today()) . '"></label></div>'
        . '<label class="field">Catatan<textarea name="note" maxlength="500" placeholder="Tambahkan catatan opsional..."></textarea></label>'
        . '<div class="modal-actions"><button type="button" class="secondary-button" data-close>Batal</button><button class="primary-button" type="submit">' . (is_super() ? 'Simpan Transaksi' : 'Ajukan Perubahan') . '</button></div>'
        . '</form></dialog>';
    return $h;
}

function add_button(string $label, string $dialogId, array $defaults = []): string
{
    if (!can_write()) {
        return '';
    }
    return '<button class="primary-button" type="button" data-dialog="' . e($dialogId) . '" data-mode="create"'
        . ($defaults ? ' data-defaults="' . json_attr($defaults) . '"' : '') . '>' . icon('plus', 18) . ' ' . e($label) . '</button>';
}

function submit_label(string $base = 'Simpan'): string
{
    return is_super() ? $base : 'Ajukan Perubahan';
}

function approval_note(): string
{
    return is_super() ? '' : '<div class="modal-note">Perubahan akan diajukan dan baru berlaku setelah disetujui super admin.</div>';
}

/** Spanduk jumlah permintaan yang menunggu (khusus pengguna biasa). */
function pending_banner(): string
{
    $u = current_user();
    if (!$u || is_super()) {
        return '';
    }
    $n = pending_mine((int)$u['id']);
    if ($n < 1) {
        return '';
    }
    return '<div class="notice"><span>' . $n . ' perubahan Anda menunggu persetujuan super admin.</span><a href="' . e(url('/permintaan')) . '">Lihat permintaan</a></div>';
}

function modal_head(string $titleCreate, string $titleUpdate, string $subtitle): string
{
    return '<div class="modal-head"><div><div class="card-title" data-title-create>' . e($titleCreate) . '</div><div class="card-title" data-title-update hidden>' . e($titleUpdate) . '</div>'
        . '<div class="card-subtitle">' . e($subtitle) . '</div></div><button class="icon-button" type="button" data-close aria-label="Tutup">' . icon('close') . '</button></div>';
}
