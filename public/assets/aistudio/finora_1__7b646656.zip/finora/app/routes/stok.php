<?php
declare(strict_types=1);

// Perubahan stok (tambah/ubah/hapus + foto) lewat POST /aksi (entity 'car') sehingga
// pengguna biasa masuk antrean persetujuan super admin; super admin langsung diterapkan.

route('GET', '/stok-mobil', function () {
    $tab = req('tab') === 'terjual' ? 'terjual' : 'aktif';
    $q = mb_substr(trim(req('q')), 0, 80);
    $status = in_array(req('status'), ['tersedia','dipesan'], true) ? req('status') : '';
    $bulan = valid_month(req('bulan')) ? req('bulan') : '';
    $where = []; $params = [];
    if ($q !== '') { $where[] = '(brand LIKE ? OR model LIKE ? OR plate_number LIKE ? OR buyer_name LIKE ?)'; $like = '%' . $q . '%'; array_push($params, $like, $like, $like, $like); }
    if ($tab === 'terjual') {
        $where[] = "status='terjual'";
        if ($bulan !== '') { $where[] = 'sold_at>=? AND sold_at<=?'; array_push($params, $bulan . '-01', month_end($bulan)); }
        $order = 'c.sold_at DESC, c.id DESC';
    } else {
        $where[] = "status IN ('tersedia','dipesan')";
        if ($status !== '') { $where[] = 'status=?'; $params[] = $status; }
        $order = 'c.created_at DESC, c.id DESC';
    }
    $cover = '(SELECT path FROM car_photos p WHERE p.car_id=c.id ORDER BY p.is_primary DESC, p.id ASC LIMIT 1) AS cover';
    $cars = rows("SELECT c.*, $cover FROM cars c WHERE " . implode(' AND ', $where) . " ORDER BY $order", $params);
    $stats = [
      'active' => (int)val("SELECT COUNT(*) FROM cars WHERE status<>'terjual'"),
      'available' => (int)val("SELECT COUNT(*) FROM cars WHERE status='tersedia'"),
      'reserved' => (int)val("SELECT COUNT(*) FROM cars WHERE status='dipesan'"),
      'capital' => (int)val("SELECT COALESCE(SUM(purchase_price),0) FROM cars WHERE status<>'terjual'"),
      'sold_all' => (int)val("SELECT COUNT(*) FROM cars WHERE status='terjual'"),
    ];
    // ringkasan daftar terjual (mengikuti filter)
    $sold = ['count' => count($cars), 'revenue' => 0, 'profit' => 0];
    if ($tab === 'terjual') {
        foreach ($cars as $c) {
            $sold['revenue'] += (int)$c['sold_price'];
            $sold['profit'] += (int)$c['sold_price'] - (int)$c['purchase_price'];
        }
    }
    $editId = can_write() && ctype_digit(req('edit')) ? (int)req('edit') : 0;
    $edit = $editId ? row('SELECT * FROM cars WHERE id=?', [$editId]) : null;
    if ($edit) {
        $edit['photos'] = rows('SELECT * FROM car_photos WHERE car_id=? ORDER BY is_primary DESC,id', [$editId]);
    }
    render('stok_mobil', [
        'cars'=>$cars, 'pending'=>pending_map('car', array_column($cars, 'id')), 'stats'=>$stats, 'sold'=>$sold,
        'tab'=>$tab, 'q'=>$q, 'status'=>$status, 'bulan'=>$bulan, 'edit'=>$edit,
        'accounts'=>rows('SELECT id, name FROM accounts ORDER BY name'),
    ], ['title'=>'Stok Mobil','active'=>'/stok-mobil']);
});
