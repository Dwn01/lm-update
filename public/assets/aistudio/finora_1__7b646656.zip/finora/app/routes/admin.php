<?php
declare(strict_types=1);

// ---------- Antrean persetujuan ----------
route('GET', '/persetujuan', function () {
    $status = in_array(req('status'), ['pending', 'approved', 'rejected'], true) ? req('status') : 'pending';
    $list = rows(
        'SELECT r.*, u.name AS requester, v.name AS reviewer FROM change_requests r
         JOIN users u ON u.id=r.requested_by LEFT JOIN users v ON v.id=r.reviewed_by
         WHERE r.status=? ORDER BY r.id ' . ($status === 'pending' ? 'ASC' : 'DESC') . ' LIMIT 100',
        [$status]
    );
    $counts = ['pending' => 0, 'approved' => 0, 'rejected' => 0];
    foreach (rows('SELECT status, COUNT(*) AS n FROM change_requests GROUP BY status') as $c) {
        $counts[$c['status']] = (int)$c['n'];
    }
    foreach ($list as &$r) {
        $r['diff'] = change_diff($r);
        $x = (json_decode((string)$r['payload'], true) ?: [])['_x'] ?? [];
        $r['photos_add'] = array_values(array_filter((array)($x['add'] ?? []), fn($n) => is_string($n) && preg_match(CAR_STAGE_RE, $n)));
        $r['photos_rm'] = [];
        if ($r['status'] === 'pending' && !empty($x['remove']) && $r['entity_id']) {
            $r['photos_rm'] = array_column(rows('SELECT path FROM car_photos WHERE car_id=? AND id IN (' . in_placeholders($x['remove']) . ')', array_merge([(int)$r['entity_id']], array_map('intval', $x['remove']))), 'path');
        }
    }
    unset($r);
    render('persetujuan', ['list' => $list, 'status' => $status, 'counts' => $counts], ['title' => 'Persetujuan', 'active' => '/persetujuan']);
}, ['admin' => true]);

// Pratinjau foto yang masih menunggu persetujuan (disimpan di luar docroot).
route('GET', '/persetujuan/foto', function () {
    $f = req('f');
    $file = car_stage_dir() . '/' . $f;
    if (!preg_match(CAR_STAGE_RE, $f) || !is_file($file)) {
        http_response_code(404);
        exit('Tidak ditemukan.');
    }
    $types = ['jpg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp'];
    header('Content-Type: ' . $types[pathinfo($f, PATHINFO_EXTENSION)]);
    header('Content-Length: ' . filesize($file));
    header('Cache-Control: private, max-age=300');
    readfile($file);
}, ['admin' => true]);

route('POST', '/persetujuan/proses', function () {
    $id = (int)req('id');
    $note = mb_substr(req('note'), 0, 255);
    $admin = current_user();
    if (req('keputusan') === 'setuju') {
        [$ok, $msg] = approve_request($id, (int)$admin['id'], $note);
    } elseif (req('keputusan') === 'tolak') {
        [$ok, $msg] = reject_request($id, (int)$admin['id'], $note);
    } else {
        [$ok, $msg] = [false, 'Keputusan tidak valid.'];
    }
    flash($ok ? 'success' : 'error', $msg);
    redirect(url('/persetujuan'));
}, ['admin' => true]);

// ---------- Pengguna ----------
function gen_password(int $len = 12): string
{
    $chars = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    do {
        $p = '';
        for ($i = 0; $i < $len; $i++) {
            $p .= $chars[random_int(0, strlen($chars) - 1)];
        }
    } while (!preg_match('/[A-Za-z]/', $p) || !preg_match('/\d/', $p));
    return $p;
}

route('GET', '/pengguna', function () {
    $users = rows("SELECT * FROM users ORDER BY CASE role WHEN 'super_admin' THEN 0 ELSE 1 END, name");
    $newCred = $_SESSION['new_cred'] ?? null;
    unset($_SESSION['new_cred']);
    render('pengguna', ['users' => $users, 'newCred' => $newCred, 'me' => current_user()], ['title' => 'Pengguna', 'active' => '/pengguna']);
}, ['admin' => true]);

route('POST', '/pengguna/tambah', function () {
    $name = mb_substr(req('name'), 0, 100);
    $username = mb_strtolower(req('username'));
    $email = mb_substr(req('email'), 0, 150);
    $role = req('role');
    $err = [];
    if ($name === '') {
        $err[] = 'Nama wajib diisi.';
    }
    if (!preg_match('/^[a-z0-9._-]{3,50}$/', $username)) {
        $err[] = 'Username 3-50 karakter: huruf kecil, angka, titik, strip, atau garis bawah.';
    }
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $err[] = 'Email tidak valid.';
    }
    if (!in_array($role, ['user', 'viewer'], true)) {
        $err[] = 'Peran tidak valid.';
    }
    if (!$err && (int)val('SELECT COUNT(*) FROM users WHERE username=?', [$username]) > 0) {
        $err[] = 'Username sudah dipakai.';
    }
    if ($err) {
        flash('error', implode(' ', $err));
        redirect(url('/pengguna'));
    }
    $pw = gen_password();
    $id = insert_row('users', [
        'name' => $name, 'username' => $username, 'email' => $email, 'password_hash' => password_hash($pw, PASSWORD_DEFAULT),
        'role' => $role, 'is_active' => 1, 'must_change_password' => 1, 'created_at' => now_sql(),
    ]);
    audit('buat_pengguna', 'user', $id, $username . ' (' . $role . ')');
    $_SESSION['new_cred'] = ['name' => $name, 'username' => $username, 'password' => $pw];
    redirect(url('/pengguna'));
}, ['admin' => true]);

/** Ambil target pengguna biasa (bukan diri sendiri, bukan super admin). */
function target_user(): ?array
{
    $u = row('SELECT * FROM users WHERE id=?', [(int)req('id')]);
    $me = current_user();
    if (!$u || (int)$u['id'] === (int)$me['id'] || $u['role'] === 'super_admin') {
        flash('error', 'Pengguna tidak ditemukan atau tidak dapat diubah dari sini.');
        redirect(url('/pengguna'));
    }
    return $u;
}

route('POST', '/pengguna/reset-password', function () {
    $u = target_user();
    $pw = gen_password();
    update_row('users', (int)$u['id'], ['password_hash' => password_hash($pw, PASSWORD_DEFAULT), 'must_change_password' => 1]);
    audit('reset_password', 'user', (int)$u['id'], $u['username']);
    $_SESSION['new_cred'] = ['name' => $u['name'], 'username' => $u['username'], 'password' => $pw];
    redirect(url('/pengguna'));
}, ['admin' => true]);

route('POST', '/pengguna/status', function () {
    $u = target_user();
    $new = (int)$u['is_active'] === 1 ? 0 : 1;
    update_row('users', (int)$u['id'], ['is_active' => $new]);
    audit($new ? 'aktifkan_pengguna' : 'nonaktifkan_pengguna', 'user', (int)$u['id'], $u['username']);
    flash('success', 'Pengguna ' . $u['username'] . ($new ? ' diaktifkan.' : ' dinonaktifkan.'));
    redirect(url('/pengguna'));
}, ['admin' => true]);

route('POST', '/pengguna/peran', function () {
    $u = target_user();
    $role = req('role');
    if (!in_array($role, ['user', 'viewer'], true)) {
        flash('error', 'Peran tidak valid.');
        redirect(url('/pengguna'));
    }
    update_row('users', (int)$u['id'], ['role' => $role]);
    audit('ubah_peran', 'user', (int)$u['id'], $u['username'] . ' -> ' . $role);
    flash('success', 'Peran ' . $u['username'] . ' diubah menjadi ' . ROLE_LABELS[$role] . '.');
    redirect(url('/pengguna'));
}, ['admin' => true]);

// ---------- Log audit ----------
route('GET', '/audit', function () {
    $page = max(1, (int)req('page', '1'));
    $per = 25;
    $f = mb_substr(req('q'), 0, 60);
    $where = '1=1';
    $p = [];
    if ($f !== '') {
        $where = '(l.action LIKE ? OR l.detail LIKE ? OR u.username LIKE ? OR l.ip LIKE ?)';
        $p = array_fill(0, 4, '%' . $f . '%');
    }
    $total = (int)val("SELECT COUNT(*) FROM audit_logs l LEFT JOIN users u ON u.id=l.user_id WHERE $where", $p);
    $pages = max(1, (int)ceil($total / $per));
    $page = min($page, $pages);
    $list = rows("SELECT l.*, u.username FROM audit_logs l LEFT JOIN users u ON u.id=l.user_id WHERE $where ORDER BY l.id DESC LIMIT $per OFFSET " . (($page - 1) * $per), $p);
    render('audit', ['list' => $list, 'total' => $total, 'page' => $page, 'pages' => $pages, 'q' => $f], ['title' => 'Log Audit', 'active' => '/audit']);
}, ['admin' => true]);
