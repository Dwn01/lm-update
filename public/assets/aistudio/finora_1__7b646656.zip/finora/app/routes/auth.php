<?php
declare(strict_types=1);

route('GET', '/masuk', function () {
    if (current_user()) {
        redirect(url('/'));
    }
    render('login', ['username' => ''], ['layout' => 'bare', 'title' => 'Masuk']);
}, ['public' => true]);

route('POST', '/masuk', function () {
    $username = (string)($_POST['username'] ?? '');
    $password = (string)($_POST['password'] ?? '');
    [$st, $msg] = try_login($username, $password);
    if ($st === 'ok') {
        $to = safe_return($_SESSION['intended'] ?? null, '/');
        unset($_SESSION['intended']);
        redirect($to);
    }
    if ($st === '2fa') {
        redirect(url('/masuk/2fa'));
    }
    flash('error', $msg);
    redirect(url('/masuk'));
}, ['public' => true]);

route('GET', '/masuk/2fa', function () {
    if (empty($_SESSION['pre2fa'])) {
        redirect(url('/masuk'));
    }
    render('login_2fa', [], ['layout' => 'bare', 'title' => 'Verifikasi 2FA']);
}, ['public' => true]);

route('POST', '/masuk/2fa', function () {
    if (empty($_SESSION['pre2fa'])) {
        redirect(url('/masuk'));
    }
    if (verify_2fa_login((string)($_POST['code'] ?? ''))) {
        $to = safe_return($_SESSION['intended'] ?? null, '/');
        unset($_SESSION['intended']);
        redirect($to);
    }
    if (empty($_SESSION['pre2fa'])) {
        flash('error', 'Verifikasi gagal atau kedaluwarsa. Silakan masuk kembali.');
        redirect(url('/masuk'));
    }
    flash('error', 'Kode tidak valid atau sudah dipakai. Coba lagi dengan kode terbaru.');
    redirect(url('/masuk/2fa'));
}, ['public' => true]);

route('POST', '/keluar', function () {
    logout_user();
    session_start();
    flash('info', 'Anda sudah keluar.');
    redirect(url('/masuk'));
});

// ---------- keamanan akun ----------

route('GET', '/keamanan', function () {
    $u = current_user();
    $secret = $_SESSION['totp_pending'] ?? null;
    render('keamanan', [
        'u'      => $u,
        'secret' => $secret,
        'uri'    => $secret ? totp_uri($secret, $u['username'], cfg('app_name', 'LM Finance') . ' Admin') : null,
        'forced' => must_finish_security(),
    ], ['title' => 'Keamanan', 'active' => is_admin_mode() ? '/keamanan' : '/pengaturan']);
});

route('POST', '/keamanan/password', function () {
    $u = current_user();
    $cur = (string)($_POST['current'] ?? '');
    $new = (string)($_POST['new'] ?? '');
    $conf = (string)($_POST['confirm'] ?? '');
    if (!password_verify($cur, $u['password_hash'])) {
        flash('error', 'Password saat ini salah.');
        redirect(url('/keamanan'));
    }
    if ($new !== $conf) {
        flash('error', 'Konfirmasi password baru tidak sama.');
        redirect(url('/keamanan'));
    }
    if ($new === $cur) {
        flash('error', 'Password baru harus berbeda dari password saat ini.');
        redirect(url('/keamanan'));
    }
    if ($p = password_problems($new)) {
        flash('error', implode(' ', $p));
        redirect(url('/keamanan'));
    }
    update_row('users', (int)$u['id'], ['password_hash' => password_hash($new, PASSWORD_DEFAULT), 'must_change_password' => 0]);
    audit('ganti_password', 'user', (int)$u['id'], 'Mengganti password sendiri');
    session_regenerate_id(true);
    flash('success', 'Password berhasil diganti.');
    redirect(url('/keamanan'));
});

route('POST', '/keamanan/2fa/mulai', function () {
    if (!is_admin_mode()) {
        redirect(url('/keamanan'));
    }
    $_SESSION['totp_pending'] = totp_new_secret();
    redirect(url('/keamanan'));
});

route('POST', '/keamanan/2fa/aktifkan', function () {
    $u = current_user();
    $secret = $_SESSION['totp_pending'] ?? '';
    if (!is_admin_mode() || $secret === '') {
        redirect(url('/keamanan'));
    }
    $step = totp_verify($secret, (string)($_POST['code'] ?? ''));
    if ($step === null) {
        flash('error', 'Kode tidak cocok. Pastikan jam perangkat akurat lalu coba lagi.');
        redirect(url('/keamanan'));
    }
    update_row('users', (int)$u['id'], [
        'totp_secret' => secret_encrypt($secret), 'totp_enabled' => 1, 'totp_last_step' => $step,
    ]);
    unset($_SESSION['totp_pending']);
    audit('aktifkan_2fa', 'user', (int)$u['id'], 'Autentikasi dua langkah diaktifkan');
    flash('success', '2FA aktif. Mulai sekarang login membutuhkan kode dari aplikasi autentikator.');
    redirect(url('/'));
});
