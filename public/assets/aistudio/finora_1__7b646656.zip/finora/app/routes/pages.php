<?php
declare(strict_types=1);

function req_month(string $key = 'bulan'): string
{
    $v = req($key);
    return valid_month($v) ? $v : date('Y-m');
}

function req_periode(): string
{
    return in_array(req('periode'), ['6', '12', 'tahun'], true) ? req('periode') : '6';
}

// ---------- Dashboard ----------
route('GET', '/', function () {
    $u = current_user();
    $ym = req_month();
    $periode = req_periode();
    $rentang = in_array(req('rentang'), ['hari', 'bulan', 'tahun', 'semua'], true) ? req('rentang') : 'bulan';
    $rg = dash_range($rentang, $ym);
    $cur = business_summary($rg['from'], $rg['to']);
    $prev = $rg['pfrom'] ? business_summary($rg['pfrom'], $rg['pto']) : null;
    $balNow = balance_at($rg['to'] > today() ? '2100-12-31' : $rg['to']);
    $balPrev = $rg['pto'] ? balance_at($rg['pto']) : null;
    $chg = fn(int $now, ?int $before) => $before === null ? null : pct_change((float)$now, (float)$before);
    $inv = invoice_stats();
    $budgets = budget_rows($ym);
    $budTotal = array_sum(array_column($budgets, 'amount'));
    $budUsed = array_sum(array_column($budgets, 'used'));
    $months = period_months($ym, $periode);
    [$recent] = tx_list([], 1, 5);

    render('dashboard', [
        'first'    => explode(' ', trim($u['name']))[0],
        'ym'       => $ym,
        'periode'  => $periode,
        'rentang'  => $rentang,
        'rg'       => $rg,
        'stats'    => [
            ['Total Saldo', $balNow, $chg($balNow, $balPrev), 'wallet', 'blue', true],
            ['Pemasukan', $cur['income'], $chg($cur['income'], $prev['income'] ?? null), 'arrowDown', 'green', true],
            ['Pengeluaran', $cur['expense'], $chg($cur['expense'], $prev['expense'] ?? null), 'arrowUp', 'red', false],
            ['Arus Kas Bersih', $cur['net_cash'], $chg($cur['net_cash'], $prev['net_cash'] ?? null), 'swap', 'purple', true],
        ],
        'stats2'   => [
            ['Laba Kotor Penjualan', $cur['gross_profit'], $chg($cur['gross_profit'], $prev['gross_profit'] ?? null), 'chart', 'green', true],
            ['Laba Bersih', $cur['net_profit'], $chg($cur['net_profit'], $prev['net_profit'] ?? null), 'budget', 'purple', true],
        ],
        'sum'      => $cur,
        'stock'    => car_stock_summary(),
        'inv'      => $inv,
        'budPct'   => $budTotal > 0 ? round($budUsed / $budTotal * 100, 1) : null,
        'series'   => monthly_series($months),
        'expCats'  => expense_by_category($rg['from'], $rg['to']),
        'expTotal' => $cur['expense'],
        'recent'   => $recent,
        'pending'  => pending_map('transaction', array_column($recent, 'id')),
    ], ['title' => 'Dashboard', 'active' => '/']);
});

// ---------- Transaksi ----------
route('GET', '/transaksi', function () {
    $f = ['q' => mb_substr(req('q'), 0, 80), 'type' => in_array(req('jenis'), ['income', 'expense'], true) ? req('jenis') : ''];
    $bulan = valid_month(req('bulan')) ? req('bulan') : '';
    if ($bulan) {
        $f['from'] = $bulan . '-01';
        $f['to'] = month_end($bulan);
    }
    $page = max(1, (int)req('page', '1'));
    $per = 10;
    [$list, $total] = tx_list($f, $page, $per);
    $pages = max(1, (int)ceil($total / $per));
    if ($page > $pages) {
        $page = $pages;
        [$list, $total] = tx_list($f, $page, $per);
    }
    render('transaksi', [
        'list' => $list, 'total' => $total, 'page' => $page, 'pages' => $pages, 'per' => $per,
        'q' => $f['q'], 'jenis' => $f['type'], 'bulan' => $bulan,
        'pending' => pending_map('transaction', array_column($list, 'id')),
    ], ['title' => 'Transaksi', 'active' => '/transaksi']);
});

// ---------- Kategori ----------
route('GET', '/kategori', function () {
    $ym = req_month();
    $totals = category_totals($ym . '-01', month_end($ym));
    $cats = rows('SELECT * FROM categories ORDER BY type DESC, name');
    foreach ($cats as &$c) {
        $c['total'] = $totals[(int)$c['id']] ?? 0;
    }
    unset($c);
    render('kategori', [
        'cats' => $cats, 'ym' => $ym,
        'pending' => pending_map('category', array_column($cats, 'id')),
    ], ['title' => 'Kategori', 'active' => '/kategori']);
});

// ---------- Analitik ----------
route('GET', '/analitik', function () {
    $ym = req_month();
    $periode = req_periode();
    $months = period_months($ym, $periode);
    $series = monthly_series($months);
    $cur = sum_month($ym);
    $prev = sum_month(month_add($ym, -1));
    $profit = $cur['income'] - $cur['expense'];
    $profits = [];
    foreach ($months as $i => $m) {
        $profits[] = $series['income'][$i] - $series['expense'][$i];
    }
    render('analitik', [
        'ym' => $ym, 'periode' => $periode, 'series' => $series, 'profits' => $profits,
        'cur' => $cur, 'prev' => $prev, 'profit' => $profit,
        'margin' => $cur['income'] > 0 ? $profit / $cur['income'] * 100 : null,
        'expCats' => expense_by_category($ym . '-01', month_end($ym)),
    ], ['title' => 'Analitik', 'active' => '/analitik']);
});

// ---------- Laporan ----------
function report_range(): array
{
    $to = valid_month(req('sampai')) ? req('sampai') : date('Y-m');
    $from = valid_month(req('dari')) ? req('dari') : month_add($to, -5);
    if ($from > $to) {
        [$from, $to] = [$to, $from];
    }
    // batasi maksimal 36 bulan
    if (month_add($from, 36) <= $to) {
        $from = month_add($to, -35);
    }
    return [$from, $to];
}

function report_data(string $from, string $to): array
{
    $months = [];
    for ($m = $from; $m <= $to; $m = month_add($m, 1)) {
        $months[] = $m;
    }
    $series = monthly_series($months);
    $catRows = rows(
        'SELECT c.name, c.type, COALESCE(SUM(t.amount),0) AS s FROM transactions t JOIN categories c ON c.id=t.category_id
         WHERE t.tx_date>=? AND t.tx_date<=? GROUP BY c.id, c.name, c.type ORDER BY c.type, s DESC',
        [$from . '-01', month_end($to)]
    );
    $inc = array_sum($series['income']);
    $exp = array_sum($series['expense']);
    return ['months' => $months, 'series' => $series, 'cats' => $catRows, 'income' => $inc, 'expense' => $exp, 'profit' => $inc - $exp];
}

route('GET', '/laporan', function () {
    [$from, $to] = report_range();
    render('laporan', ['from' => $from, 'to' => $to, 'r' => report_data($from, $to)], ['title' => 'Laporan', 'active' => '/laporan']);
});

route('GET', '/laporan/cetak', function () {
    [$from, $to] = report_range();
    $r = report_data($from, $to);
    [$tx] = tx_list(['from' => $from . '-01', 'to' => month_end($to)], 1, 0);
    audit('cetak_laporan', 'laporan', null, $from . ' s/d ' . $to);
    render('laporan_cetak', ['from' => $from, 'to' => $to, 'r' => $r, 'tx' => $tx, 'company' => settings_all()],
        ['layout' => 'bare', 'title' => 'Laporan Keuangan', 'body_attr' => 'data-print']);
});

function csv_safe($v): string
{
    $s = (string)$v;
    if ($s !== '' && in_array($s[0], ['=', '+', '-', '@', "\t", "\r"], true)) {
        $s = "'" . $s;
    }
    return '"' . str_replace('"', '""', $s) . '"';
}

route('GET', '/laporan/export', function () {
    [$from, $to] = report_range();
    $r = report_data($from, $to);
    [$tx] = tx_list(['from' => $from . '-01', 'to' => month_end($to)], 1, 0);
    $format = req('format') === 'csv' ? 'csv' : 'xlsx';
    $name = 'laporan-keuangan-' . $from . '_' . $to;
    audit('ekspor_laporan', 'laporan', null, $format . ' ' . $from . ' s/d ' . $to);

    $summary = [['Bulan', 'Pemasukan', 'Pengeluaran', 'Arus Kas Bersih']];
    foreach ($r['months'] as $i => $m) {
        $summary[] = [month_label($m), $r['series']['income'][$i], $r['series']['expense'][$i], $r['series']['income'][$i] - $r['series']['expense'][$i]];
    }
    $summary[] = ['TOTAL', $r['income'], $r['expense'], $r['profit']];
    $txRows = [['Tanggal', 'Nama', 'Jenis', 'Kategori', 'Akun', 'Jumlah', 'Catatan']];
    foreach ($tx as $t) {
        $txRows[] = [$t['tx_date'], $t['name'], $t['type'] === 'income' ? 'Pemasukan' : 'Pengeluaran', $t['category_name'], $t['account_name'], (int)$t['amount'], $t['note']];
    }

    $bin = $format === 'xlsx' ? xlsx_build([
        ['name' => 'Ringkasan', 'rows' => $summary, 'widths' => [20, 18, 18, 18], 'money_cols' => [1, 2, 3]],
        ['name' => 'Transaksi', 'rows' => $txRows, 'widths' => [12, 36, 13, 20, 18, 16, 32], 'money_cols' => [5]],
    ]) : null;

    if ($bin !== null) {
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="' . $name . '.xlsx"');
        header('Content-Length: ' . strlen($bin));
        echo $bin;
        return;
    }
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $name . '.csv"');
    echo "\xEF\xBB\xBF";
    foreach ($txRows as $row) {
        echo implode(';', array_map('csv_safe', $row)) . "\r\n";
    }
});

// ---------- Akun ----------
route('GET', '/akun', function () {
    $accs = account_balances();
    render('akun', [
        'accs' => $accs, 'total' => array_sum(array_column($accs, 'balance')),
        'pending' => pending_map('account', array_column($accs, 'id')),
    ], ['title' => 'Akun & Dana', 'active' => '/akun']);
});

// ---------- Piutang & Utang ----------
route('GET', '/piutang-utang', function () {
    $tab = in_array(req('tab'), ['piutang', 'utang'], true) ? req('tab') : 'semua';
    $where = '1=1';
    $p = [];
    if ($tab !== 'semua') {
        $where = 'kind=?';
        $p[] = $tab === 'piutang' ? 'receivable' : 'payable';
    }
    $list = rows("SELECT * FROM invoices WHERE $where ORDER BY CASE WHEN status='unpaid' THEN 0 ELSE 1 END, due_date ASC, id DESC LIMIT 300", $p);
    render('piutang', [
        'tab' => $tab, 'list' => $list, 'inv' => invoice_stats(),
        'pending' => pending_map('invoice', array_column($list, 'id')),
    ], ['title' => 'Piutang & Utang', 'active' => '/piutang-utang']);
});

// ---------- Anggaran ----------
route('GET', '/anggaran', function () {
    $ym = req_month();
    $list = budget_rows($ym);
    $total = array_sum(array_column($list, 'amount'));
    $used = array_sum(array_column($list, 'used'));
    render('anggaran', [
        'ym' => $ym, 'list' => $list, 'total' => $total, 'used' => $used,
        'cats' => rows("SELECT id, name FROM categories WHERE type='expense' ORDER BY name"),
        'pending' => pending_map('budget', array_column($list, 'id')),
    ], ['title' => 'Anggaran', 'active' => '/anggaran']);
});

// ---------- Pengaturan ----------
route('GET', '/pengaturan', function () {
    render('pengaturan', [
        's' => settings_all(),
        'pendingSettings' => pending_exists('settings', null),
    ], ['title' => 'Pengaturan', 'active' => '/pengaturan']);
});

// ---------- Aksi data (satu pintu untuk semua perubahan) ----------
route('POST', '/aksi', function () {
    $entity = req('entity');
    $action = req('action');
    $id = ctype_digit(req('id')) ? (int)req('id') : null;
    if (!entity_get($entity)) {
        flash('error', 'Permintaan tidak valid.');
        redirect(url('/'));
    }
    [$ok, $msg] = submit_change($entity, $action, $id, $_POST);
    flash($ok ? 'success' : 'error', $msg);
    redirect(safe_return(req('return'), '/'));
}, ['write' => true]);

// ---------- Permintaan saya (pengguna biasa) ----------
route('GET', '/permintaan', function () {
    $u = current_user();
    $list = rows('SELECT r.*, v.name AS reviewer FROM change_requests r LEFT JOIN users v ON v.id=r.reviewed_by WHERE r.requested_by=? ORDER BY r.id DESC LIMIT 100', [(int)$u['id']]);
    render('permintaan', ['list' => $list], ['title' => 'Permintaan Saya', 'active' => '/permintaan']);
});
